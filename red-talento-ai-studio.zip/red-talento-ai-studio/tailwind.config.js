/** Tokens del brandbook Extandard 2026 */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        blanco: "#FFFFFF",
        negro: "#000000",
        roto: "rgba(255,255,255,.55)",
        tinta: "#1D1D1B",
        suave: "#5A5F69",
        linea: "rgba(10,20,40,.10)",
        filo: "rgba(10,20,40,.10)",
        verde: "#00FF00",
        azul: "#0B70FE",
        celeste: "#43CCFF",
        magenta: "#FF0085",
        amarillo: "#FFD917",
        ambar: "#FF9F00",
      },
      fontFamily: {
        display: ['"Concrette XL"', "Georgia", "serif"],
        sans: ['"General Sans"', "system-ui", "-apple-system", "Segoe UI", "sans-serif"],
        mono: ['"Geist Mono"', "ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      borderRadius: { tarjeta: "28px", tag: "999px", marco: "46px" },
      borderWidth: { fino: "0.5px" },
      boxShadow: { flotante: "0 30px 70px -30px rgba(30,60,130,.35)", frio: "0 24px 60px -28px rgba(30,60,130,.30)" },
      maxWidth: { contenido: "1240px" },
    },
  },
  plugins: [],
};
