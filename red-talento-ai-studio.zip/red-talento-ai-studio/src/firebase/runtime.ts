/**
 * Adaptador de Firebase.
 * La app se escribió contra una interfaz mínima tipo Firestore (doc / collection / onSnapshot / set / update / delete)
 * y un espacio de usuario (me / can / canEdit / profiles). Este archivo implementa esa misma interfaz con
 * Firebase Authentication + Cloud Firestore y la expone en window.claude, de modo que el resto del código no cambia.
 *
 * Roles:
 *  - Equipo (administrador): su correo verificado existe como documento en la colección `admins` (admins/{correo en minúsculas}).
 *    Esa colección solo se edita desde la consola de Firebase.
 *  - Profesional: cualquier persona con sesión iniciada.
 *  - Visitante: sin sesión; solo lee la portada y las ofertas públicas (colección `board`).
 * Los permisos los impone firestore.rules en el servidor; la interfaz solo refleja lo que las reglas permiten.
 */
import { initializeApp } from "firebase/app";
import {
  GoogleAuthProvider, createUserWithEmailAndPassword, getAuth, onAuthStateChanged, sendEmailVerification,
  sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup, signOut, updateProfile, type User,
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDoc, initializeFirestore, onSnapshot, setDoc, updateDoc, writeBatch,
  type DocumentSnapshot,
} from "firebase/firestore";
import { firebaseConfig } from "./config";
import type { AuthNS } from "../Acceso";
import type { ColRef, DB, DocRef, Snap, UserNS } from "../db";
import seed from "./seed.json";

export function firebaseConfigured() { return !!firebaseConfig.apiKey && !!firebaseConfig.projectId; }

export async function installFirebaseRuntime() {
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  // ignoreUndefinedProperties: la app a veces construye objetos con campos opcionales sin valor.
  const fs = initializeFirestore(app, { ignoreUndefinedProperties: true });

  const user: User | null = await new Promise((res) => { const off = onAuthStateChanged(auth, (u) => { off(); res(u); }); });
  const email = user?.email?.toLowerCase() ?? null;
  let isAdmin = false;
  if (user && email && user.emailVerified) {
    try { isAdmin = (await getDoc(doc(fs, "admins", email))).exists(); } catch { isAdmin = false; }
    // Directorio del equipo para mostrar nombres en historiales y notas.
    if (isAdmin) setDoc(doc(fs, "staff", user.uid), { name: user.displayName || email, email }, { merge: true }).catch(() => {});
  }

  const wrap = (s: DocumentSnapshot): Snap => ({ id: s.id, exists: s.exists(), data: () => (s.exists() ? (s.data() as Record<string, unknown>) : undefined) });
  const errOf = (e: { code?: string; message?: string }) => ({ code: (e.code ?? "unknown").replace(/^firestore\//, ""), message: e.message ?? "" });

  const docRef = (path: string): DocRef => {
    const d = doc(fs, path);
    return {
      id: d.id, path,
      get: async () => wrap(await getDoc(d)),
      set: (data) => setDoc(d, data),
      update: (data) => updateDoc(d, data),
      delete: () => deleteDoc(d),
      onSnapshot: (n, e) => onSnapshot(d, (s) => n(wrap(s)), (err) => e?.(errOf(err))),
    };
  };
  const colRef = (path: string): ColRef => {
    const c = collection(fs, path);
    const self: ColRef = {
      path,
      doc: (id?: string) => docRef(id ? `${path}/${id}` : doc(c).path),
      add: async (data) => docRef((await addDoc(c, data)).path),
      orderBy: () => self,
      limit: () => self,
      onSnapshot: (n, e) => onSnapshot(c, (q) => n({ docs: q.docs.map(wrap) }), (err) => e?.(errOf(err))),
    };
    return self;
  };
  const db: DB = { doc: docRef, collection: colRef };

  const userNS: UserNS = {
    canEdit: async () => isAdmin,
    can: async () => !!user,
    id: async () => user?.uid ?? null,
    me: async () => ({ id: user?.uid ?? null, name: user?.displayName || email || "", avatarUrl: user?.photoURL ?? "", isOwner: isAdmin, canEdit: isAdmin }),
    profiles: async (ids) => {
      const out: Record<string, { name: string; avatarUrl: string }> = {};
      await Promise.all(ids.map(async (id) => {
        for (const col of ["staff", "profiles"]) {
          try {
            const s = await getDoc(doc(fs, col, id));
            if (s.exists()) { const v = s.data() as { name?: string; fullName?: string }; out[id] = { name: v.name || v.fullName || "", avatarUrl: "" }; return; }
          } catch { /* sin permiso: se muestra el identificador */ }
        }
      }));
      return out;
    },
  };

  const authNS: AuthNS = {
    current: () => (user ? { email: user.email ?? "", verified: user.emailVerified, name: user.displayName ?? "" } : null),
    signIn: async (e, p) => { await signInWithEmailAndPassword(auth, e, p); },
    signUp: async (e, p, name) => {
      const cred = await createUserWithEmailAndPassword(auth, e, p);
      if (name) await updateProfile(cred.user, { displayName: name });
      await sendEmailVerification(cred.user).catch(() => {});
    },
    google: async () => { await signInWithPopup(auth, new GoogleAuthProvider()); },
    reset: async (e) => { await sendPasswordResetEmail(auth, e); },
    resendVerification: async () => { if (auth.currentUser) await sendEmailVerification(auth.currentUser); },
    signOut: async () => { await signOut(auth); },
  };

  window.claude = { use: async (name: string) => (name === "db" ? db : name === "user" ? userNS : null) };
  window.__extandardAuth = authNS;
  if (isAdmin) {
    window.__extandardSeed = async () => {
      const docs = seed as { path: string; data: Record<string, unknown> }[];
      for (let i = 0; i < docs.length; i += 400) {
        const b = writeBatch(fs);
        for (const d of docs.slice(i, i + 400)) b.set(doc(fs, d.path), d.data);
        await b.commit();
      }
      return docs.length;
    };
  }
}
