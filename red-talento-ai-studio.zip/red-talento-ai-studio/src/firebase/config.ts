/**
 * Configuración del proyecto de Firebase.
 * AI Studio la rellena al conectar Firebase (o cópiala de Consola de Firebase → Configuración del proyecto → Tus apps → Web).
 * Estos valores son públicos por diseño: la seguridad la ponen las reglas de firestore.rules, no ocultar la clave.
 */
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY ?? "",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? "",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID ?? "",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ?? "",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? "",
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? "",
};
