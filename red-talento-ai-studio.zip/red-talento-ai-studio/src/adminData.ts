import { useMemo } from "react";
import { audit, notify, now, plain, profileStatus, useCollection, type DB } from "./db";
import type {
  AppStatusDoc, AppsDoc, AuditEntry, BoardItem, Internal, Opportunity, OppStatus, PipelineDoc, PipelineEntry, Profile, ProfileStatus, Review, Stage,
} from "./types";
import { STAGE_TO_PUBLIC, PROFILE_STATUS, STAGES, isActive } from "./constants";
import { specialtyOverlap } from "./match";

export function useAdminData(db: DB | null) {
  const profiles = useCollection<Profile>(db, "profiles");
  const reviews = useCollection<Review>(db, "reviews");
  const internal = useCollection<Internal>(db, "internal");
  const apps = useCollection<AppsDoc>(db, "apps");
  const appStatus = useCollection<AppStatusDoc>(db, "appStatus");
  const pipeline = useCollection<PipelineDoc>(db, "pipeline");
  const opps = useCollection<Opportunity>(db, "opps");
  const board = useCollection<BoardItem>(db, "board");
  const auditLog = useCollection<AuditEntry>(db, "audit");
  const ready = profiles.ready && reviews.ready && opps.ready && apps.ready && pipeline.ready;

  return useMemo(() => {
    const byId = <T extends { _id: string }>(l: T[]) => Object.fromEntries(l.map((x) => [x._id, x]));
    const rev = byId(reviews.items);
    const int = byId(internal.items);
    const ap = byId(apps.items);
    const aps = byId(appStatus.items);
    const pl = byId(pipeline.items);
    const people = profiles.items.map((p) => ({
      ...p, uid: p._id,
      review: (rev[p._id] as Review | undefined) ?? null,
      status: profileStatus(p, rev[p._id] as Review | undefined) as ProfileStatus,
      internal: (int[p._id] as Internal | undefined) ?? { tags: [], notes: [] },
    }));
    /** Candidaturas aplanadas: una fila por (profesional, oportunidad). */
    const applications = apps.items.flatMap((doc) => Object.values(doc.items ?? {}).map((a) => {
      const pe = (pl[doc._id] as PipelineDoc | undefined)?.items?.[a.oppId];
      return { uid: doc._id, ...a, stage: (pe?.stage ?? "nueva") as Stage, pipe: pe ?? null, withdrawn: !!a.withdrawnAt };
    }));
    // Duplicados: mismo correo o mismo LinkedIn en perfiles distintos.
    const keyCount: Record<string, number> = {};
    for (const p of people) for (const k of [p.email?.trim().toLowerCase(), p.linkedin?.trim().toLowerCase().replace(/\/$/, "")]) if (k) keyCount[k] = (keyCount[k] ?? 0) + 1;
    const dupes = new Set(people.filter((p) => [p.email?.trim().toLowerCase(), p.linkedin?.trim().toLowerCase().replace(/\/$/, "")].some((k) => k && keyCount[k] > 1)).map((p) => p.uid));
    const audits = [...auditLog.items].sort((a, b) => (b.at > a.at ? 1 : -1));
    return {
      ready, people, applications, opps: opps.items, board: board.items, audits, dupes,
      appsRaw: ap as Record<string, AppsDoc>, appStatusRaw: aps as Record<string, AppStatusDoc>, pipelineRaw: pl as Record<string, PipelineDoc>,
    };
  }, [ready, profiles.items, reviews.items, internal.items, apps.items, appStatus.items, pipeline.items, opps.items, board.items, auditLog.items]);
}
export type AdminData = ReturnType<typeof useAdminData>;
export type Person = AdminData["people"][number];
export type AppRow = AdminData["applications"][number];

/* ---------- Acciones del equipo ---------- */

export async function setProfileStatus(db: DB, by: string, person: Person, status: ProfileStatus, note?: string) {
  const prev = person.review ? plain(person.review) : { history: [] as Review["history"] };
  const t = now();
  const body: Review = { status, ...(note ? { note } : {}), updatedAt: t, history: [...(prev.history ?? []), { status, by, at: t, ...(note ? { note } : {}) }] };
  await db.doc(`reviews/${person.uid}`).set(body as unknown as Record<string, unknown>);
  const msg: Partial<Record<ProfileStatus, string>> = {
    aprobado: "Tu perfil vuelve a estar activo en la red.",
    info_solicitada: `El equipo te pide completar algunos datos de tu perfil${note ? `: ${note}` : "."} Tu perfil sigue activo.`,
    inactivo: "Tu perfil ha pasado a inactivo en la red.",
  };
  if (msg[status]) await notify(db, person.uid, msg[status]!);
  await audit(db, { action: `Perfil → ${PROFILE_STATUS[status].label}`, target: person.fullName || person.uid, by, detail: note });
}

export async function setStage(db: DB, by: string, d: AdminData, row: AppRow, stage: Stage, extra: Partial<PipelineEntry> = {}) {
  const t = now();
  const pdoc = plain(d.pipelineRaw[row.uid]?.items ?? {}) as PipelineDoc["items"];
  const cur = pdoc[row.oppId] ?? { stage: "nueva", history: [] };
  const changed = cur.stage !== stage;
  pdoc[row.oppId] = { ...cur, ...extra, stage, history: changed ? [...(cur.history ?? []), { status: stage, by, at: t }] : cur.history ?? [] };
  await db.doc(`pipeline/${row.uid}`).set({ items: pdoc });
  if (!changed) return;
  const sdoc = plain(d.appStatusRaw[row.uid]?.items ?? {}) as AppStatusDoc["items"];
  sdoc[row.oppId] = { status: STAGE_TO_PUBLIC[stage], updatedAt: t };
  await db.doc(`appStatus/${row.uid}`).set({ items: sdoc });
  const label = STAGES.find((s) => s.id === stage)!.label;
  const txt: Partial<Record<Stage, string>> = {
    revision: `Estamos revisando tu candidatura a «${row.title}».`,
    preseleccionada: `Has sido preseleccionado/a para «${row.title}». Te contactaremos con los siguientes pasos.`,
    entrevista: `Tu candidatura a «${row.title}» pasa a fase de entrevista o reunión.`,
    seleccionada: `Has sido seleccionado/a para «${row.title}». ¡Enhorabuena!`,
    no_seleccionada: `Tu candidatura a «${row.title}» no ha sido seleccionada esta vez. Gracias por presentarte.`,
  };
  if (txt[stage]) await notify(db, row.uid, txt[stage]!, row.oppId);
  await audit(db, { action: `Candidatura → ${label}`, target: `${row.title}`, by, detail: row.uid });
}

export async function savePipelineFields(db: DB, d: AdminData, row: AppRow, extra: Partial<PipelineEntry>) {
  const pdoc = plain(d.pipelineRaw[row.uid]?.items ?? {}) as PipelineDoc["items"];
  const cur = pdoc[row.oppId] ?? { stage: "nueva" as Stage, history: [] };
  pdoc[row.oppId] = { ...cur, ...extra };
  await db.doc(`pipeline/${row.uid}`).set({ items: pdoc });
}

function rateText(o: Opportunity) {
  if (!o.publishRate || (!o.rateMin && !o.rateMax)) return null;
  const u = o.rateType === "dia" ? "día" : "mes";
  const f = (n: number) => n.toLocaleString("es-ES");
  if (o.rateMin && o.rateMax) return `${f(o.rateMin)}–${f(o.rateMax)} ${o.currency} / ${u}`;
  return `${o.rateMin ? "Desde" : "Hasta"} ${f((o.rateMin || o.rateMax)!)} ${o.currency} / ${u}`;
}

/** Proyección pública: nunca incluye cliente confidencial, notas internas ni tarifas no publicadas. */
export function toBoard(o: Opportunity, publishedAt: string): BoardItem {
  return {
    id: o.id, title: o.title, client: o.clientConfidential ? null : o.client || null, summary: o.summary, description: o.description, context: o.context,
    objectives: o.objectives, responsibilities: o.responsibilities, requirements: o.requirements, specialties: o.specialties, sector: o.sector,
    companyType: o.companyType, dedication: o.dedication, collaboration: o.collaboration, duration: o.duration, startDate: o.startDate, workMode: o.workMode,
    location: o.location, rate: rateText(o), deadline: o.deadline, status: o.status as BoardItem["status"], publishedAt, ...(o.demo ? { demo: true } : {}),
  };
}

export async function saveOpportunity(db: DB, by: string, d: AdminData, o: Opportunity, nextStatus?: OppStatus) {
  const prev = d.opps.find((x) => x._id === o.id);
  const status = nextStatus ?? o.status;
  const body: Opportunity = { ...o, status, updatedAt: now() };
  await db.doc(`opps/${o.id}`).set(plain(body) as unknown as Record<string, unknown>);
  const existingBoard = d.board.find((b) => b._id === o.id);
  if (status === "publicada" || status === "pausada" || status === "cerrada") {
    await db.doc(`board/${o.id}`).set(plain(toBoard(body, existingBoard?.publishedAt ?? now())) as unknown as Record<string, unknown>);
  } else if (existingBoard) {
    await db.doc(`board/${o.id}`).delete();
  }
  // Avisos
  if (status === "publicada" && prev?.status !== "publicada" && !existingBoard) {
    const fits = d.people.filter((p) => isActive(p.status) && p.availability !== "no_disponible" && specialtyOverlap(p, body) > 0);
    for (const p of fits) await notify(db, p.uid, `Nueva oportunidad que encaja con tu perfil: «${body.title}».`, body.id);
  }
  if (status === "cerrada" && prev?.status !== "cerrada") {
    const applicants = d.applications.filter((a) => a.oppId === o.id && !a.withdrawn);
    for (const a of applicants) await notify(db, a.uid, `La oportunidad «${body.title}» se ha cerrado.`, body.id);
  }
  if (prev?.status !== status || !prev) await audit(db, { action: prev ? `Oportunidad → ${status}` : "Oportunidad creada", target: body.internalName || body.title, by });
  else await audit(db, { action: "Oportunidad editada", target: body.internalName || body.title, by });
}

export async function saveInternal(db: DB, uid: string, data: Internal) {
  await db.doc(`internal/${uid}`).set(plain(data) as unknown as Record<string, unknown>);
}

export async function deletePersonData(db: DB, by: string, person: Person) {
  for (const c of ["profiles", "reviews", "internal", "apps", "appStatus", "pipeline", "inbox"]) {
    try { await db.doc(`${c}/${person.uid}`).delete(); } catch { /* */ }
  }
  await audit(db, { action: "Datos eliminados a petición", target: person.fullName || person.uid, by });
}
