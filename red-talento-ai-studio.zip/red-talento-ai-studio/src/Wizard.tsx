import type React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "./context";
import { notify, now, plain, profileStatus, useDoc } from "./db";
import type { Experience, Profile, Review } from "./types";
import {
  COLLABORATIONS, COMPANY_SIZES, COMPANY_TYPES, CURRENCIES, DEDICATIONS, LANGUAGES, TEAM_LEADERSHIP, TIMEZONES, WORK_MODES, AVAILABILITY,
} from "./constants";
import { Arrow, ChipSelect, Field, LoadingBlock, Select, TextArea, TextInput, useToast, AvailabilityDot } from "./ui";

export const STEPS = ["Información básica", "Experiencia", "Especialización", "Disponibilidad", "Revisión y envío"];

export function emptyProfile(uid: string, name = ""): Profile {
  const t = now();
  return {
    uid, fullName: name, email: "", location: "", timezone: "Europe/Madrid (CET)", linkedin: "", website: "", languages: ["Español"],
    headline: "", bio: "", years: null, currentRole: "", experience: [{ role: "", company: "", period: "", summary: "" }], sectorsWorked: [], companyTypes: [], achievements: "",
    specialties: [], sectorsExpertise: [], companySizes: [], teamLeadership: "", tools: "",
    availability: "disponible", availableFrom: "", dedication: "", collaboration: [], workMode: [], preferredLocations: "", rateType: "dia", rateMin: null, currency: "EUR", comments: "",
    step: 0, createdAt: t, updatedAt: t,
  };
}

type Errors = Record<string, string>;
const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s.trim());
const isUrl = (s: string) => /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/\S*)?$/i.test(s.trim());

export function validate(p: Profile, step: number): Errors {
  const e: Errors = {};
  if (step === 0) {
    if (p.fullName.trim().length < 3) e.fullName = "Escribe tu nombre y apellidos.";
    if (!isEmail(p.email)) e.email = "Escribe un correo válido, por ejemplo nombre@empresa.com.";
    if (!p.location.trim()) e.location = "Indica tu ciudad y país.";
    if (!p.timezone) e.timezone = "Elige tu zona horaria.";
    if (!/linkedin\.com\//i.test(p.linkedin)) e.linkedin = "Pega la URL completa de tu perfil de LinkedIn.";
    if (p.website && !isUrl(p.website)) e.website = "La web no parece una URL válida.";
    if (!p.languages.length) e.languages = "Elige al menos un idioma.";
  }
  if (step === 1) {
    if (p.headline.trim().length < 6) e.headline = "Escribe un titular breve, por ejemplo «Fractional CMO B2B SaaS».";
    if (p.bio.trim().length < 80) e.bio = `Cuéntanos un poco más (mínimo 80 caracteres; llevas ${p.bio.trim().length}).`;
    if (!p.years || p.years < 1 || p.years > 60) e.years = "Indica tus años de experiencia (entre 1 y 60).";
    if (!p.currentRole.trim()) e.currentRole = "Indica tu cargo o situación actual.";
    if (!p.sectorsWorked.length) e.sectorsWorked = "Elige al menos un sector.";
    if (!p.companyTypes.length) e.companyTypes = "Elige al menos un tipo de empresa.";
    if (p.achievements.trim().length < 40) e.achievements = "Describe al menos un logro o caso de éxito (mínimo 40 caracteres).";
  }
  if (step === 2) {
    if (!p.specialties.length) e.specialties = "Elige al menos una especialidad.";
    if (!p.sectorsExpertise.length) e.sectorsExpertise = "Elige al menos un sector de especialización.";
    if (!p.companySizes.length) e.companySizes = "Elige al menos un tamaño de empresa.";
    if (!p.teamLeadership) e.teamLeadership = "Indica tu experiencia liderando equipos.";
  }
  if (step === 3) {
    if (!p.dedication) e.dedication = "Elige la dedicación que prefieres.";
    if (!p.collaboration.length) e.collaboration = "Elige al menos un tipo de colaboración.";
    if (!p.workMode.length) e.workMode = "Elige al menos una preferencia de trabajo.";
    if ((p.availability === "proximamente") && !p.availableFrom) e.availableFrom = "Indica desde cuándo estarás disponible.";
    if (p.rateMin !== null && (isNaN(p.rateMin) || p.rateMin < 0)) e.rateMin = "La tarifa debe ser un número positivo.";
  }
  return e;
}

export function completeness(p: Profile | null) {
  if (!p) return 0;
  const checks = [
    p.fullName, p.email, p.location, p.timezone, p.linkedin, p.languages.length, p.headline, p.bio.length >= 80, p.years, p.currentRole,
    p.experience.some((x) => x.role && x.company), p.sectorsWorked.length, p.companyTypes.length, p.achievements.length >= 40, p.specialties.length,
    p.sectorsExpertise.length, p.companySizes.length, p.teamLeadership, p.tools, p.dedication, p.collaboration.length, p.workMode.length, p.rateMin, p.website,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

export default function Wizard({ startStep }: { startStep?: number }) {
  const { session, catalog, label, go } = useApp();
  const toast = useToast();
  const { db, uid } = session;
  const prof = useDoc<Profile>(db, uid ? `profiles/${uid}` : null);
  const review = useDoc<Review>(db, uid ? `reviews/${uid}` : null);
  const [p, setP] = useState<Profile | null>(null);
  const [step, setStep] = useState(startStep ?? 0);
  const [errors, setErrors] = useState<Errors>({});
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [consent, setConsent] = useState(false);
  const topRef = useRef<HTMLDivElement>(null);
  const draftKey = uid ? `red-borrador-${uid}` : "";

  // Carga inicial: perfil guardado o borrador local no guardado.
  useEffect(() => {
    if (!prof.ready || p || !uid) return;
    let local: Profile | null = null;
    try { const raw = localStorage.getItem(draftKey); if (raw) local = JSON.parse(raw); } catch { /* sin almacenamiento */ }
    const base = prof.data ? plain(prof.data) : emptyProfile(uid, session.name);
    const useLocal = local && (!prof.data || local.updatedAt > prof.data.updatedAt);
    setP(useLocal ? { ...base, ...local } : base);
    if (useLocal) setDirty(true);
    if (startStep === undefined && prof.data && !prof.data.submittedAt) setStep(Math.min(prof.data.step ?? 0, 4));
    setConsent(!!prof.data?.consentAt);
  }, [prof.ready]); // eslint-disable-line react-hooks/exhaustive-deps

  // Copia local de lo no guardado para no perder nada al cerrar.
  useEffect(() => {
    if (!p || !dirty || !draftKey) return;
    const t = setTimeout(() => { try { localStorage.setItem(draftKey, JSON.stringify({ ...p, updatedAt: now() })); } catch { /* */ } }, 400);
    return () => clearTimeout(t);
  }, [p, dirty, draftKey]);

  const status = profileStatus(prof.data, review.data);
  const submitted = !!prof.data?.submittedAt;

  const set = <K extends keyof Profile>(k: K, v: Profile[K]) => { setP((x) => (x ? { ...x, [k]: v } : x)); setDirty(true); setErrors((e) => { const n = { ...e }; delete n[k as string]; return n; }); };

  async function save(nextStep: number, extra: Partial<Profile> = {}) {
    if (!db || !uid || !p) return false;
    setSaving(true);
    const body: Profile = { ...p, ...extra, uid, step: Math.max(p.step ?? 0, nextStep), updatedAt: now() };
    try {
      await db.doc(`profiles/${uid}`).set(plain(body) as unknown as Record<string, unknown>);
      try { localStorage.removeItem(draftKey); } catch { /* */ }
      setP(body); setDirty(false);
      return true;
    } catch (err) {
      const code = (err as { code?: string }).code;
      toast(code === "invalid_argument" ? "Tu acceso no permite guardar. Pide acceso de colaborador al equipo." : "No se ha podido guardar. Revisa tu conexión y vuelve a intentarlo.", "error");
      return false;
    } finally { setSaving(false); }
  }

  const scrollTop = () => topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  async function next() {
    if (!p) return;
    const e = validate(p, step);
    setErrors(e);
    if (Object.keys(e).length) { toast("Revisa los campos marcados antes de seguir.", "error"); return; }
    if (await save(step + 1)) { setStep(step + 1); scrollTop(); }
  }

  async function saveLater() {
    if (await save(step)) { toast("Guardado. Puedes seguir cuando quieras."); go({ name: "inicio" }); }
  }

  async function submit() {
    if (!p || !db || !uid) return;
    for (let s = 0; s < 4; s++) {
      const e = validate(p, s);
      if (Object.keys(e).length) { setErrors(e); setStep(s); scrollTop(); toast(`Falta información en «${STEPS[s]}».`, "error"); return; }
    }
    if (!consent) { setErrors({ consent: "Necesitamos tu consentimiento para gestionar tu perfil." }); return; }
    const t = now();
    const resend = submitted && status === "info_solicitada";
    const firstTime = !submitted;
    if (firstTime || resend) {
      if (await save(4, { submittedAt: t, consentAt: p.consentAt ?? t })) {
        await notify(db, uid, resend ? "Has actualizado tu perfil con la información solicitada." : "Tu perfil ya está activo en la red. Ya puedes presentarte a las oportunidades publicadas.");
        go({ name: "inicio" });
        toast(resend ? "Perfil actualizado." : "¡Ya formas parte de la red!");
      }
    } else if (await save(4, { consentAt: p.consentAt ?? t })) { toast("Cambios guardados."); go({ name: "perfil" }); }
  }

  if (!uid) return <div className="gutter py-20 text-center text-suave">Necesitas iniciar sesión para crear tu perfil.</div>;
  if (!p) return <LoadingBlock label="Cargando tu perfil" />;

  const sp = catalog.specialties.filter((s) => !s.archived).map((s) => ({ value: s.id, label: s.label }));
  const se = catalog.sectors.filter((s) => !s.archived).map((s) => ({ value: s.id, label: s.label }));
  const opt = (l: string[]) => l.map((x) => ({ value: x, label: x }));
  const err = (k: string) => errors[k];
  const ia = (k: string) => !!errors[k];

  return (
    <div className="gutter" ref={topRef}>
      <div className="mx-auto grid max-w-contenido gap-10 py-10 md:grid-cols-6 md:py-14">
        {/* Columna lateral: progreso */}
        <aside className="md:col-span-2">
          <div className="flex flex-col gap-6 md:sticky" style={{ top: "calc(88px + env(safe-area-inset-top,0px))" }}>
            <div className="flex flex-col gap-2">
              <span className="eyebrow">{submitted ? "Editar perfil" : "Únete a la red"}</span>
              <h1 className="font-display text-[34px] leading-[1.02]">{submitted ? "Tu perfil profesional" : "Crea tu perfil profesional"}</h1>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-[rgba(10,20,40,.08)]" role="progressbar" aria-valuenow={(step + 1) * 20} aria-valuemin={0} aria-valuemax={100} aria-label="Progreso del registro">
              <div className="h-full rounded-full transition-all" style={{ background: "linear-gradient(90deg,#43CCFF,#00FF00)", width: `${((step + 1) / STEPS.length) * 100}%` }} />
            </div>
            <ol className="flex flex-col">
              {STEPS.map((s, i) => {
                const reached = i <= Math.max(p.step ?? 0, step) || submitted;
                return (
                  <li key={s}>
                    <button disabled={!reached} onClick={() => { setErrors({}); setStep(i); }}
                      className={`flex w-full items-center gap-3 border-b-[0.5px] border-filo py-2.5 text-left text-[14px] ${i === step ? "font-medium" : reached ? "" : "text-suave"}`}>
                      <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border border-filo text-[11px] tnum ${i === step ? "bg-verde" : i < (p.step ?? 0) || submitted ? "bg-negro text-blanco" : ""}`}>{i + 1}</span>
                      {s}
                    </button>
                  </li>
                );
              })}
            </ol>
            <p className="ayuda">{dirty ? "Hay cambios sin guardar. Se conservan en este navegador hasta que guardes." : "Todo guardado."}</p>
          </div>
        </aside>

        {/* Contenido del paso */}
        <section className="flex min-w-0 flex-col gap-7 md:col-span-4" key={step}>
          <header className="aparecer flex flex-col gap-1 border-b border-filo pb-4">
            <span className="eyebrow tnum">Paso {step + 1} de {STEPS.length}</span>
            <h2 className="font-display text-[30px] leading-tight">{STEPS[step]}</h2>
          </header>

          {step === 0 && (
            <div className="aparecer grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2"><Field id="fullName" label="Nombre y apellidos" error={err("fullName")}><TextInput id="fullName" value={p.fullName} invalid={ia("fullName")} onChange={(e) => set("fullName", e.target.value)} autoComplete="name" /></Field></div>
              <Field id="email" label="Correo electrónico profesional" error={err("email")}><TextInput id="email" type="email" value={p.email} invalid={ia("email")} onChange={(e) => set("email", e.target.value)} autoComplete="email" /></Field>
              <Field id="location" label="Ubicación" help="Ciudad y país" error={err("location")}><TextInput id="location" value={p.location} invalid={ia("location")} onChange={(e) => set("location", e.target.value)} placeholder="Madrid, España" /></Field>
              <Field id="timezone" label="Zona horaria" error={err("timezone")}><Select id="timezone" value={p.timezone} options={TIMEZONES} onChange={(e) => set("timezone", e.target.value)} /></Field>
              <Field id="linkedin" label="Perfil de LinkedIn" error={err("linkedin")}><TextInput id="linkedin" value={p.linkedin} invalid={ia("linkedin")} onChange={(e) => set("linkedin", e.target.value)} placeholder="https://www.linkedin.com/in/…" /></Field>
              <div className="sm:col-span-2"><Field id="website" label="Web personal o portfolio" optional error={err("website")}><TextInput id="website" value={p.website} invalid={ia("website")} onChange={(e) => set("website", e.target.value)} placeholder="https://" /></Field></div>
              <div className="sm:col-span-2"><Field id="languages" label="Idiomas de trabajo" error={err("languages")}><ChipSelect id="languages" options={opt(LANGUAGES)} value={p.languages} onChange={(v) => set("languages", v)} /></Field></div>
              <div className="sm:col-span-2"><Field id="photo" label="Fotografía profesional" optional help="La subida de fotos y CV se activará con el almacenamiento privado de archivos. En esta versión no se guarda ningún archivo."><input id="photo" type="file" disabled className="text-[13px] text-suave" /></Field></div>
            </div>
          )}

          {step === 1 && (
            <div className="aparecer grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2"><Field id="headline" label="Titular profesional" help="Cómo te presentarías en una línea" error={err("headline")}><TextInput id="headline" value={p.headline} invalid={ia("headline")} onChange={(e) => set("headline", e.target.value)} placeholder="Fractional CMO para scale-ups B2B" maxLength={90} /></Field></div>
              <div className="sm:col-span-2"><Field id="bio" label="Presentación profesional breve" help={`${p.bio.trim().length} caracteres · mínimo 80`} error={err("bio")}><TextArea id="bio" value={p.bio} invalid={ia("bio")} onChange={(e) => set("bio", e.target.value)} maxLength={1200} /></Field></div>
              <Field id="years" label="Años de experiencia" error={err("years")}><TextInput id="years" type="number" inputMode="numeric" min={1} max={60} value={p.years ?? ""} invalid={ia("years")} onChange={(e) => set("years", e.target.value === "" ? null : Number(e.target.value))} /></Field>
              <Field id="currentRole" label="Cargo actual o situación profesional" error={err("currentRole")}><TextInput id="currentRole" value={p.currentRole} invalid={ia("currentRole")} onChange={(e) => set("currentRole", e.target.value)} placeholder="Fractional CMO independiente" /></Field>
              <div className="flex flex-col gap-3 sm:col-span-2">
                <span className="etiqueta">Experiencia laboral relevante <span className="font-normal text-suave">· hasta 4 puestos</span></span>
                {p.experience.map((x, i) => {
                  const upd = (k: keyof Experience, v: string) => set("experience", p.experience.map((y, j) => (j === i ? { ...y, [k]: v } : y)));
                  return (
                    <div key={i} className="tarjeta tarjeta-roto grid gap-3 !p-4 sm:grid-cols-3">
                      <TextInput id={`exp-role-${i}`} aria-label="Cargo" placeholder="Cargo" value={x.role} onChange={(e) => upd("role", e.target.value)} />
                      <TextInput id={`exp-company-${i}`} aria-label="Empresa" placeholder="Empresa" value={x.company} onChange={(e) => upd("company", e.target.value)} />
                      <TextInput id={`exp-period-${i}`} aria-label="Periodo" placeholder="2019 – 2023" value={x.period} onChange={(e) => upd("period", e.target.value)} />
                      <div className="sm:col-span-3"><TextInput id={`exp-summary-${i}`} aria-label="Qué hiciste" placeholder="Qué hiciste y con qué resultado" value={x.summary} onChange={(e) => upd("summary", e.target.value)} /></div>
                      {p.experience.length > 1 && <div className="sm:col-span-3"><button type="button" className="btn btn-texto btn-sm" onClick={() => set("experience", p.experience.filter((_, j) => j !== i))}>Quitar este puesto</button></div>}
                    </div>
                  );
                })}
                {p.experience.length < 4 && <div><button type="button" className="btn btn-contorno btn-sm" onClick={() => set("experience", [...p.experience, { role: "", company: "", period: "", summary: "" }])}>Añadir puesto</button></div>}
              </div>
              <div className="sm:col-span-2"><Field id="sectorsWorked" label="Sectores en los que has trabajado" error={err("sectorsWorked")}><ChipSelect id="sectorsWorked" options={se} value={p.sectorsWorked} onChange={(v) => set("sectorsWorked", v)} /></Field></div>
              <div className="sm:col-span-2"><Field id="companyTypes" label="Tipo de empresas en las que has trabajado" error={err("companyTypes")}><ChipSelect id="companyTypes" options={opt(COMPANY_TYPES)} value={p.companyTypes} onChange={(v) => set("companyTypes", v)} /></Field></div>
              <div className="sm:col-span-2"><Field id="achievements" label="Principales logros y casos de éxito" help="Contexto, qué hiciste y qué resultado tuvo" error={err("achievements")}><TextArea id="achievements" value={p.achievements} invalid={ia("achievements")} onChange={(e) => set("achievements", e.target.value)} maxLength={1500} /></Field></div>
              <div className="sm:col-span-2"><Field id="cv" label="CV" optional help="La subida de archivos llegará con el almacenamiento privado. De momento basta con tu LinkedIn."><input id="cv" type="file" disabled className="text-[13px] text-suave" /></Field></div>
            </div>
          )}

          {step === 2 && (
            <div className="aparecer grid gap-6">
              <Field id="specialties" label="Especialidades" help="Elige hasta 6, las que de verdad dominas" error={err("specialties")}><ChipSelect id="specialties" options={sp} value={p.specialties} onChange={(v) => set("specialties", v)} max={6} /></Field>
              <Field id="sectorsExpertise" label="Sectores de especialización" error={err("sectorsExpertise")}><ChipSelect id="sectorsExpertise" options={se} value={p.sectorsExpertise} onChange={(v) => set("sectorsExpertise", v)} /></Field>
              <Field id="companySizes" label="Tamaño de empresa con el que mejor trabajas" help="Número de personas" error={err("companySizes")}><ChipSelect id="companySizes" options={opt(COMPANY_SIZES)} value={p.companySizes} onChange={(v) => set("companySizes", v)} /></Field>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field id="teamLeadership" label="Experiencia liderando equipos" error={err("teamLeadership")}><Select id="teamLeadership" value={p.teamLeadership} placeholder="Elige una opción" options={TEAM_LEADERSHIP} invalid={ia("teamLeadership")} onChange={(e) => set("teamLeadership", e.target.value)} /></Field>
                <Field id="tools" label="Herramientas y plataformas que dominas" optional help="Separadas por comas"><TextInput id="tools" value={p.tools} onChange={(e) => set("tools", e.target.value)} placeholder="HubSpot, Salesforce, GA4, Looker Studio" /></Field>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="aparecer grid gap-6">
              <Field id="availability" label="Disponibilidad actual">
                <div role="radiogroup" id="availability" className="grid gap-2 sm:grid-cols-2">
                  {(Object.keys(AVAILABILITY) as (keyof typeof AVAILABILITY)[]).map((k) => (
                    <button key={k} type="button" role="radio" aria-checked={p.availability === k} onClick={() => set("availability", k)}
                      className={`flex items-center justify-between rounded-[14px] border border-filo px-4 py-3 text-left ${p.availability === k ? "bg-[rgba(0,255,0,.28)] shadow-[0_8px_22px_-10px_rgba(0,230,0,.8)]" : "bg-white/60 hover:bg-white/90"}`}>
                      <AvailabilityDot value={k} />
                    </button>
                  ))}
                </div>
              </Field>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field id="availableFrom" label="Fecha estimada de incorporación" optional={p.availability !== "proximamente"} error={err("availableFrom")}><TextInput id="availableFrom" type="date" value={p.availableFrom} invalid={ia("availableFrom")} onChange={(e) => set("availableFrom", e.target.value)} /></Field>
                <Field id="dedication" label="Dedicación preferida" error={err("dedication")}><Select id="dedication" value={p.dedication} placeholder="Elige una opción" options={DEDICATIONS} invalid={ia("dedication")} onChange={(e) => set("dedication", e.target.value)} /></Field>
              </div>
              <Field id="collaboration" label="Tipo de colaboración" error={err("collaboration")}><ChipSelect id="collaboration" options={opt(COLLABORATIONS)} value={p.collaboration} onChange={(v) => set("collaboration", v)} /></Field>
              <Field id="workMode" label="Preferencia de trabajo" error={err("workMode")}><ChipSelect id="workMode" options={opt(WORK_MODES)} value={p.workMode} onChange={(v) => set("workMode", v)} /></Field>
              <Field id="preferredLocations" label="Ubicaciones preferidas" optional help="Para proyectos híbridos o presenciales"><TextInput id="preferredLocations" value={p.preferredLocations} onChange={(e) => set("preferredLocations", e.target.value)} placeholder="Madrid, Barcelona" /></Field>
              <div className="tarjeta tarjeta-roto flex flex-col gap-4">
                <div className="flex flex-wrap items-center gap-2"><span className="etiqueta">Tarifa mínima esperada</span><span className="tag bg-negro text-blanco">Privado</span></div>
                <p className="ayuda -mt-2">Solo la ve el equipo interno de Extandard. Nunca se publica.</p>
                <div className="grid gap-3 sm:grid-cols-3">
                  <Select id="rateType" aria-label="Tipo de tarifa" value={p.rateType} options={[{ value: "dia", label: "Por día" }, { value: "mes", label: "Por mes" }]} onChange={(e) => set("rateType", e.target.value as "dia" | "mes")} />
                  <TextInput id="rateMin" aria-label="Importe" type="number" inputMode="decimal" min={0} value={p.rateMin ?? ""} invalid={ia("rateMin")} onChange={(e) => set("rateMin", e.target.value === "" ? null : Number(e.target.value))} placeholder="Importe" />
                  <Select id="currency" aria-label="Moneda" value={p.currency} options={CURRENCIES} onChange={(e) => set("currency", e.target.value)} />
                </div>
                {err("rateMin") && <span className="error">{err("rateMin")}</span>}
              </div>
              <Field id="comments" label="Comentarios adicionales" optional><TextArea id="comments" value={p.comments} onChange={(e) => set("comments", e.target.value)} maxLength={800} /></Field>
            </div>
          )}

          {step === 4 && (
            <div className="aparecer flex flex-col gap-6">
              <ProfileSummary p={p} label={label} onEdit={(s) => setStep(s)} showPrivate />
              <label className={`flex items-start gap-3 rounded-[14px] border p-4 ${errors.consent ? "border-magenta" : "border-filo"}`}>
                <input id="consent" type="checkbox" className="mt-1 h-4 w-4 accent-black" checked={consent} onChange={(e) => { setConsent(e.target.checked); setErrors({}); }} />
                <span className="text-[14px]">Acepto la <button type="button" className="underline underline-offset-2" onClick={() => go({ name: "privacidad" })}>política de privacidad</button> y el tratamiento de mis datos para gestionar la red de talento de Extandard y recibir oportunidades profesionales que encajen con mi perfil.</span>
              </label>
              {errors.consent && <span className="error -mt-4">{errors.consent}</span>}
            </div>
          )}

          {/* Navegación del asistente */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-filo pt-5">
            <div className="flex gap-2">
              {step > 0 && <button className="btn btn-contorno" onClick={() => { setErrors({}); setStep(step - 1); scrollTop(); }} disabled={saving}><Arrow dir="izquierda" /> Anterior</button>}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {saving && <span className="cargando" aria-label="Guardando" />}
              {!submitted && step < 4 && <button className="btn btn-texto" onClick={saveLater} disabled={saving}>Guardar y seguir más tarde</button>}
              {submitted && step < 4 && <button className="btn btn-contorno" onClick={async () => { if (await save(step)) toast("Cambios guardados."); }} disabled={saving}>Guardar cambios</button>}
              {step < 4 && <button className="btn btn-verde" onClick={next} disabled={saving}>Siguiente <Arrow /></button>}
              {step === 4 && <button className="btn btn-verde" onClick={submit} disabled={saving}>{!submitted ? "Enviar y entrar en la red" : status === "info_solicitada" ? "Enviar la información" : "Guardar cambios"}</button>}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

/** Resumen del perfil, usado en la revisión, en "Mi perfil" y en el panel del equipo. */
export function ProfileSummary({ p, label, onEdit, showPrivate }: { p: Profile; label: (id: string) => string; onEdit?: (step: number) => void; showPrivate?: boolean }) {
  const block = (title: string, step: number, rows: [string, React.ReactNode, boolean?][]) => (
    <section className="flex flex-col gap-1">
      <div className="flex items-center justify-between gap-3 border-b border-filo pb-2">
        <h3 className="font-display text-[20px]">{title}</h3>
        {onEdit && <button className="btn btn-texto btn-sm" onClick={() => onEdit(step)}>Editar</button>}
      </div>
      <dl className="grid">
        {rows.filter(([, v, priv]) => (priv ? showPrivate : true) && v !== undefined).map(([k, v, priv]) => (
          <div key={k} className="grid gap-1 border-b-[0.5px] border-linea py-2.5 sm:grid-cols-[200px_1fr] sm:gap-4">
            <dt className="flex items-center gap-2 text-[13px] text-suave">{k}{priv && <span className="tag bg-negro text-blanco !text-[10px]">Privado</span>}</dt>
            <dd className="min-w-0 whitespace-pre-line break-words text-[14px]">{v || <span className="text-suave">—</span>}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
  const list = (ids: string[]) => (ids?.length ? ids.map(label).join(", ") : "");
  const ccy = (n: number | null, c: string, t: string) => (n ? `${n.toLocaleString("es-ES")} ${c} / ${t === "dia" ? "día" : "mes"}` : "");
  return (
    <div className="flex flex-col gap-8">
      {block("Información básica", 0, [
        ["Nombre", p.fullName], ["Correo", p.email, true], ["Ubicación", p.location], ["Zona horaria", p.timezone],
        ["LinkedIn", p.linkedin ? <a className="underline underline-offset-2" href={p.linkedin.startsWith("http") ? p.linkedin : `https://${p.linkedin}`} target="_blank" rel="noreferrer">{p.linkedin}</a> : ""],
        ["Web", p.website], ["Idiomas", p.languages.join(", ")],
      ])}
      {block("Experiencia", 1, [
        ["Titular", p.headline], ["Presentación", p.bio], ["Años de experiencia", p.years ? `${p.years}` : ""], ["Situación actual", p.currentRole],
        ["Trayectoria", p.experience.filter((x) => x.role || x.company).map((x) => `${x.role}${x.company ? ` · ${x.company}` : ""}${x.period ? ` (${x.period})` : ""}${x.summary ? `\n${x.summary}` : ""}`).join("\n\n")],
        ["Sectores", list(p.sectorsWorked)], ["Tipo de empresa", p.companyTypes.join(", ")], ["Logros", p.achievements],
      ])}
      {block("Especialización", 2, [
        ["Especialidades", list(p.specialties)], ["Sectores de especialización", list(p.sectorsExpertise)], ["Tamaño de empresa", p.companySizes.join(", ")],
        ["Liderazgo de equipos", p.teamLeadership], ["Herramientas", p.tools],
      ])}
      {block("Disponibilidad y preferencias", 3, [
        ["Disponibilidad", <AvailabilityDot value={p.availability} />], ["Incorporación", p.availableFrom], ["Dedicación", p.dedication],
        ["Colaboración", p.collaboration.join(", ")], ["Modalidad", p.workMode.join(", ")], ["Ubicaciones preferidas", p.preferredLocations],
        ["Tarifa mínima", ccy(p.rateMin, p.currency, p.rateType), true], ["Comentarios", p.comments, true],
      ])}
    </div>
  );
}

export function useCompleteness(p: Profile | null) { return useMemo(() => completeness(p), [p]); }
