import type React from "react";
import { AREAS, areaOf } from "./constants";
import { fmtDate } from "./db";

/** Datos mínimos que necesita la tarjeta ancha de oportunidad (vale para la ficha pública y la interna). */
export interface OppRowData {
  title: string;
  summary: string;
  client?: string | null;
  confidential?: boolean;
  specialties: string[];
  sector: string;
  companyType: string;
  dedication: string;
  collaboration: string;
  duration: string;
  startDate: string;
  workMode: string;
  location: string;
  deadline: string;
  rate?: string | null;
  demo?: boolean;
}

const fechaCorta = (iso: string) => (iso ? fmtDate(iso).replace(".", "") : "A convenir");

function Candado() {
  return <svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true"><path d="M4.5 7V5a3.5 3.5 0 0 1 7 0v2M3.5 7h9v7h-9z" fill="none" stroke="currentColor" strokeWidth="1.3" /></svg>;
}

/**
 * Tarjeta ancha de oportunidad: número y contexto en mono arriba, título, resumen y meta a la izquierda;
 * especialidades, fechas, tarifa y flecha a la derecha. Un solo resplandor del color del área principal.
 */
export function OppRow({ o, n, label, onClick, badge, extra, side }: {
  o: OppRowData; n: number; label: (id: string) => string; onClick?: () => void;
  /** Píldora arriba del todo (estado de la candidatura, «Encaja contigo», estado interno…). */
  badge?: React.ReactNode;
  /** Contenido adicional bajo la meta (contadores internos, acciones). */
  extra?: React.ReactNode;
  /** Sustituye la tarifa (por ejemplo, el rango interno). */
  side?: React.ReactNode;
}) {
  const area = AREAS[areaOf(o.specialties[0] ?? "otras")];
  const shown = o.specialties.slice(0, 3);
  const rest = o.specialties.length - shown.length;
  const contexto = [o.confidential || !o.client ? null : o.client, label(o.sector), o.companyType].filter(Boolean).join(" · ");
  return (
    <div onClick={onClick} role={onClick ? "button" : undefined} tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === e.currentTarget) { e.preventDefault(); onClick(); } } : undefined}
      className={`bento vidrio elevar group grid w-full gap-6 p-6 text-left md:grid-cols-[1fr_auto] md:p-7 ${onClick ? "cursor-pointer" : ""}`}>
      <span className={`glow ${area.glow} -right-16 -top-24 w-[300px] opacity-70`} aria-hidden="true" />
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5 font-mono text-[10.5px] uppercase tracking-[.07em] text-suave">
          <span className="text-negro">N.º {String(n).padStart(2, "0")}</span>
          <span aria-hidden="true">·</span>
          {(o.confidential || !o.client) && <span className="inline-flex items-center gap-1"><Candado /><span className="sr-only">Cliente confidencial ·</span></span>}
          <span>{contexto}</span>
          {o.demo && <span className="tag bg-blanco !py-1">Ficticio</span>}
          {badge}
        </div>
        <h3 className="max-w-[46ch] text-[19px] font-medium leading-[1.25] tracking-[-0.01em] transition-transform duration-300 group-hover:translate-x-0.5 md:text-[21px]">{o.title}</h3>
        <p className="line-clamp-2 max-w-[70ch] text-[14.5px] text-suave">{o.summary}</p>
        <p className="font-mono text-[10.5px] uppercase leading-[1.7] tracking-[.06em] text-suave">
          {[label(o.sector), o.companyType, o.dedication, o.collaboration, o.workMode, o.location].filter(Boolean).join(" · ")}
        </p>
        {extra}
      </div>
      <div className="flex flex-col items-start gap-4 md:min-w-[230px] md:items-end">
        <div className="flex flex-wrap gap-1.5 md:max-w-[260px] md:justify-end">
          {shown.map((s) => <span key={s} className="tag bg-blanco">{label(s)}</span>)}
          {rest > 0 && <span className="tag bg-blanco">+{rest}</span>}
        </div>
        <dl className="grid grid-cols-[auto_auto] gap-x-3 gap-y-0.5 font-mono text-[10.5px] uppercase tracking-[.06em] text-suave md:text-right">
          <dt>Inicio</dt><dd className="text-negro">{fechaCorta(o.startDate)}</dd>
          <dt>Duración</dt><dd className="text-negro">{o.duration || "—"}</dd>
          <dt>Plazo</dt><dd className="text-negro">{o.deadline ? fechaCorta(o.deadline) : "Abierto"}</dd>
        </dl>
        <div className="mt-auto flex w-full items-center justify-between gap-4 md:justify-end">
          {side ?? (o.rate ? <span className="tnum text-[15px] font-medium">{o.rate}</span> : <span className="tag bg-blanco">Tarifa a convenir</span>)}
          {onClick && (
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-negro text-verde transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true">
              <svg viewBox="0 0 16 16" width="13" height="13"><path d="M2 8h11M9 4l4 4-4 4" fill="none" stroke="currentColor" strokeWidth="1.6" /></svg>
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

/** Columna lateral de filtros en cristal (portal de oportunidades y directorio). */
export function Filtros({ children, onClear, active }: { children: React.ReactNode; onClear?: () => void; active?: boolean }) {
  return (
    <aside className="vidrio flex flex-col gap-4 self-start !rounded-[24px] p-4 lg:sticky lg:top-24" aria-label="Filtros">
      {children}
      {active && onClear && <button className="btn btn-texto btn-sm self-start" onClick={onClear}>Quitar filtros</button>}
    </aside>
  );
}

export function FiltroCampo({ id, label, children }: { id: string; label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[13px] font-medium">{label}</label>
      {children}
    </div>
  );
}

/** Cabecera de bloque: punto verde + etiqueta mono. */
export function Eyebrow({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <span className={`eyebrow inline-flex items-center gap-2 ${className}`}><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />{children}</span>;
}
