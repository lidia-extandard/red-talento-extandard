import { createContext, useContext } from "react";
import type { Session } from "./db";
import type { Catalog } from "./types";

export type View =
  | { name: "landing" } | { name: "publicas" } | { name: "privacidad" }
  | { name: "inicio" } | { name: "registro"; step?: number } | { name: "perfil" } | { name: "oportunidades" } | { name: "oportunidad"; id: string }
  | { name: "candidaturas" } | { name: "avisos" }
  | { name: "panel" } | { name: "talento"; filter?: string; uid?: string } | { name: "opps-admin" } | { name: "opp-edit"; id?: string }
  | { name: "pipeline"; oppId: string } | { name: "catalogo" } | { name: "actividad" };

export interface AppCtx {
  session: Session;
  catalog: Catalog;
  label: (id: string) => string;
  go: (v: View) => void;
  view: View;
  proMode: boolean;
  setProMode: (b: boolean) => void;
}

export const Ctx = createContext<AppCtx>(null as unknown as AppCtx);
export const useApp = () => useContext(Ctx);
