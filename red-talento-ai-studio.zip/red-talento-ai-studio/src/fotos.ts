/* Retratos ficticios generados con IA para los perfiles de ejemplo (marcados como «Ficticio»).
   En la versión real, la foto la sube cada profesional y solo la ven él y el equipo. */
import f0 from "./fotos/demo-01.jpg";
import f1 from "./fotos/demo-02.jpg";
import f2 from "./fotos/demo-03.jpg";
import f3 from "./fotos/demo-04.jpg";
import f4 from "./fotos/demo-05.jpg";
import f5 from "./fotos/demo-06.jpg";
import f6 from "./fotos/demo-07.jpg";
import f7 from "./fotos/demo-08.jpg";

export interface Foto { src: string; fondo: string }
export const FOTOS_DEMO: Record<string, Foto> = {
  "demo-01": { src: f0, fondo: "#80A4ED" },
  "demo-02": { src: f1, fondo: "#E7C05D" },
  "demo-03": { src: f2, fondo: "#A1D3EA" },
  "demo-04": { src: f3, fondo: "#F5BE7E" },
  "demo-05": { src: f4, fondo: "#6F93E3" },
  "demo-06": { src: f5, fondo: "#ECAAB4" },
  "demo-07": { src: f6, fondo: "#EDCA6B" },
  "demo-08": { src: f7, fondo: "#EFB4BA" },
};
/** Para los perfiles de ejemplo de la portada (mismo retrato que su perfil ficticio). */
export const FOTOS_POR_NOMBRE: Record<string, Foto> = {
  "Lucía Ferrer": FOTOS_DEMO["demo-01"], "Andrés Molina": FOTOS_DEMO["demo-02"], "Claire Dubois": FOTOS_DEMO["demo-03"],
  "Javier Sanz": FOTOS_DEMO["demo-04"], "Elena Rivas": FOTOS_DEMO["demo-05"], "Tomás Herrera": FOTOS_DEMO["demo-06"],
  "Nuria Castillo": FOTOS_DEMO["demo-07"], "Pablo Ortiz": FOTOS_DEMO["demo-08"],
};
