import type React from "react";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "./context";
import { ago, fmtDate, now, plain, rid, useNames } from "./db";
import type { Catalog, CatalogItem, ProfileStatus } from "./types";
import { APP_STATUS, AVAILABILITY, COLLABORATIONS, DEFAULT_CATALOG, LANGUAGES, OPP_STATUS, PROFILE_STATUS, STAGES, STAGE_TO_PUBLIC, isActive } from "./constants";
import { type AdminData, type Person, deletePersonData, saveInternal, setProfileStatus } from "./adminData";
import { Arrow, AvailabilityDot, Conector, DemoTag, Drawer, Empty, Field, LoadingBlock, Pager, PerfilCard, SectionHead, Select, Stat, StatusTag, TextArea, TextInput, useConfirm, useToast, Modal } from "./ui";
import { Page } from "./Pro";
import { ProfileSummary } from "./Wizard";
import { fit } from "./match";
import { FOTOS_DEMO } from "./fotos";
import { Eyebrow, FiltroCampo, Filtros } from "./OppRow";

const PRESETS: [string, string][] = [["", "Todos"], ["activos", "Activos"], ["nuevos", "Nuevos esta semana"], ["disponibles", "Disponibles"], ["info", "Información pedida"], ["borradores", "Borradores"], ["inactivos", "Inactivos"]];
function inPreset(p: Person, k: string) {
  switch (k) {
    case "activos": return isActive(p.status);
    case "nuevos": return !!p.submittedAt && new Date(p.submittedAt).getTime() > Date.now() - 7 * 864e5;
    case "disponibles": return isActive(p.status) && ["disponible", "proximamente"].includes(p.availability);
    case "info": return p.status === "info_solicitada";
    case "borradores": return p.status === "borrador";
    case "inactivos": return p.status === "inactivo";
    default: return true;
  }
}

declare global { interface Window { __extandardSeed?: () => Promise<number> } }
/** Solo en la versión con Firebase: carga los perfiles y oportunidades ficticios de ejemplo en una base vacía. */
function SeedCard() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <div className="bento vidrio mt-6 flex flex-wrap items-center justify-between gap-4 p-6">
      <span className="glow glow-verde -left-10 -top-16 w-[220px] opacity-50" aria-hidden="true" />
      <div className="flex max-w-[60ch] flex-col gap-1"><span className="font-medium">La base de datos está vacía</span><span className="text-[14px] text-suave">Carga 8 perfiles y 3 oportunidades marcados como ficticios para probar el panel. Puedes borrarlos después.</span></div>
      <button className="btn btn-verde" disabled={busy} onClick={async () => { setBusy(true); try { const n = await window.__extandardSeed!(); toast(`${n} documentos de ejemplo cargados.`); } catch { toast("No se han podido cargar los datos de ejemplo.", "error"); } finally { setBusy(false); } }}>Cargar datos de ejemplo <Arrow /></button>
    </div>
  );
}

/* ---------- Dashboard ---------- */
export function AdminDashboard({ d }: { d: AdminData }) {
  const { go, session } = useApp();
  const name = useNames(session.user, d.audits.slice(0, 12).map((a) => a.by));
  if (!d.ready) return <LoadingBlock label="Cargando la red" />;
  const week = Date.now() - 7 * 864e5;
  const pending = d.people.filter((p) => p.submittedAt && new Date(p.submittedAt).getTime() > week);
  const approved = d.people.filter((p) => isActive(p.status));
  const available = approved.filter((p) => p.availability === "disponible" || p.availability === "proximamente");
  const activeOpps = d.opps.filter((o) => o.status === "publicada");
  const newApps = d.applications.filter((a) => !a.withdrawn && a.stage === "nueva");
  const shortlisted = d.applications.filter((a) => !a.withdrawn && a.stage === "preseleccionada");
  const since = Date.now() - 30 * 864e5;
  const recent = d.people.filter((p) => new Date(p.createdAt).getTime() > since);
  const deletions = d.people.filter((p) => p.deletionRequestedAt);

  const tasks = [
    ...pending.map((p) => ({ k: `p-${p.uid}`, text: `Nuevo perfil en la red: ${p.fullName || "un profesional"}`, when: p.submittedAt, act: () => go({ name: "talento", uid: p.uid }) })),
    ...newApps.map((a) => {
      const p = d.people.find((x) => x.uid === a.uid);
      return { k: `a-${a.uid}-${a.oppId}`, text: `Nueva candidatura de ${p?.fullName || "un profesional"} a «${a.title}»`, when: a.appliedAt, act: () => go({ name: "pipeline", oppId: a.oppId }) };
    }),
    ...deletions.map((p) => ({ k: `d-${p.uid}`, text: `Solicitud de eliminación de datos: ${p.fullName || p.uid}`, when: p.deletionRequestedAt, act: () => go({ name: "talento", uid: p.uid }) })),
  ].sort((a, b) => ((b.when ?? "") > (a.when ?? "") ? 1 : -1));

  return (
    <Page>
      <SectionHead eyebrow="Panel del equipo" title="La red, hoy" text="Lo que necesita tu atención y cómo evoluciona la red de talento."
        actions={<><button className="btn btn-contorno" onClick={() => go({ name: "talento", filter: "disponibles" })}>Buscar talento disponible</button><button className="btn btn-verde" onClick={() => go({ name: "opp-edit" })}>Crear oportunidad <Arrow /></button></>} />

      {d.ready && d.people.length === 0 && d.opps.length === 0 && window.__extandardSeed && <SeedCard />}
      <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat color="celeste" value={d.people.length} label="Profesionales registrados" onClick={() => go({ name: "talento" })} />
        <Stat color="verde" value={pending.length} label="Perfiles nuevos esta semana" onClick={() => go({ name: "talento", filter: "nuevos" })} accent={pending.length > 0} />
        <Stat color="azul" value={approved.length} label="Perfiles activos" onClick={() => go({ name: "talento", filter: "activos" })} />
        <Stat color="amarillo" value={available.length} label="Disponibles ahora o próximamente" onClick={() => go({ name: "talento", filter: "disponibles" })} />
        <Stat color="celeste" value={activeOpps.length} label="Oportunidades publicadas" onClick={() => go({ name: "opps-admin" })} />
        <Stat color="verde" value={newApps.length} label="Candidaturas sin revisar" accent={newApps.length > 0} onClick={() => go({ name: "opps-admin" })} />
        <Stat color="magenta" value={shortlisted.length} label="Candidatos preseleccionados" onClick={() => go({ name: "opps-admin" })} />
        <Stat color="ambar" value={recent.length} label="Nuevos registros en 30 días" onClick={() => go({ name: "talento" })} />
      </div>

      <div className="mt-3 grid items-start gap-3 lg:grid-cols-5">
        <section className="bento tarjeta-roto flex flex-col gap-4 p-6 lg:col-span-3">
          <span className="glow glow-verde -left-16 -top-24 w-[260px] opacity-40" aria-hidden="true" />
          <h2 className="font-display text-[24px]">Tareas pendientes</h2>
          {tasks.length === 0 ? <p className="text-suave">No hay nada pendiente. Buen momento para publicar una oportunidad o revisar disponibilidades.</p> : (
            <ul>
              {tasks.slice(0, 8).map((t) => (
                <li key={t.k} className="border-b border-filo last:border-0">
                  <button className="fila group flex w-full items-center justify-between gap-4 px-3 py-3.5 text-left" onClick={t.act}>
                    <span className="flex min-w-0 items-center gap-3"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} /><span className="font-medium">{t.text}</span></span>
                    <span className="flex shrink-0 items-center gap-3 font-mono text-[11px] text-suave">{ago(t.when)}<Conector size={26} className="transition-transform group-hover:translate-x-0.5" /></span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {tasks.length > 8 && <p className="ayuda">Y {tasks.length - 8} más.</p>}
        </section>
        <section className="bento tarjeta-roto flex flex-col gap-4 p-6 lg:col-span-2">
          <span className="glow glow-celeste -bottom-40 -right-28 w-[340px] opacity-60" aria-hidden="true" />
          <div className="flex items-baseline justify-between"><h2 className="font-display text-[24px]">Actividad reciente</h2><button className="btn btn-texto btn-sm" onClick={() => go({ name: "actividad" })}>Ver todo</button></div>
          {d.audits.length === 0 ? <p className="text-suave">Aquí aparecerá cada cambio que haga el equipo: quién y cuándo.</p> : (
            <ul>
              {d.audits.slice(0, 7).map((a) => (
                <li key={a._id} className="fila flex flex-col gap-1 border-b border-filo px-3 py-3 last:border-0">
                  <span className="text-[14px]"><span className="font-medium">{a.action}</span> · {a.target}</span>
                  <span className="font-mono text-[11px] text-suave">{name(a.by)} · {ago(a.at)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </Page>
  );
}

/* ---------- Directorio de talento ---------- */
/** En el directorio el estado va en etiqueta neutra con un punto: el color de la tarjeta lo pone solo el área principal. */
const STATUS_DOT: Record<ProfileStatus, string> = { borrador: "#A9AEB8", enviado: "#00FF00", revision: "#00FF00", info_solicitada: "#FFD917", aprobado: "#00FF00", no_aceptado: "#0d1117", inactivo: "#A9AEB8" };
const PAGE = 12;
type Sort = "updated" | "name" | "years" | "availability";

export function Talent({ d, filter, openUid }: { d: AdminData; filter?: string; openUid?: string }) {
  const { catalog, label, go } = useApp();
  const [q, setQ] = useState("");
  const [f, setF] = useState({ availability: "", specialty: "", sector: "", location: "", timezone: "", minYears: "", collaboration: "", language: "", status: "", rateMax: "" });
  const [preset, setPreset] = useState(filter ?? "");
  const [sort, setSort] = useState<Sort>("updated");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState<string | null>(openUid ?? null);
  useEffect(() => { setPreset(filter ?? ""); setPage(1); }, [filter]);
  useEffect(() => { if (openUid) setOpen(openUid); }, [openUid]);

  const list = useMemo(() => {
    const avOrder = { disponible: 0, proximamente: 1, limitada: 2, no_disponible: 3 };
    return d.people
      .filter((p) => inPreset(p, preset))
      .filter((p) => !q || `${p.fullName} ${p.headline} ${p.email} ${p.tools} ${p.bio}`.toLowerCase().includes(q.toLowerCase()))
      .filter((p) => !f.availability || p.availability === f.availability)
      .filter((p) => !f.specialty || p.specialties.includes(f.specialty))
      .filter((p) => !f.sector || p.sectorsExpertise.includes(f.sector) || p.sectorsWorked.includes(f.sector))
      .filter((p) => !f.location || p.location.toLowerCase().includes(f.location.toLowerCase()))
      .filter((p) => !f.timezone || p.timezone === f.timezone)
      .filter((p) => !f.minYears || (p.years ?? 0) >= Number(f.minYears))
      .filter((p) => !f.collaboration || p.collaboration.includes(f.collaboration))
      .filter((p) => !f.language || p.languages.includes(f.language))
      .filter((p) => !f.status || p.status === f.status)
      .filter((p) => !f.rateMax || (p.rateMin != null && p.rateType === "dia" && p.rateMin <= Number(f.rateMax)))
      .sort((a, b) => sort === "name" ? a.fullName.localeCompare(b.fullName) : sort === "years" ? (b.years ?? 0) - (a.years ?? 0) : sort === "availability" ? avOrder[a.availability] - avOrder[b.availability] : b.updatedAt > a.updatedAt ? 1 : -1);
  }, [d.people, q, f, preset, sort]);
  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  const shown = list.slice((page - 1) * PAGE, page * PAGE);
  const person = d.people.find((p) => p.uid === open) ?? null;
  const upd = (k: keyof typeof f, v: string) => { setF({ ...f, [k]: v }); setPage(1); };
  const timezones = Array.from(new Set(d.people.map((p) => p.timezone).filter(Boolean)));
  const anyFilter = Object.values(f).some(Boolean) || q || preset;

  return (
    <Page>
      <SectionHead eyebrow="Base de datos de talento" title="Comunidad" text="Todos los profesionales de la red. Entran sin aprobación; aquí los buscas, filtras y valoras para cada oferta. Las tarifas solo las ve el equipo." />
      <div className="mt-6 flex flex-wrap gap-2">
        {PRESETS.map(([k, l]) => (
          <button key={k} className="chip" aria-pressed={preset === k} onClick={() => { setPreset(k); setPage(1); }}>{l}<span className="tnum text-suave">{d.people.filter((p) => inPreset(p, k)).length}</span></button>
        ))}
      </div>
      <div className="mt-6 grid items-start gap-5 lg:grid-cols-[260px_1fr]">
        <Filtros active={!!anyFilter} onClear={() => { setQ(""); setPreset(""); setF({ availability: "", specialty: "", sector: "", location: "", timezone: "", minYears: "", collaboration: "", language: "", status: "", rateMax: "" }); }}>
          <TextInput id="t-q" type="search" placeholder="Buscar talento" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Buscar talento" />
          <FiltroCampo id="t-av" label="Disponibilidad"><Select id="t-av" placeholder="Cualquiera" value={f.availability} onChange={(e) => upd("availability", e.target.value)} options={Object.entries(AVAILABILITY).map(([value, a]) => ({ value, label: a.label }))} /></FiltroCampo>
          <FiltroCampo id="t-sp" label="Especialidad"><Select id="t-sp" placeholder="Todas" value={f.specialty} onChange={(e) => upd("specialty", e.target.value)} options={catalog.specialties.map((s) => ({ value: s.id, label: s.label }))} /></FiltroCampo>
          <FiltroCampo id="t-se" label="Sector"><Select id="t-se" placeholder="Todos" value={f.sector} onChange={(e) => upd("sector", e.target.value)} options={catalog.sectors.map((s) => ({ value: s.id, label: s.label }))} /></FiltroCampo>
          <FiltroCampo id="t-yr" label="Experiencia"><Select id="t-yr" placeholder="Cualquiera" value={f.minYears} onChange={(e) => upd("minYears", e.target.value)} options={[["5", "5+ años"], ["10", "10+ años"], ["15", "15+ años"], ["20", "20+ años"]].map(([value, label]) => ({ value, label }))} /></FiltroCampo>
          <FiltroCampo id="t-co" label="Colaboración"><Select id="t-co" placeholder="Cualquiera" value={f.collaboration} onChange={(e) => upd("collaboration", e.target.value)} options={COLLABORATIONS} /></FiltroCampo>
          <FiltroCampo id="t-la" label="Idioma"><Select id="t-la" placeholder="Cualquiera" value={f.language} onChange={(e) => upd("language", e.target.value)} options={LANGUAGES} /></FiltroCampo>
          <FiltroCampo id="t-lo" label="Ubicación"><TextInput id="t-lo" placeholder="Ciudad o país" value={f.location} onChange={(e) => upd("location", e.target.value)} /></FiltroCampo>
          <FiltroCampo id="t-tz" label="Zona horaria"><Select id="t-tz" placeholder="Cualquiera" value={f.timezone} onChange={(e) => upd("timezone", e.target.value)} options={timezones} /></FiltroCampo>
          <FiltroCampo id="t-st" label="Estado del perfil"><Select id="t-st" placeholder="Cualquiera" value={f.status} onChange={(e) => upd("status", e.target.value)} options={(["aprobado", "info_solicitada", "borrador", "inactivo"] as ProfileStatus[]).map((value) => ({ value, label: PROFILE_STATUS[value].label }))} /></FiltroCampo>
          <FiltroCampo id="t-rate" label="Tarifa diaria máxima · solo equipo"><TextInput id="t-rate" type="number" min={0} placeholder="Ej. 900" value={f.rateMax} onChange={(e) => upd("rateMax", e.target.value)} /></FiltroCampo>
        </Filtros>
        <div className="flex min-w-0 flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Eyebrow>{list.length} {list.length === 1 ? "perfil" : "perfiles"}</Eyebrow>
            <label className="flex items-center gap-2 text-[13px]">Ordenar por
              <select className="entrada !w-auto !py-1.5 !text-[13px]" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
                <option value="updated">Última actualización</option><option value="name">Nombre</option><option value="years">Años de experiencia</option><option value="availability">Disponibilidad</option>
              </select>
            </label>
          </div>
          {!d.ready ? <LoadingBlock /> : list.length === 0 ? <Empty title="Ningún perfil coincide" text="Prueba a quitar filtros o a buscar por otra palabra." /> : (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {shown.map((p) => (
                <PerfilCard key={p.uid} onClick={() => setOpen(p.uid)} label={label}
                  p={toPerfil(p)}
                  badges={<>
                    <span className="tag bg-blanco"><span className="punto" style={{ background: STATUS_DOT[p.status], color: STATUS_DOT[p.status] }} />{PROFILE_STATUS[p.status].label}</span>
                    <span className="tag bg-blanco"><span className="punto" style={{ background: AVAILABILITY[p.availability].dot, color: AVAILABILITY[p.availability].dot }} />{AVAILABILITY[p.availability].label.replace("Disponibilidad ", "")}</span>
                    {p.demo && <DemoTag />}
                  </>}
                  footer={(d.dupes.has(p.uid) || p.deletionRequestedAt) ? <span className="flex gap-1.5">{d.dupes.has(p.uid) && <span className="tag bg-blanco">Posible duplicado</span>}{p.deletionRequestedAt && <span className="tag bg-blanco">Pide baja</span>}</span> : undefined} />
              ))}
            </div>
          )}
          <Pager page={page} pages={pages} onPage={setPage} />
        </div>
      </div>
      {person && <PersonDrawer d={d} person={person} onClose={() => { setOpen(null); if (openUid) go({ name: "talento", filter: preset || undefined }); }} />}
    </Page>
  );
}

/* ---------- Ficha del profesional ---------- */
export function PersonDrawer({ d, person, onClose }: { d: AdminData; person: Person; onClose: () => void }) {
  const { session, label, go } = useApp();
  const toast = useToast();
  const confirm = useConfirm();
  const [tab, setTab] = useState<"perfil" | "notas" | "candidaturas" | "encaje">("perfil");
  const [noteText, setNoteText] = useState("");
  const [tagText, setTagText] = useState("");
  const [infoOpen, setInfoOpen] = useState(false);
  const [infoNote, setInfoNote] = useState("");
  const [busy, setBusy] = useState(false);
  const by = session.uid ?? "equipo";
  const names = useNames(session.user, [...person.internal.notes.map((n) => n.by), ...(person.review?.history ?? []).map((h) => h.by)]);
  const db = session.db!;

  async function change(status: ProfileStatus, note?: string) {
    setBusy(true);
    try { await setProfileStatus(db, by, person, status, note); toast(`Perfil: ${PROFILE_STATUS[status].label}.`); } catch { toast("No se ha podido cambiar el estado.", "error"); } finally { setBusy(false); }
  }
  async function addNote() {
    if (!noteText.trim()) return;
    const data = plain(person.internal);
    data.notes = [{ id: rid(), text: noteText.trim(), by, at: now() }, ...(data.notes ?? [])];
    try { await saveInternal(db, person.uid, data); setNoteText(""); } catch { toast("No se ha podido guardar la nota.", "error"); }
  }
  async function setTags(tags: string[]) {
    const data = plain(person.internal); data.tags = tags;
    try { await saveInternal(db, person.uid, data); } catch { toast("No se han podido guardar las etiquetas.", "error"); }
  }
  async function setAvailability(v: string) {
    try { await db.doc(`profiles/${person.uid}`).update({ availability: v, updatedAt: now() }); toast("Disponibilidad actualizada."); } catch { toast("No se ha podido actualizar.", "error"); }
  }
  async function removeData() {
    const ok = await confirm.ask("Eliminar datos", `Se eliminarán el perfil, las candidaturas, el estado, las notas internas y los avisos de ${person.fullName || "este profesional"}. No se puede deshacer.`, "Eliminar definitivamente");
    if (!ok) return;
    await deletePersonData(db, by, person); toast("Datos eliminados."); onClose();
  }

  const apps = d.applications.filter((a) => a.uid === person.uid);
  const fits = d.opps.filter((o) => o.status === "publicada").map((o) => ({ o, f: fit(person, o, label, true) })).sort((a, b) => b.f.score - a.f.score);

  return (
    <Drawer open onClose={onClose}
      title={<div className="flex flex-col gap-1.5">
        <div className="flex flex-wrap items-center gap-2"><StatusTag {...PROFILE_STATUS[person.status]} />{person.demo && <DemoTag />}{d.dupes.has(person.uid) && <span className="tag bg-amarillo">Posible duplicado</span>}</div>
        <h2 className="font-display text-[28px] leading-tight">{person.fullName || "Sin nombre"}</h2>
        <p className="text-[14px] text-suave">{person.headline}</p>
      </div>}>
      {person.deletionRequestedAt && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-tarjeta border border-magenta p-4">
          <span className="text-[14px]">Solicitó la eliminación de sus datos el {fmtDate(person.deletionRequestedAt)}.</span>
          <button className="btn btn-negro btn-sm" onClick={removeData}>Tramitar eliminación</button>
        </div>
      )}
      {/* Acciones de revisión */}
      <div className="mb-6 flex flex-col gap-3 rounded-tarjeta bg-roto p-4">
        <span className="text-[13px] text-suave">{PROFILE_STATUS[person.status].hint}{person.submittedAt ? ` Enviado ${fmtDate(person.submittedAt)}.` : ""}</span>
        <div className="flex flex-wrap gap-2">
          {person.status === "aprobado" && <button className="btn btn-contorno btn-sm" disabled={busy} onClick={() => setInfoOpen(true)}>Pedir información</button>}
          {person.status === "info_solicitada" && <button className="btn btn-contorno btn-sm" disabled={busy} onClick={() => change("aprobado")}>Marcar como resuelto</button>}
          {isActive(person.status) && <button className="btn btn-contorno btn-sm" disabled={busy} onClick={() => change("inactivo")}>Pausar perfil</button>}
          {person.status === "inactivo" && <button className="btn btn-verde btn-sm" disabled={busy} onClick={() => change("aprobado")}>Reactivar <Arrow /></button>}
        </div>
        {!person.submittedAt ? <span className="ayuda">Este perfil aún es un borrador: entrará en la red cuando lo envíe.</span> : <span className="ayuda">Comunidad abierta: no hace falta aprobar perfiles. La valoración se hace en cada candidatura.</span>}
      </div>

      <div className="mb-6 flex gap-1 overflow-x-auto border-b border-filo" role="tablist">
        {([["perfil", "Perfil"], ["notas", `Notas y etiquetas (${person.internal.notes.length})`], ["candidaturas", `Candidaturas (${apps.length})`], ["encaje", "Encaje con oportunidades"]] as const).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`-mb-px whitespace-nowrap border-b-2 px-3 py-2.5 text-[14px] ${tab === k ? "border-filo font-medium" : "border-transparent text-suave hover:text-negro"}`}>{l}</button>
        ))}
      </div>

      {tab === "perfil" && (
        <div className="flex flex-col gap-6">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[13px] text-suave">Disponibilidad</span>
            <select className="entrada !w-auto !py-1.5 !text-[13px]" aria-label="Cambiar disponibilidad" value={person.availability} onChange={(e) => setAvailability(e.target.value)}>
              {Object.entries(AVAILABILITY).map(([k, a]) => <option key={k} value={k}>{a.label}</option>)}
            </select>
          </div>
          <ProfileSummary p={person} label={label} showPrivate />
          {(person.review?.history?.length ?? 0) > 0 && (
            <section className="flex flex-col gap-2">
              <h3 className="border-b border-filo pb-2 font-display text-[20px]">Historial de revisión</h3>
              <ul>{person.review!.history.slice().reverse().map((h, i) => <li key={i} className="border-b-[0.5px] border-linea py-2 text-[13px]"><span className="font-medium">{PROFILE_STATUS[h.status as ProfileStatus]?.label ?? h.status}</span> · {names(h.by)} · {fmtDate(h.at, true)}{h.note && <span className="block text-suave">«{h.note}»</span>}</li>)}</ul>
            </section>
          )}
          {person.deletionRequestedAt == null && <div className="border-t border-filo pt-4"><button className="btn btn-texto btn-sm !text-suave" onClick={removeData}>Eliminar todos sus datos</button></div>}
        </div>
      )}

      {tab === "notas" && (
        <div className="flex flex-col gap-8">
          <section className="flex flex-col gap-3">
            <h3 className="font-display text-[20px]">Etiquetas internas</h3>
            <div className="flex flex-wrap gap-2">
              {person.internal.tags.map((t) => <span key={t} className="chip chip-static">{t}<button className="ml-1" aria-label={`Quitar ${t}`} onClick={() => setTags(person.internal.tags.filter((x) => x !== t))}>✕</button></span>)}
              {!person.internal.tags.length && <span className="text-[13px] text-suave">Sin etiquetas.</span>}
            </div>
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); const t = tagText.trim(); if (t && !person.internal.tags.includes(t)) setTags([...person.internal.tags, t]); setTagText(""); }}>
              <TextInput id="tag-new" placeholder="Nueva etiqueta, p. ej. «Top SaaS»" value={tagText} onChange={(e) => setTagText(e.target.value)} />
              <button className="btn btn-contorno btn-sm">Añadir</button>
            </form>
          </section>
          <section className="flex flex-col gap-3">
            <h3 className="font-display text-[20px]">Notas privadas</h3>
            <TextArea id="note-new" placeholder="Solo las ve el equipo" value={noteText} onChange={(e) => setNoteText(e.target.value)} />
            <div><button className="btn btn-negro btn-sm" onClick={addNote} disabled={!noteText.trim()}>Guardar nota</button></div>
            <ul className="border-t border-filo">
              {person.internal.notes.map((n) => <li key={n.id} className="flex flex-col gap-1 border-b-[0.5px] border-filo py-3"><p className="whitespace-pre-line text-[14px]">{n.text}</p><span className="text-[12px] text-suave">{names(n.by)} · {fmtDate(n.at, true)}</span></li>)}
            </ul>
          </section>
        </div>
      )}

      {tab === "candidaturas" && (
        apps.length === 0 ? <p className="text-suave">No se ha presentado a ninguna oportunidad.</p> : (
          <ul className="border-t border-filo">
            {apps.map((a) => (
              <li key={a.oppId} className="border-b-[0.5px] border-filo">
                <button className="fila flex w-full flex-wrap items-center justify-between gap-3 px-3 py-3 text-left" onClick={() => go({ name: "pipeline", oppId: a.oppId })}>
                  <span className="min-w-0"><span className="block font-medium">{a.title}</span><span className="text-[12px] text-suave">Presentada {fmtDate(a.appliedAt)}</span></span>
                  <StatusTag {...(a.withdrawn ? APP_STATUS.retirada : APP_STATUS[STAGE_TO_PUBLIC[a.stage]])} />
                </button>
              </li>
            ))}
          </ul>
        )
      )}

      {tab === "encaje" && (
        <div className="flex flex-col gap-3">
          <p className="ayuda">Puntuación por reglas transparentes sobre las oportunidades publicadas: especialidades (40), sector (15), disponibilidad (15), tipo de empresa (10), dedicación (10), colaboración (5) y modalidad (5).</p>
          {fits.length === 0 ? <p className="text-suave">No hay oportunidades publicadas ahora mismo.</p> : fits.map(({ o, f }) => (
            <FitCard key={o.id} title={o.title} score={f.score} reasons={f.reasons} action={<button className="btn btn-contorno btn-sm" onClick={() => go({ name: "pipeline", oppId: o.id })}>Ver candidaturas</button>} />
          ))}
        </div>
      )}

      <Modal open={infoOpen} onClose={() => setInfoOpen(false)} title="Pedir información">
        <div className="flex flex-col gap-4">
          <Field id="info-note" label="Qué necesitas que complete o aclare" help="El profesional verá este mensaje en su área privada."><TextArea id="info-note" value={infoNote} onChange={(e) => setInfoNote(e.target.value)} /></Field>
          <div className="flex justify-end gap-2"><button className="btn btn-contorno" onClick={() => setInfoOpen(false)}>Cancelar</button><button className="btn btn-negro" disabled={!infoNote.trim()} onClick={async () => { await change("info_solicitada", infoNote.trim()); setInfoOpen(false); setInfoNote(""); }}>Enviar petición</button></div>
        </div>
      </Modal>
      {confirm.node}
    </Drawer>
  );
}

/** Encaje: cada criterio que coincide se enciende en los dos lados (oferta y perfil), unidos por una barra de degradado. */
export function FitCard({ title, score, reasons, action, sub }: { title: string; score: number; reasons: { ok: boolean | null; text: string }[]; action?: React.ReactNode; sub?: React.ReactNode }) {
  const top = score >= 70;
  return (
    <div className={`bento tarjeta-roto flex flex-col gap-4 !p-5 ${top ? "borde-conexion" : ""}`}>
      <span className={`glow ${top ? "glow-verde" : "glow-celeste"} -right-10 -top-14 w-[200px] ${top ? "opacity-70" : "opacity-40"}`} aria-hidden="true" />
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0"><h4 className="font-display text-[21px] leading-tight">{title}</h4>{sub}</div>
        <div className="flex items-center gap-3">
          <span className="flex items-baseline gap-1"><span className="font-display text-[38px] leading-none">{score}</span><span className="font-mono text-[11px] text-suave">/100</span></span>
          {action}
        </div>
      </div>
      <Criterios reasons={reasons} columns />
    </div>
  );
}

/** Criterios de encaje: los que coinciden unen oferta y perfil con una barra de degradado. */
export function Criterios({ reasons, columns }: { reasons: { ok: boolean | null; text: string }[]; columns?: boolean }) {
  return (
    <ul className={`grid gap-1 text-[12.5px] ${columns ? "lg:grid-cols-2" : ""}`}>
        {reasons.map((r, i) => (
          <li key={i} className={`flex items-center gap-2.5 rounded-full px-2.5 py-1.5 transition-colors duration-200 ${r.ok === true ? "bg-[rgba(0,255,0,.12)]" : ""}`}>
            <span aria-hidden="true" className="flex w-[54px] shrink-0 items-center">
              <span className="punto" style={{ background: r.ok === true ? "#43CCFF" : "rgba(10,20,40,.18)", color: r.ok === true ? "#43CCFF" : "transparent" }} />
              <span className="mx-0.5 h-[3px] flex-1 rounded-full" style={{ background: r.ok === true ? "linear-gradient(90deg,#43CCFF,#00FF00)" : r.ok === null ? "rgba(255,217,23,.6)" : "rgba(10,20,40,.08)" }} />
              <span className="punto" style={{ background: r.ok === true ? "#00FF00" : r.ok === null ? "#FFD917" : "rgba(10,20,40,.18)", color: r.ok === true ? "#00FF00" : "transparent" }} />
            </span>
            <span className={r.ok === false ? "text-suave" : ""}>{r.ok === true ? "Coincide · " : r.ok === false ? "No coincide · " : ""}{r.text}</span>
          </li>
        ))}
    </ul>
  );
}

/** Datos de tarjeta a partir de un perfil. */
export function toPerfil(p: Person) {
  return { name: p.fullName || "Sin nombre", headline: p.headline, specialties: p.specialties, years: p.years, sector: p.sectorsExpertise[0] ?? p.sectorsWorked[0] ?? "", dedication: p.dedication, availability: p.availability, place: [p.workMode[0], p.location.split(",")[0]].filter(Boolean).join(" · "), foto: FOTOS_DEMO[p.uid] };
}

/* ---------- Catálogo ---------- */
export function CatalogAdmin() {
  const { session, catalog } = useApp();
  const toast = useToast();
  const [draft, setDraft] = useState<Catalog>(plain(catalog));
  const [busy, setBusy] = useState(false);
  useEffect(() => setDraft(plain(catalog)), [catalog]);
  const dirty = JSON.stringify(draft) !== JSON.stringify(catalog);
  async function save() {
    if (!session.db) return;
    setBusy(true);
    try { await session.db.doc("config/catalog").set(plain(draft) as unknown as Record<string, unknown>); toast("Catálogo guardado."); } catch { toast("No se ha podido guardar.", "error"); } finally { setBusy(false); }
  }
  const col = (key: "specialties" | "sectors", title: string) => {
    const list = draft[key];
    const setList = (l: CatalogItem[]) => setDraft({ ...draft, [key]: l });
    return (
      <section className="flex min-w-0 flex-col gap-3">
        <h2 className="border-b border-filo pb-2 font-display text-[22px]">{title}</h2>
        <ul className="flex flex-col gap-2">
          {list.map((it, i) => (
            <li key={it.id} className="flex items-center gap-2">
              <TextInput id={`${key}-${it.id}`} aria-label={`Nombre de ${it.label}`} value={it.label} className={it.archived ? "!text-suave line-through" : ""} onChange={(e) => setList(list.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} />
              <button className="btn btn-contorno btn-sm" onClick={() => setList(list.map((x, j) => (j === i ? { ...x, archived: !x.archived } : x)))}>{it.archived ? "Recuperar" : "Ocultar"}</button>
            </li>
          ))}
        </ul>
        <div><button className="btn btn-texto btn-sm" onClick={() => setList([...list, { id: `${key.slice(0, 3)}-${rid()}`, label: "Nueva opción" }])}>Añadir opción</button></div>
      </section>
    );
  };
  return (
    <Page>
      <SectionHead eyebrow="Configuración" title="Especialidades y sectores" text="Lo que los profesionales eligen al registrarse. Ocultar una opción la quita del registro sin borrarla de los perfiles que ya la tienen."
        actions={<button className="btn btn-verde" disabled={!dirty || busy} onClick={save}>Guardar cambios</button>} />
      <div className="mt-8 grid gap-10 lg:grid-cols-2">{col("specialties", "Especialidades")}{col("sectors", "Sectores")}</div>
      {JSON.stringify(catalog) === JSON.stringify(DEFAULT_CATALOG) && <p className="ayuda mt-6">Estás viendo el catálogo inicial. Se guardará en la base de datos la primera vez que lo modifiques.</p>}
    </Page>
  );
}

/* ---------- Actividad ---------- */
export function Activity({ d }: { d: AdminData }) {
  const { session } = useApp();
  const names = useNames(session.user, d.audits.map((a) => a.by));
  const [page, setPage] = useState(1);
  const pages = Math.max(1, Math.ceil(d.audits.length / 25));
  return (
    <Page>
      <SectionHead eyebrow="Registro de auditoría" title="Historial de cambios" text="Cada acción del equipo sobre perfiles, oportunidades y candidaturas: quién la hizo y cuándo." />
      <div className="mt-8">
        {d.audits.length === 0 ? <Empty title="Sin actividad todavía" text="Cuando el equipo apruebe un perfil, publique una oportunidad o mueva una candidatura, quedará registrado aquí." /> : (
          <div className="overflow-x-auto">
            <table className="tabla min-w-[640px]">
              <thead><tr><th>Cuándo</th><th>Acción</th><th>Sobre</th><th>Quién</th></tr></thead>
              <tbody>{d.audits.slice((page - 1) * 25, page * 25).map((a) => <tr key={a._id}><td className="tnum whitespace-nowrap text-[13px]">{fmtDate(a.at, true)}</td><td className="font-medium">{a.action}{a.detail && !a.detail.startsWith("u_") && !a.detail.startsWith("demo") && <span className="block text-[13px] font-normal text-suave">{a.detail}</span>}</td><td>{a.target}</td><td className="text-[13px]">{names(a.by)}</td></tr>)}</tbody>
            </table>
          </div>
        )}
        <Pager page={page} pages={pages} onPage={setPage} />
      </div>
    </Page>
  );
}

export { STAGES, OPP_STATUS };
