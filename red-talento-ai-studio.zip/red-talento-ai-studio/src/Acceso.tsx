import { useState } from "react";
import { Arrow, Field, TextInput } from "./ui";

/** Acceso real (solo existe cuando la app corre con Firebase; en la demo de Claude no hay). */
export interface AuthNS {
  current(): { email: string; verified: boolean; name: string } | null;
  signIn(email: string, password: string): Promise<void>;
  signUp(email: string, password: string, name: string): Promise<void>;
  google(): Promise<void>;
  reset(email: string): Promise<void>;
  resendVerification(): Promise<void>;
  signOut(): Promise<void>;
}
declare global { interface Window { __extandardAuth?: AuthNS } }
export const authNS = (): AuthNS | null => (typeof window !== "undefined" ? window.__extandardAuth ?? null : null);

const ERR: Record<string, string> = {
  "auth/invalid-credential": "El correo o la contraseña no son correctos.",
  "auth/wrong-password": "El correo o la contraseña no son correctos.",
  "auth/user-not-found": "No hay ninguna cuenta con ese correo.",
  "auth/email-already-in-use": "Ya existe una cuenta con ese correo. Entra con tu contraseña.",
  "auth/weak-password": "La contraseña debe tener al menos 8 caracteres.",
  "auth/invalid-email": "Escribe un correo válido.",
  "auth/too-many-requests": "Demasiados intentos. Espera unos minutos y vuelve a probar.",
  "auth/popup-closed-by-user": "Has cerrado la ventana de Google antes de terminar.",
  "auth/operation-not-allowed": "Este método de acceso no está activado en Firebase.",
};
const msg = (e: unknown) => ERR[(e as { code?: string })?.code ?? ""] ?? "No se ha podido completar el acceso. Inténtalo de nuevo.";

function Google() {
  return <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 0 1-2.4 3.6v3h3.9c2.2-2.1 3.5-5.1 3.5-8.8Z" /><path fill="#34A853" d="M12 24c3.2 0 6-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2-3.1 0-5.7-2.1-6.6-4.9h-4v3.1A12 12 0 0 0 12 24Z" /><path fill="#FBBC05" d="M5.4 14.4a7.2 7.2 0 0 1 0-4.7V6.6h-4a12 12 0 0 0 0 10.9l4-3.1Z" /><path fill="#EA4335" d="M12 4.8c1.7 0 3.3.6 4.6 1.8l3.4-3.4A12 12 0 0 0 1.4 6.6l4 3.1C6.3 6.9 8.9 4.8 12 4.8Z" /></svg>;
}

export default function Acceso({ auth, initial = "entrar" }: { auth: AuthNS; initial?: "entrar" | "crear" }) {
  const [mode, setMode] = useState<"entrar" | "crear" | "recuperar">(initial);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [busy, setBusy] = useState(false);
  const run = async (f: () => Promise<void>, after?: string) => {
    setErr(""); setOk(""); setBusy(true);
    try { await f(); if (after) setOk(after); else window.location.reload(); } catch (e) { setErr(msg(e)); } finally { setBusy(false); }
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr("Escribe un correo válido.");
    if (mode === "recuperar") return run(() => auth.reset(email), "Te hemos enviado un correo para cambiar la contraseña.");
    if (pw.length < 8) return setErr("La contraseña debe tener al menos 8 caracteres.");
    if (mode === "crear") return run(() => auth.signUp(email, pw, name.trim()));
    return run(() => auth.signIn(email, pw));
  };
  return (
    <div className="flex flex-col gap-5">
      {mode !== "recuperar" && (
        <div className="flex gap-1 rounded-full bg-white/60 p-1 text-[13px]" role="tablist">
          {(["entrar", "crear"] as const).map((m) => (
            <button key={m} role="tab" aria-selected={mode === m} className={`flex-1 rounded-full px-3 py-2 transition-colors ${mode === m ? "bg-negro text-blanco" : ""}`} onClick={() => { setMode(m); setErr(""); }}>
              {m === "entrar" ? "Entrar" : "Crear cuenta"}
            </button>
          ))}
        </div>
      )}
      {mode !== "recuperar" && (
        <>
          <button className="btn btn-contorno w-full" disabled={busy} onClick={() => run(() => auth.google())}><Google /> Continuar con Google</button>
          <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[.08em] text-suave"><span className="h-px flex-1 bg-filo" />o con tu correo<span className="h-px flex-1 bg-filo" /></div>
        </>
      )}
      <form className="flex flex-col gap-4" onSubmit={submit} noValidate>
        {mode === "crear" && <Field id="acc-name" label="Nombre y apellidos"><TextInput id="acc-name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></Field>}
        <Field id="acc-email" label="Correo electrónico"><TextInput id="acc-email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        {mode !== "recuperar" && <Field id="acc-pw" label="Contraseña" help={mode === "crear" ? "Mínimo 8 caracteres." : undefined}><TextInput id="acc-pw" type="password" autoComplete={mode === "crear" ? "new-password" : "current-password"} value={pw} onChange={(e) => setPw(e.target.value)} /></Field>}
        {err && <p className="text-[13.5px] text-[#c4005f]" role="alert">{err}</p>}
        {ok && <p className="text-[13.5px]" role="status">{ok}</p>}
        <button className="btn btn-verde w-full" disabled={busy} type="submit">{mode === "entrar" ? "Entrar" : mode === "crear" ? "Crear cuenta y unirme" : "Enviar enlace"} <Arrow /></button>
      </form>
      <div className="flex justify-between text-[13px]">
        {mode === "recuperar"
          ? <button className="underline underline-offset-4" onClick={() => setMode("entrar")}>Volver a entrar</button>
          : <button className="underline underline-offset-4" onClick={() => { setMode("recuperar"); setErr(""); }}>¿Has olvidado tu contraseña?</button>}
        {mode === "crear" && <span className="text-suave">Te enviaremos un correo de verificación.</span>}
      </div>
    </div>
  );
}
