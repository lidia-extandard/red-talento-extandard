import type React from "react";
import { useEffect, useRef, useState } from "react";
import { useApp } from "./context";
import { AREAS, type AreaId } from "./constants";
import { FOTOS_POR_NOMBRE } from "./fotos";
import { Arrow, Conector, Isotipo, LoadingBlock, Logo, Modal, PerfilCard, Proceso, type PerfilData } from "./ui";
import { useCollection } from "./db";
import type { BoardItem } from "./types";
import { Eyebrow, OppRow } from "./OppRow";
import Acceso, { authNS } from "./Acceso";

const FAQ = [
  ["¿Qué es un Fractional CMO?", "Un director o directora de marketing que trabaja con una empresa a tiempo parcial: unos días al mes o a la semana, con responsabilidad real sobre la estrategia y el equipo, sin ser una incorporación a tiempo completo."],
  ["¿Necesito aprobación para entrar en la red?", "No. Tu perfil entra en la comunidad en cuanto lo envías y ya puedes ver y presentarte a las oportunidades. Lo que valoramos es cada candidatura: para cada proyecto decidimos si tu perfil encaja."],
  ["¿Tiene coste formar parte de la red?", "No. Registrarte y mantener tu perfil es gratuito. Las condiciones económicas de cada proyecto se acuerdan contigo antes de empezar."],
  ["¿Quién ve mis datos?", "Solo el equipo interno de Extandard. Tu tarifa es privada y nunca se publica. Los demás profesionales de la red no pueden ver tu perfil."],
  ["¿Cómo sé si encajo en una oferta?", "Cuando te presentas, el equipo revisa tu candidatura y la mueve por el proceso: en revisión, preseleccionada, entrevista. Ves cada cambio en tu área privada y te avisamos allí."],
  ["¿Me comprometo a algo al entrar?", "No. Tú decides a qué oportunidades te presentas y puedes marcarte como no disponible cuando quieras."],
  ["¿Puedo pausar mi perfil o eliminar mis datos?", "Sí. Desde tu perfil puedes cambiar tu disponibilidad o solicitar la eliminación de tus datos, y el equipo la tramitará."],
];

/** Perfiles de ejemplo (ficticios) para mostrar cómo se ve la red. */
const EJEMPLOS: PerfilData[] = [
  { name: "Lucía Ferrer", headline: "", quote: "Ordeno el go to market de SaaS que pasan a venta consultiva.", specialties: ["gtm", "demanda", "saas", "b2b"], years: 16, sector: "fintech", dedication: "1 día/sem", place: "Remoto · Madrid" },
  { name: "Claire Dubois", headline: "", quote: "Traduzco producto a mensajes que venden en varios mercados.", specialties: ["product", "internacional", "posicionamiento"], years: 14, sector: "rrhh", dedication: "Días/mes", place: "Híbrido · Barcelona" },
  { name: "Andrés Molina", headline: "", quote: "Mido bien antes de escalar la adquisición.", specialties: ["ecommerce", "growth", "performance"], years: 11, sector: "retail", dedication: "Varios días", place: "Remoto · Valencia" },
  { name: "Elena Rivas", headline: "", quote: "Entro en momentos de cambio y dejo el área funcionando.", specialties: ["estrategia", "equipos", "posicionamiento"], years: 19, sector: "salud", dedication: "Interina", place: "Híbrido · Bilbao" },
  { name: "Javier Sanz", headline: "", quote: "Pongo orden en CRM, scoring y automatización.", specialties: ["mops", "crm", "b2b"], years: 9, sector: "industria", dedication: "Varios días", place: "Remoto · Sevilla" },
  { name: "Tomás Herrera", headline: "", quote: "Programas de ABM y demanda para mid-market.", specialties: ["demanda", "performance", "saas"], years: 8, sector: "saas", dedication: "Flexible", place: "Remoto · CDMX" },
  { name: "Nuria Castillo", headline: "", quote: "La marca como herramienta de negocio en consumo.", specialties: ["b2c", "posicionamiento", "estrategia"], years: 12, sector: "turismo", dedication: "Días/mes", place: "Híbrido · Madrid" },
].map((p) => ({ ...p, foto: FOTOS_POR_NOMBRE[p.name] }));

/** Carrusel continuo de derecha a izquierda; la central más grande y nítida, se detiene al pasar el cursor, arrastre en móvil. */
function Carrusel({ items, label }: { items: PerfilData[]; label: (id: string) => string }) {
  const wrap = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const state = useRef({ x: 0, paused: false, drag: false, lastX: 0, w: 0 });
  useEffect(() => {
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    let raf = 0, last = performance.now();
    const loop = (t: number) => {
      const st = state.current, el = track.current, box = wrap.current;
      if (el && box) {
        const half = el.scrollWidth / 2;
        if (!st.paused && !st.drag && !reduce) st.x -= (t - last) * 0.035;
        if (st.x <= -half) st.x += half;
        if (st.x > 0) st.x -= half;
        el.style.transform = `translate3d(${st.x}px,0,0)`;
        const c = box.getBoundingClientRect(); const mid = c.left + c.width / 2;
        for (const card of Array.from(el.children) as HTMLElement[]) {
          const r = card.getBoundingClientRect();
          const d = Math.min(1, Math.abs(r.left + r.width / 2 - mid) / (c.width * 0.55));
          card.style.transform = `scale(${1.06 - d * 0.16})`;
          card.style.filter = `blur(${(d * d * 3.5).toFixed(2)}px)`;
          card.style.opacity = String(1 - d * 0.35);
          card.style.zIndex = String(Math.round((1 - d) * 10));
        }
      }
      last = t; raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  const s = state.current;
  return (
    <div ref={wrap} className="relative overflow-hidden py-10 [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]"
      onMouseEnter={() => (s.paused = true)} onMouseLeave={() => (s.paused = false)}
      onPointerDown={(e) => { s.drag = true; s.lastX = e.clientX; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); }}
      onPointerMove={(e) => { if (!s.drag) return; s.x += e.clientX - s.lastX; s.lastX = e.clientX; }}
      onPointerUp={() => (s.drag = false)} onPointerCancel={() => (s.drag = false)}
      style={{ touchAction: "pan-y", cursor: "grab" }} aria-label="Perfiles de ejemplo de la red" role="region">
      <div ref={track} className="flex w-max gap-5 will-change-transform">
        {[...items, ...items].map((p, i) => (
          <div key={i} className="w-[250px] shrink-0 transition-[filter] sm:w-[270px]" aria-hidden={i >= items.length || undefined}>
            <PerfilCard p={p} label={label} badges={<><span className="tag bg-blanco"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />Disponible</span><span className="tag bg-blanco">Ficticio</span></>} />
          </div>
        ))}
      </div>
    </div>
  );
}

/** Composición en abanico: tarjetas superpuestas y rotadas con etiquetas de expertise flotando encima. */
function Abanico({ label }: { label: (id: string) => string }) {
  const cards = [EJEMPLOS[1], EJEMPLOS[3], EJEMPLOS[0]];
  const pos = [{ r: -9, x: "2%", y: 46 }, { r: 0, x: "25%", y: 0 }, { r: 8, x: "47%", y: 50 }];
  const tags: [string, AreaId, string, string][] = [["Go-to-market", "estrategia", "4%", "6%"], ["Growth", "demanda", "78%", "4%"], ["CRM", "operaciones", "-2%", "70%"], ["Ecommerce", "consumo", "74%", "80%"]];
  return (
    <div className="relative mx-auto h-[500px] w-full max-w-[540px]" aria-hidden="true">
      <span className="glow glow-celeste left-[10%] top-[6%] w-[70%] opacity-70" />
      <span className="glow glow-magenta bottom-[4%] right-[0%] w-[40%] opacity-40" />
      {cards.map((p, i) => (
        <div key={p.name} className="abanico absolute w-[50%] min-w-[220px]" style={{ left: pos[i].x, top: pos[i].y, transform: `rotate(${pos[i].r}deg)`, animationDelay: `${i * 0.1}s`, zIndex: i === 1 ? 3 : 1 }}>
          <PerfilCard p={p} label={label} highlight={i === 1}
            badges={i === 1 ? <><span className="tag bg-blanco"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />Disponible</span><span className="tag bg-blanco">Ficticio</span></> : undefined} />
        </div>
      ))}
      {tags.map(([t, a, l, top], i) => (
        <span key={t} className="tag etiqueta-entra absolute z-10 shadow-flotante" style={{ left: l, top, background: `color-mix(in srgb, ${AREAS[a].color} 26%, white)`, borderColor: `color-mix(in srgb, ${AREAS[a].color} 40%, white)`, transform: `rotate(${[-7, 6, 5, -5][i]}deg)`, animationDelay: `${0.35 + i * 0.08}s` }}>
          <span className="punto" style={{ background: AREAS[a].color, color: AREAS[a].color }} />{t}
        </span>
      ))}
    </div>
  );
}

function MiniPaso({ i }: { i: number }) {
  if (i === 0) return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-1.5">{[1, 1, 1, 0, 0].map((on, k) => <span key={k} className="h-1.5 flex-1 rounded-full" style={{ background: on ? "linear-gradient(90deg,#43CCFF,#00FF00)" : "rgba(10,20,40,.08)" }} />)}</div>
      <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[.07em] text-suave"><span>Paso 3 de 5</span><span className="inline-flex items-center gap-1.5"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />Guardado</span></div>
    </div>
  );
  if (i === 1) return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="tag bg-verde"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />Perfil activo</span>
      <span className="tag bg-blanco">Sin aprobación</span>
    </div>
  );
  if (i === 2) return (
    <div className="flex items-center justify-between gap-2 rounded-full bg-white/80 py-1.5 pl-4 pr-1.5 shadow-frio">
      <span className="truncate font-mono text-[10.5px] uppercase tracking-[.06em]">CMO · SaaS B2B</span>
      <span className="rounded-full bg-verde px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.06em]">Presentarme</span>
    </div>
  );
  return (
    <div className="flex items-center gap-2">
      <span className="tag bg-celeste">En revisión</span>
      <span className="h-[2px] flex-1 rounded-full" style={{ background: "linear-gradient(90deg,#43CCFF,#00FF00)" }} />
      <span className="tag bg-verde">Preseleccionada</span>
    </div>
  );
}

const PASOS: [string, string][] = [
  ["Crea tu perfil", "Un asistente en cinco pasos cortos. Puedes guardarlo y seguir más tarde."],
  ["Entra en la comunidad", "Tu perfil queda activo en cuanto lo envías. Sin aprobación previa ni coste."],
  ["Preséntate", "Elige las oportunidades que encajan contigo y cuéntanos por qué en un mensaje breve."],
  ["Valoramos cada candidatura", "Para cada proyecto el equipo decide si encajas y sigues el estado en tu área privada."],
];

const BUSCAMOS: [string, string, string][] = [
  ["Fractional CMOs", "Parcial · recurrente", "Dirigen el marketing de varias compañías a tiempo parcial y de forma recurrente."],
  ["Directores y directoras de marketing", "Dirección · presupuesto", "Han liderado la función, el presupuesto y el equipo, en contacto directo con dirección general."],
  ["Especialistas senior", "Especialidad · estrategia", "Go-to-market, posicionamiento, growth, product marketing, demanda, CRM o marketing ops con visión estratégica."],
  ["Líderes interinos", "Transición · ejecutivo", "Asumen la dirección del área durante una transición, una expansión o una reestructuración."],
];
const PROYECTOS: [string, string, string][] = [
  ["Fractional CMO recurrente", "Semanal o mensual", "Dirección de marketing continuada, con una dedicación parcial estable."],
  ["Proyecto cerrado", "Acotado en el tiempo", "Un objetivo acotado: un lanzamiento, un plan de go-to-market o una auditoría."],
  ["Dirección interina", "Temporal · ejecutiva", "La dirección del área durante un periodo concreto, con más dedicación."],
  ["Asesoramiento estratégico", "Puntual", "Acompañamiento puntual a dirección general o al equipo en decisiones clave."],
];

function Lista({ eyebrow, title, text, rows, glow }: { eyebrow: string; title: string; text: string; rows: [string, string, string][]; glow: string }) {
  return (
    <div className="bento vidrio flex flex-col gap-2 !rounded-[28px] p-7 md:p-9">
      <span className={`glow ${glow} -right-20 -top-28 w-[320px] opacity-60`} aria-hidden="true" />
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="mt-2 font-display text-[34px] leading-[1.02] tracking-[-0.01em] md:text-[40px]">{title}</h2>
      <p className="mb-4 max-w-[52ch] text-[14.5px] text-suave">{text}</p>
      {rows.map(([t, m, d]) => (
        <div key={t} className="fila flex flex-col gap-1 border-t border-filo px-3 py-4 sm:flex-row sm:items-start sm:justify-between sm:gap-6">
          <div className="flex max-w-[44ch] flex-col gap-1">
            <span className="text-[15px] font-medium">{t}</span>
            <span className="text-[13.5px] leading-snug text-suave">{d}</span>
          </div>
          <span className="shrink-0 pt-1 font-mono text-[10px] uppercase tracking-[.08em] text-suave">{m}</span>
        </div>
      ))}
    </div>
  );
}

/** Manchas de color repartidas a lo largo de la página (además de la atmósfera fija). */
function Lavado() {
  const m: [string, string, string, string][] = [
    ["glow-celeste", "-8%", "14%", "720px"], ["glow-amarillo", "62%", "22%", "620px"], ["glow-magenta", "70%", "34%", "520px"],
    ["glow-verde-suave", "-6%", "44%", "620px"], ["glow-celeste", "58%", "52%", "700px"], ["glow-amarillo", "8%", "64%", "640px"],
    ["glow-azul", "66%", "72%", "620px"], ["glow-verde-suave", "20%", "84%", "700px"], ["glow-celeste", "-10%", "92%", "620px"],
  ];
  return (
    <div className="pointer-events-none absolute inset-0 -z-[5] overflow-hidden" aria-hidden="true">
      {m.map(([c, l, t, w], i) => <span key={i} className={`glow ${c} opacity-60`} style={{ left: l, top: t, width: w, filter: "blur(60px)" }} />)}
    </div>
  );
}

export function irA(id: string) {
  setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }), 40);
}

export default function Landing() {
  const { session, go, setProMode, label } = useApp();
  const [gate, setGate] = useState(false);
  const board = useCollection<BoardItem>(session.db, session.db ? "board" : null);
  const ultimas = board.items.filter((b) => b.status === "publicada").sort((a, b) => (b.publishedAt > a.publishedAt ? 1 : -1)).slice(0, 3);
  const join = () => {
    if (session.role === "equipo") { setProMode(true); go({ name: "registro" }); }
    else if (session.role === "profesional") go({ name: "registro" });
    else setGate(true);
  };
  const discover = () => { if (session.role === "equipo") { setProMode(true); go({ name: "oportunidades" }); } else go({ name: session.role === "profesional" ? "oportunidades" : "publicas" }); };
  const abrir = (id: string) => { if (session.role === "equipo") { setProMode(true); go({ name: "oportunidad", id }); } else go({ name: "oportunidad", id }); };

  return (
    <div className="relative isolate overflow-x-clip">
      <Lavado />
      {/* Hero */}
      <section className="gutter relative">
        <div className="mx-auto flex max-w-contenido flex-col items-center pt-16 text-center md:pt-24">
          <span className="vidrio inline-flex items-center gap-2 !rounded-full px-4 py-2 font-mono text-[10.5px] uppercase tracking-[.08em]">
            <span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />Red de talento · The Fractional CMO Company
          </span>
          <h1 className="mt-8 max-w-[15ch] font-display text-[46px] leading-[1.04] tracking-[-0.03em] sm:text-[70px] lg:text-[92px]">
            Conectamos <span className="capsula">talento</span> estratégico con proyectos que generan <span className="capsula capsula-b">impacto</span>
          </h1>
          <p className="mt-7 max-w-[54ch] text-[16px] leading-[1.55] text-suave sm:text-[17px]">
            Forma parte de una red seleccionada de Fractional CMOs y líderes de marketing. Descubre oportunidades alineadas con tu experiencia, especialización y disponibilidad.
          </p>
          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <button className="btn btn-verde text-[16px]" onClick={join}>Quiero formar parte de la red <Arrow /></button>
            <button className="btn btn-contorno text-[16px]" onClick={discover}>Descubrir oportunidades <Arrow /></button>
          </div>
          <div className="mt-12 flex max-w-full items-center rounded-full p-1.5 shadow-[0_18px_40px_-18px_rgba(0,160,120,.6)]" style={{ background: "linear-gradient(90deg,#43CCFF,#00FF00)" }} aria-label="Empresa, encaje, Fractional CMO">
            <span className="flex items-center gap-2 rounded-full bg-white/90 px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[.08em]"><span className="punto" style={{ background: "#0B70FE", color: "#0B70FE" }} />Empresa</span>
            <span className="flex items-center gap-2 px-3 font-mono text-[10.5px] uppercase tracking-[.08em] sm:px-6">
              <span className="hidden sm:inline">Encaje</span><Conector size={30} />
            </span>
            <span className="flex items-center gap-2 rounded-full bg-white/90 px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[.08em]">Fractional CMO<span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} /></span>
          </div>
        </div>
      </section>

      {/* Carrusel de perfiles */}
      <section className="relative mt-12">
        <p className="gutter flex justify-center"><Eyebrow>Perfiles de ejemplo · datos ficticios</Eyebrow></p>
        <Carrusel items={EJEMPLOS} label={label} />
      </section>

      {/* La red */}
      <section id="red" className="gutter revelar scroll-mt-24">
        <div className="mx-auto grid max-w-contenido items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
          <div className="flex flex-col gap-6">
            <Eyebrow>La red</Eyebrow>
            <h2 className="max-w-[15ch] font-display text-[42px] leading-[1.04] tracking-[-0.02em] md:text-[60px]">Una comunidad <span className="capsula">abierta</span> y especializada, no un portal de empleo.</h2>
            <p className="max-w-[54ch] text-[16px] text-suave">Extandard es una agencia de Fractional CMOs. Esta red es nuestra base de talento propia: aquí conocemos a los profesionales con los que construimos equipos para cada cliente y publicamos los proyectos en los que buscamos colaborar.</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="bento vidrio flex flex-col gap-3 p-5">
                <span className="glow glow-verde -left-10 -top-14 w-[170px] opacity-60" aria-hidden="true" />
                <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4" stroke="#000" strokeWidth="1.4" fill="none" /></svg>
                <span className="text-[15.5px] font-medium">Gratis y sin compromiso</span>
                <span className="text-[13.5px] leading-snug text-suave">Te registras sin aprobación previa y sin coste. Tú decides a qué te presentas.</span>
              </div>
              <div className="bento vidrio flex flex-col gap-3 p-5">
                <span className="glow glow-amarillo -left-10 -top-14 w-[170px] opacity-60" aria-hidden="true" />
                <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M7 10.5V7.5a5 5 0 0 1 10 0v3M5.5 10.5h13v10h-13z" stroke="#000" strokeWidth="1.4" fill="none" /></svg>
                <span className="text-[15.5px] font-medium">Tarifa privada</span>
                <span className="text-[13.5px] leading-snug text-suave">Solo la ve el equipo de Extandard. Nunca se publica ni la ven otros profesionales.</span>
              </div>
            </div>
            <div className="flex flex-col gap-2.5">
              <span className="eyebrow">Áreas de expertise</span>
              <div className="flex flex-wrap gap-2">
                {(Object.keys(AREAS) as AreaId[]).map((a) => (
                  <span key={a} className="tag bg-blanco"><span className="punto" style={{ background: AREAS[a].color, color: AREAS[a].color }} />{AREAS[a].label}</span>
                ))}
              </div>
            </div>
          </div>
          <Abanico label={label} />
        </div>
      </section>

      {/* Últimas oportunidades */}
      <section id="oportunidades" className="gutter revelar scroll-mt-24">
        <div className="mx-auto max-w-contenido pb-20">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div className="flex flex-col gap-3">
              <Eyebrow>Portal de oportunidades</Eyebrow>
              <h2 className="font-display text-[38px] leading-[1.04] tracking-[-0.02em] md:text-[52px]">Últimas oportunidades publicadas</h2>
            </div>
            <button className="btn btn-texto !no-underline" onClick={discover}>Ver todas <Arrow /></button>
          </div>
          {!session.db ? (
            <div className="vidrio !rounded-[24px] p-7 text-suave">Las oportunidades se cargan desde la plataforma publicada.</div>
          ) : !board.ready ? <LoadingBlock /> : ultimas.length === 0 ? (
            <div className="vidrio !rounded-[24px] p-7 text-suave">Ahora mismo no hay proyectos abiertos. Únete a la red y te avisaremos cuando publiquemos uno que encaje contigo.</div>
          ) : (
            <ul className="flex flex-col gap-4">
              {ultimas.map((b, i) => <li key={b.id}><OppRow o={{ ...b, confidential: !b.client }} n={i + 1} label={label} onClick={() => abrir(b.id)} /></li>)}
            </ul>
          )}
        </div>
      </section>

      {/* A quién buscamos / con quién trabajarás */}
      <section className="gutter revelar">
        <div className="mx-auto grid max-w-contenido gap-4 pb-20 lg:grid-cols-2">
          <Lista eyebrow="Perfiles" title="A quién buscamos" text="Profesionales senior de marketing con experiencia dirigiendo la función o una disciplina clave." rows={BUSCAMOS} glow="glow-azul" />
          <Lista eyebrow="Proyectos" title="Con quién trabajarás" text="Startups, scale-ups, pymes y grandes empresas que necesitan dirección de marketing senior, en cuatro formatos." rows={PROYECTOS} glow="glow-amarillo" />
        </div>
      </section>

      {/* Cómo funciona */}
      <section id="proceso" className="gutter revelar scroll-mt-24">
        <div className="mx-auto max-w-contenido pb-20">
          <div className="mb-10 flex flex-col items-center gap-4 text-center">
            <Eyebrow>Proceso</Eyebrow>
            <h2 className="font-display text-[46px] leading-[1.02] tracking-[-0.02em] md:text-[68px]">Cómo <span className="capsula capsula-b">funciona</span></h2>
          </div>
          <div className="vidrio mx-auto mb-5 max-w-[900px] !rounded-full px-4 py-5 md:px-10"><Proceso pasos={PASOS.map(([t]) => ({ label: t }))} actual={3} /></div>
          <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PASOS.map(([t, d], i) => (
              <li key={t} className="bento vidrio elevar flex flex-col gap-5 p-6">
                <span className={`glow ${["glow-verde", "glow-celeste", "glow-azul", "glow-amarillo"][i]} -right-10 -top-12 w-[180px] opacity-60`} aria-hidden="true" />
                <span className="font-mono text-[10.5px] tracking-[.08em] text-suave">PASO {String(i + 1).padStart(2, "0")}</span>
                <div aria-hidden="true" className="flex min-h-[64px] flex-col justify-center"><MiniPaso i={i} /></div>
                <div className="flex flex-col gap-1.5">
                  <h3 className="text-[17px] font-medium leading-tight">{t}</h3>
                  <p className="text-[14px] text-suave">{d}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* FAQ */}
      <section id="preguntas" className="gutter revelar scroll-mt-24">
        <div className="mx-auto flex max-w-[860px] flex-col items-center gap-8 pb-20">
          <div className="flex flex-col items-center gap-4 text-center">
            <Eyebrow>Preguntas</Eyebrow>
            <h2 className="font-display text-[44px] leading-[1.02] tracking-[-0.02em] md:text-[60px]">Preguntas frecuentes</h2>
          </div>
          <div className="vidrio w-full !rounded-[28px] p-3 md:p-5">
            {FAQ.map(([q, a]) => (
              <details key={q} className="fila group border-b border-filo px-3 py-4 last:border-0">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6 text-[15.5px] font-medium">
                  {q}<span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/80 text-[17px] shadow-frio transition-[transform,background-color] duration-200 group-open:rotate-45 group-open:bg-verde" aria-hidden="true">+</span>
                </summary>
                <p className="max-w-[62ch] pt-3 text-suave">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Cierre */}
      <section className="gutter revelar">
        <div className="bento vidrio relative mx-auto flex max-w-contenido flex-col items-center gap-7 !rounded-[40px] px-6 py-20 text-center md:py-24">
          <span className="glow glow-celeste -left-[6%] top-[-30%] w-[460px]" aria-hidden="true" />
          <span className="glow glow-amarillo right-[2%] top-[-20%] w-[420px] opacity-70" aria-hidden="true" />
          <span className="glow glow-verde left-[38%] bottom-[-45%] w-[340px] opacity-60" aria-hidden="true" />
          <div className="flex items-center font-mono text-[10.5px] uppercase tracking-[.08em]" aria-hidden="true">
            <span className="rounded-full py-2.5 pl-4 pr-8 text-white" style={{ background: "linear-gradient(90deg,#0B70FE,#43CCFF)" }}>Empresa</span>
            <span className="-ml-5 rounded-full py-2.5 pl-6 pr-4 mix-blend-multiply" style={{ background: "linear-gradient(90deg,#43CCFF,#00FF00)" }}>Fractional CMO</span>
          </div>
          <h2 className="max-w-[17ch] font-display text-[44px] leading-[1.02] tracking-[-0.02em] md:text-[72px]">Tu próxima colaboración empieza con un buen <span className="capsula capsula-b">perfil</span></h2>
          <p className="text-suave">Tu perfil entra en la red en cuanto lo envías.</p>
          <button className="btn btn-negro text-[16px]" onClick={join}>Quiero formar parte de la red <Arrow /></button>
        </div>
      </section>

      <Footer />

      <AccesoModal open={gate} onClose={() => setGate(false)} />
    </div>
  );
}

export function AccesoModal({ open, onClose, initial = "crear" }: { open: boolean; onClose: () => void; initial?: "entrar" | "crear" }) {
  const { session } = useApp();
  const auth = authNS();
  if (auth) return <Modal open={open} onClose={onClose} title={initial === "crear" ? "Únete a la red" : "Accede a la red"}><Acceso key={String(open) + initial} auth={auth} initial={initial} /></Modal>;
  return (
    <Modal open={open} onClose={onClose} title="Accede para unirte">
      <div className="flex flex-col gap-4">
        <p className="text-suave">
          {session.role === "anonimo"
            ? "Para crear tu perfil necesitas iniciar sesión. En esta demo el acceso se gestiona compartiendo la plataforma con tu cuenta; en la versión publicada será registro con email o Google."
            : "Tu acceso actual solo permite ver la plataforma. Pide al equipo de Extandard acceso de colaborador para poder registrarte y presentar candidaturas."}
        </p>
        <div className="flex justify-end"><button className="btn btn-negro" onClick={onClose}>Entendido</button></div>
      </div>
    </Modal>
  );
}

export function Footer() {
  const { go, session } = useApp();
  const [gate, setGate] = useState<false | "entrar" | "crear">(false);
  const pub = session.role === "anonimo" || session.role === "lector";
  const link = "text-left text-[14px] text-negro/80 transition-colors hover:text-negro";
  return (
    <footer className="gutter pb-6 pt-12">
      <div className="bento vidrio mx-auto flex max-w-contenido flex-col gap-10 !rounded-[28px] px-7 pb-6 pt-10 md:px-10">
        <span className="glow glow-amarillo -bottom-32 left-[30%] w-[380px] opacity-50" aria-hidden="true" />
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div className="flex max-w-[44ch] flex-col gap-4">
            <span className="w-fit"><Logo height={30} /></span>
            <p className="text-[14px] text-suave">Red de talento de Fractional CMOs y líderes de marketing. Conectamos talento estratégico con proyectos que generan impacto.</p>
          </div>
          <nav className="flex flex-col gap-2.5" aria-label="La red">
            <span className="eyebrow mb-1">La red</span>
            <button className={link} onClick={() => go({ name: pub ? "publicas" : "oportunidades" })}>Oportunidades</button>
            <button className={link} onClick={() => (pub ? setGate("crear") : go({ name: "registro" }))}>Unirme a la red</button>
            {pub && <button className={link} onClick={() => setGate("entrar")}>Acceder</button>}
          </nav>
          <nav className="flex flex-col gap-2.5" aria-label="Privacidad">
            <span className="eyebrow mb-1">Privacidad</span>
            <button className={link} onClick={() => go({ name: "privacidad" })}>Aviso de privacidad</button>
            <button className={link} onClick={() => go({ name: "privacidad" })}>Solicitar eliminación de datos</button>
          </nav>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-filo pt-5 font-mono text-[10px] uppercase tracking-[.08em] text-suave">
          <span>© 2026 Extandard · The Fractional CMO Company</span>
          <span className="inline-flex items-center gap-2"><Isotipo height={14} color="#5A5F69" stroke={10} />Red de talento</span>
        </div>
      </div>
      <AccesoModal open={!!gate} initial={gate || "crear"} onClose={() => setGate(false)} />
    </footer>
  );
}

export function Privacy() {
  const { session, go } = useApp();
  return (
    <div className="gutter">
      <article className="vidrio mx-auto my-10 flex max-w-[800px] flex-col gap-6 !rounded-[28px] p-7 md:p-12">
        <span className="eyebrow">Aviso de privacidad · borrador pendiente de revisión legal</span>
        <h1 className="font-display text-[44px] leading-[1]">Privacidad y tus datos</h1>
        <p className="text-[17px]">Extandard trata los datos que nos facilitas en esta plataforma con una única finalidad: gestionar la red de talento y comunicarte oportunidades profesionales que puedan encajar contigo.</p>
        {[
          ["Qué datos tratamos", "Los que introduces en tu perfil: identificación y contacto, experiencia, especialización, disponibilidad, preferencias de colaboración y tarifa mínima, además de tus candidaturas."],
          ["Quién puede verlos", "Solo el equipo interno autorizado de Extandard. Tu tarifa y las notas internas nunca se muestran a otros profesionales ni se publican. Cuando te presentas a un proyecto, podemos compartir tu perfil con el cliente correspondiente tras hablarlo contigo."],
          ["Base legal", "Tu consentimiento expreso, que das al enviar el perfil y que puedes retirar cuando quieras."],
          ["Cuánto tiempo", "Mientras formes parte de la red. Si marcas tu perfil como inactivo o solicitas la baja, dejaremos de tratarlo para nuevas oportunidades."],
          ["Tus derechos", "Puedes acceder, rectificar y suprimir tus datos, así como oponerte a su tratamiento o pedir su portabilidad."],
        ].map(([h, t]) => (
          <section key={h} className="flex flex-col gap-2 border-t-[0.5px] border-filo pt-4">
            <h2 className="font-display text-[22px]">{h}</h2>
            <p className="text-suave">{t}</p>
          </section>
        ))}
        <section className="tarjeta tarjeta-roto flex flex-col gap-3">
          <h2 className="font-display text-[22px]">Cómo solicitar la eliminación de tus datos</h2>
          <ol className="flex list-decimal flex-col gap-1 pl-5 text-suave">
            <li>Entra en tu área privada y abre <strong className="font-medium text-negro">Mi perfil</strong>.</li>
            <li>Al final de la página, pulsa <strong className="font-medium text-negro">Solicitar eliminación de mis datos</strong> y confirma.</li>
            <li>El equipo recibe la solicitud, la tramita y elimina tu perfil, candidaturas y notas asociadas.</li>
          </ol>
          {session.role === "profesional" && <div><button className="btn btn-contorno btn-sm mt-2" onClick={() => go({ name: "perfil" })}>Ir a mi perfil</button></div>}
        </section>
      </article>
    </div>
  );
}
