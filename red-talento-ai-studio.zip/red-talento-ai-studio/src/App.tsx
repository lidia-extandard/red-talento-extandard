import { useCallback, useEffect, useMemo, useState } from "react";
import type React from "react";
import { Ctx, type View, useApp as useApp2 } from "./context";
import { useDoc, useSession } from "./db";
import type { Catalog } from "./types";
import { DEFAULT_CATALOG } from "./constants";
import { Arrow, LoadingBlock, Logo, ToastProvider } from "./ui";
import Landing, { AccesoModal, Footer, Privacy, irA } from "./Landing";
import { authNS } from "./Acceso";
import Wizard from "./Wizard";
import { Inbox, MyApplications, MyProfile, OppDetail, OppList, ProHome, useProData, type ProData } from "./Pro";
import { useAdminData, type AdminData } from "./adminData";
import { Activity, AdminDashboard, CatalogAdmin, Talent } from "./Admin";
import { OppEditor, OppsAdmin, Pipeline } from "./AdminOpps";

export default function App() {
  const session = useSession();
  const cat = useDoc<Catalog>(session.db, session.db ? "config/catalog" : null);
  const catalog = cat.data?.specialties ? cat.data : DEFAULT_CATALOG;
  const labels = useMemo(() => {
    const m: Record<string, string> = {};
    for (const s of [...DEFAULT_CATALOG.specialties, ...DEFAULT_CATALOG.sectors, ...catalog.specialties, ...catalog.sectors]) m[s.id] = s.label;
    return m;
  }, [catalog]);
  const label = useCallback((id: string) => labels[id] ?? id, [labels]);
  const [view, setView] = useState<View>({ name: "landing" });
  const [proMode, setProMode] = useState(false);
  const [booted, setBooted] = useState(false);

  // Vista inicial según el rol, una sola vez. Respeta los enlaces directos (#/oportunidades/{id}) para campañas.
  useEffect(() => {
    if (session.loading || booted) return;
    setBooted(true);
    const h = fromHash();
    if (h && (h.name === "oportunidad" || h.name === "publicas")) {
      if (session.role === "equipo") setProMode(true);
      if (h.name === "publicas" && session.role !== "anonimo" && session.role !== "lector") setView({ name: "oportunidades" });
      else setView(h);
      return;
    }
    if (h?.name === "privacidad") { setView(h); return; }
    if (session.role === "equipo") setView({ name: "panel" });
    else if (session.role === "profesional") setView({ name: "inicio" });
  }, [session.loading, session.role, booted]);

  const go = useCallback((v: View) => { setView(v); toHash(v); window.scrollTo({ top: 0 }); }, []);
  const ctx = useMemo(() => ({ session, catalog, label, go, view, proMode, setProMode }), [session, catalog, label, go, view, proMode]);

  if (session.loading) return <div className="gutter mx-auto min-h-[60vh] max-w-contenido pt-28"><div className="atmosfera" aria-hidden="true"><i /><i /><i /><i /><i /></div><LoadingBlock label="Preparando la plataforma" /></div>;
  const asTeam = session.role === "equipo" && !proMode;
  const asPro = session.role === "profesional" || (session.role === "equipo" && proMode);

  return (
    <Ctx.Provider value={ctx}>
      <ToastProvider>
        <div className="atmosfera" aria-hidden="true"><i /><i /><i /><i /><i /></div>
        {asTeam ? <TeamShell /> : asPro ? <ProShell /> : <PublicShell />}
      </ToastProvider>
    </Ctx.Provider>
  );
}

/* ---------- Enlaces directos: #/oportunidades, #/oportunidades/{id}, #/privacidad (las UTM de la URL se conservan) ---------- */
function fromHash(): View | null {
  try {
    const [a, b] = window.location.hash.replace(/^#\/?/, "").split("/");
    if (a === "oportunidades" && b) return { name: "oportunidad", id: decodeURIComponent(b) };
    if (a === "oportunidades") return { name: "publicas" };
    if (a === "privacidad") return { name: "privacidad" };
  } catch { /* sin hash */ }
  return null;
}
function toHash(v: View) {
  const h = v.name === "oportunidad" ? `#/oportunidades/${encodeURIComponent(v.id)}` : v.name === "publicas" || v.name === "oportunidades" ? "#/oportunidades" : v.name === "privacidad" ? "#/privacidad" : "";
  try { if (window.location.hash !== h) window.history.replaceState(null, "", window.location.pathname + window.location.search + h); } catch { /* entorno sin historial */ }
}

/* ---------- Barra superior ---------- */
function TopBar({ items, right }: { items: { label: string; active: boolean; onClick: () => void; badge?: number }[]; right?: React.ReactNode }) {
  const { go, session } = useApp2();
  return (
    <>
      <header className="gutter sticky z-30 pt-3" style={{ top: "env(safe-area-inset-top,0px)" }}>
        <div className="vidrio mx-auto flex max-w-contenido flex-wrap items-center gap-x-5 gap-y-1.5 !rounded-[26px] py-2 pl-5 pr-2 md:!rounded-full">
          <button onClick={() => go({ name: session.role === "equipo" ? "panel" : session.role === "profesional" ? "inicio" : "landing" })} className="flex items-center gap-3 py-1.5" aria-label="Inicio">
            <Logo height={21} />
          </button>
          <nav className="-mx-1 order-3 flex w-full gap-0.5 overflow-x-auto pb-1 md:order-none md:w-auto md:flex-1 md:justify-center md:pb-0" aria-label="Principal">
            {items.map((it) => (
              <button key={it.label} onClick={it.onClick} aria-current={it.active ? "page" : undefined}
                className={`relative flex items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-2 text-[13.5px] transition-colors duration-200 ${it.active ? "bg-white/90 font-medium shadow-[0_6px_18px_-8px_rgba(30,60,130,.35)]" : "text-suave hover:bg-white/60 hover:text-negro"}`}>
                {it.active && <span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} aria-hidden="true" />}
                {it.label}
                {!!it.badge && <span className="tnum inline-grid min-w-[18px] place-items-center rounded-full bg-verde px-1 text-[10.5px] font-medium text-negro">{it.badge}</span>}
              </button>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">{right}{authNS() && session.uid && <button className="px-2 text-[13px] text-suave hover:text-negro" onClick={() => authNS()!.signOut().then(() => window.location.reload())}>Salir</button>}</div>
        </div>
      </header>
    </>
  );
}


function ModeSwitch() {
  const { proMode, setProMode, go } = useApp2();
  return (
    <div className="flex items-center gap-0.5 rounded-full bg-white/60 p-1 text-[12px]" role="group" aria-label="Cambiar vista">
      <button className={`rounded-full px-3 py-1.5 transition-colors duration-200 ${!proMode ? "bg-negro text-blanco" : ""}`} onClick={() => { setProMode(false); go({ name: "panel" }); }}>Equipo</button>
      <button className={`rounded-full px-3 py-1.5 transition-colors duration-200 ${proMode ? "bg-verde" : ""}`} onClick={() => { setProMode(true); go({ name: "inicio" }); }} title="Prueba el recorrido del profesional con tu propia cuenta">Vista profesional</button>
    </div>
  );
}

function TeamShell() {
  const { session, view, go } = useApp2();
  const d = useAdminData(session.db);
  const week = Date.now() - 7 * 864e5;
  const pending = d.people.filter((p) => p.submittedAt && new Date(p.submittedAt).getTime() > week).length;
  const fresh = d.applications.filter((a) => !a.withdrawn && a.stage === "nueva").length;
  const n = view.name;
  return (
    <div className="flex min-h-screen flex-col">
      <TopBar
        items={[
          { label: "Panel", active: n === "panel", onClick: () => go({ name: "panel" }) },
          { label: "Comunidad", active: n === "talento", onClick: () => go({ name: "talento" }), badge: pending },
          { label: "Oportunidades", active: ["opps-admin", "opp-edit", "pipeline"].includes(n), onClick: () => go({ name: "opps-admin" }), badge: fresh },
          { label: "Catálogo", active: n === "catalogo", onClick: () => go({ name: "catalogo" }) },
          { label: "Actividad", active: n === "actividad", onClick: () => go({ name: "actividad" }) },
          { label: "Web pública", active: n === "landing", onClick: () => go({ name: "landing" }) },
        ]}
        right={<ModeSwitch />}
      />
      <main className="flex-1"><TeamRoutes d={d} /></main>
    </div>
  );
}

function TeamRoutes({ d }: { d: AdminData }) {
  const { view } = useApp2();
  switch (view.name) {
    case "talento": return <Talent d={d} filter={view.filter} openUid={view.uid} />;
    case "opps-admin": return <OppsAdmin d={d} />;
    case "opp-edit": return <OppEditor key={view.id ?? "nueva"} d={d} id={view.id} />;
    case "pipeline": return <Pipeline key={view.oppId} d={d} oppId={view.oppId} />;
    case "catalogo": return <CatalogAdmin />;
    case "actividad": return <Activity d={d} />;
    case "landing": return <><Landing /></>;
    case "privacidad": return <Privacy />;
    default: return <AdminDashboard d={d} />;
  }
}

function ProShell() {
  const { view, go, session } = useApp2();
  const d = useProData();
  const unread = (d.inbox?.items ?? []).filter((x) => !x.read).length;
  const n = view.name;
  const items = d.profile
    ? [
        { label: "Inicio", active: n === "inicio", onClick: () => go({ name: "inicio" }) },
        { label: "Mi perfil", active: n === "perfil" || n === "registro", onClick: () => go({ name: "perfil" }) },
        { label: "Oportunidades", active: n === "oportunidades" || n === "oportunidad", onClick: () => go({ name: "oportunidades" }) },
        { label: "Mis candidaturas", active: n === "candidaturas", onClick: () => go({ name: "candidaturas" }) },
        { label: "Avisos", active: n === "avisos", onClick: () => go({ name: "avisos" }), badge: unread },
      ]
    : [
        { label: "Inicio", active: n === "inicio", onClick: () => go({ name: "inicio" }) },
        { label: "La red", active: n === "landing", onClick: () => go({ name: "landing" }) },
        { label: "Oportunidades", active: n === "oportunidades" || n === "oportunidad", onClick: () => go({ name: "oportunidades" }) },
      ];
  return (
    <div className="flex min-h-screen flex-col">
      <TopBar items={items} right={session.role === "equipo" ? <ModeSwitch /> : <span className="hidden text-[13px] text-suave sm:inline">{d.profile?.fullName || session.name}</span>} />
      <main className="flex-1"><ProRoutes d={d} /></main>
      {n !== "landing" && <Footer />}
    </div>
  );
}

function ProRoutes({ d }: { d: ProData }) {
  const { view } = useApp2();
  switch (view.name) {
    case "registro": return <Wizard key={`w-${view.step ?? "x"}`} startStep={view.step} />;
    case "perfil": return <MyProfile d={d} />;
    case "oportunidades": return <OppList d={d} />;
    case "oportunidad": return <OppDetail id={view.id} d={d} />;
    case "candidaturas": return <MyApplications d={d} />;
    case "avisos": return <Inbox d={d} />;
    case "landing": return <Landing />;
    case "privacidad": return <Privacy />;
    default: return <ProHome d={d} />;
  }
}

function PublicShell() {
  const { view, go } = useApp2();
  const [gate, setGate] = useState<false | "entrar" | "crear">(false);
  const n = view.name;
  const ancla = (id: string) => () => { if (n !== "landing") go({ name: "landing" }); irA(id); };
  return (
    <div className="flex min-h-screen flex-col">
      <TopBar
        items={[
          { label: "Oportunidades", active: n === "publicas" || n === "oportunidad", onClick: () => go({ name: "publicas" }) },
          { label: "La red", active: false, onClick: ancla("red") },
          { label: "Proceso", active: false, onClick: ancla("proceso") },
          { label: "Preguntas", active: false, onClick: ancla("preguntas") },
        ]}
        right={<>
          <button className="hidden px-2 text-[13.5px] text-negro/80 hover:text-negro sm:inline" onClick={() => setGate("entrar")}>Acceder</button>
          <button className="btn btn-verde btn-sm" onClick={() => setGate("crear")}>Unirme a la red <Arrow size={12} /></button>
        </>}
      />
      <AccesoModal open={!!gate} initial={gate || "crear"} onClose={() => setGate(false)} />
      <main className="flex-1">
        {n === "publicas" ? <OppList publicView /> : n === "oportunidad" ? <OppDetail id={view.id} /> : n === "privacidad" ? <Privacy /> : <Landing />}
      </main>
      {n !== "landing" && <Footer />}
    </div>
  );
}
