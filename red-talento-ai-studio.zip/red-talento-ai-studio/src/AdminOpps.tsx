import type React from "react";
import { useMemo, useState } from "react";
import { useApp } from "./context";
import { fmtDate, notify, now, rid, useNames } from "./db";
import type { Opportunity, OppStatus, Stage } from "./types";
import { Eyebrow, OppRow } from "./OppRow";
import { AREAS, areaOf, COLLABORATIONS, COMPANY_TYPES, CURRENCIES, DEDICATIONS, OPP_STATUS, PROFILE_STATUS, STAGES, WORK_MODES , isActive } from "./constants";
import { type AdminData, type AppRow, saveOpportunity, savePipelineFields, setStage } from "./adminData";
import { Arrow, AvailabilityDot, ChipSelect, DemoTag, Drawer, Empty, Field, LoadingBlock, Modal, SectionHead, Select, StatusTag, TextArea, TextInput, useConfirm, useToast , Proceso , Avatar, PerfilCard } from "./ui";
import { Page } from "./Pro";
import { ProfileSummary } from "./Wizard";
import { Criterios, FitCard, toPerfil } from "./Admin";
import { fit } from "./match";

/* ---------- Listado de oportunidades ---------- */
export function OppsAdmin({ d }: { d: AdminData }) {
  const { go, label } = useApp();
  const [st, setSt] = useState<"" | OppStatus>("");
  const list = d.opps.filter((o) => (st ? o.status === st : o.status !== "archivada")).sort((a, b) => (b.updatedAt > a.updatedAt ? 1 : -1));
  const count = (s: OppStatus) => d.opps.filter((o) => o.status === s).length;
  return (
    <Page>
      <SectionHead eyebrow="Oportunidades" title="Proyectos y candidaturas" text="Crea, publica y gestiona cada proyecto. Las confidenciales nunca muestran el cliente a los profesionales."
        actions={<button className="btn btn-verde" onClick={() => go({ name: "opp-edit" })}>Crear oportunidad <Arrow /></button>} />
      <div className="mt-6 flex flex-wrap gap-2">
        <button className="chip" aria-pressed={st === ""} onClick={() => setSt("")}>Activas</button>
        {(Object.keys(OPP_STATUS) as OppStatus[]).map((s) => <button key={s} className="chip" aria-pressed={st === s} onClick={() => setSt(s)}>{OPP_STATUS[s].label}<span className="tnum text-suave">{count(s)}</span></button>)}
      </div>
      <div className="mt-6">
        {!d.ready ? <LoadingBlock /> : list.length === 0 ? <Empty title="No hay oportunidades aquí" text="Crea la primera oportunidad: puedes guardarla como borrador y publicarla cuando esté lista." action={<button className="btn btn-verde" onClick={() => go({ name: "opp-edit" })}>Crear oportunidad</button>} /> : (
          <div className="flex flex-col gap-4">
            <Eyebrow>{list.length} {list.length === 1 ? "oportunidad" : "oportunidades"}</Eyebrow>
            <ul className="flex flex-col gap-4">
              {list.map((o, i) => {
                const apps = d.applications.filter((a) => a.oppId === o.id && !a.withdrawn);
                const fresh = apps.filter((a) => a.stage === "nueva").length;
                const short = apps.filter((a) => ["preseleccionada", "entrevista", "seleccionada"].includes(a.stage)).length;
                const cur = o.currency === "EUR" ? "€" : o.currency === "USD" ? "$" : o.currency === "GBP" ? "£" : o.currency;
                const num = (n: number | null) => (n == null ? "—" : `${n.toLocaleString("es-ES", { useGrouping: true })} ${cur}`);
                const rango = o.rateMin || o.rateMax ? `${num(o.rateMin)} – ${num(o.rateMax)} / ${o.rateType === "mes" ? "mes" : "día"}` : null;
                return (
                  <li key={o.id}>
                    <OppRow n={i + 1} label={label} onClick={() => go({ name: "pipeline", oppId: o.id })}
                      o={{ ...o, client: o.client, confidential: false, rate: rango }}
                      badge={<><StatusTag {...OPP_STATUS[o.status]} />{o.clientConfidential && <span className="tag bg-negro">Confidencial</span>}</>}
                      side={rango ? <span className="flex flex-col items-start md:items-end"><span className="font-mono text-[10px] uppercase tracking-[.07em] text-suave">Interno{o.publishRate ? " · publicado" : ""}</span><span className="tnum text-[15px] font-medium">{rango}</span></span> : <span className="tag bg-blanco">Sin rango</span>}
                      extra={
                        <div className="mt-1 flex flex-wrap items-center gap-2">
                          <span className="tag bg-blanco tnum">{apps.length} candidaturas</span>
                          {fresh > 0 && <span className="tag bg-verde tnum"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />{fresh} sin revisar</span>}
                          {short > 0 && <span className="tag bg-blanco tnum">{short} en proceso avanzado</span>}
                          <span className="font-mono text-[10px] uppercase tracking-[.06em] text-suave">{o.internalName} · act. {fmtDate(o.updatedAt)}</span>
                          <button className="btn btn-texto btn-sm" onClick={(e) => { e.stopPropagation(); go({ name: "opp-edit", id: o.id }); }}>Editar</button>
                        </div>
                      } />
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
    </Page>
  );
}

/* ---------- Crear / editar oportunidad ---------- */
function blankOpp(by: string): Opportunity {
  const t = now();
  return {
    id: `op-${rid()}`, internalName: "", title: "", client: "", clientConfidential: true, summary: "", description: "", context: "", objectives: "", responsibilities: "", requirements: "",
    preferredExperience: "", specialties: [], sector: "", companyType: "", dedication: "", collaboration: "", duration: "", startDate: "", workMode: "Remoto", location: "",
    rateMin: null, rateMax: null, rateType: "dia", currency: "EUR", publishRate: false, deadline: "", seats: 1, internalNotes: "", status: "borrador", createdAt: t, updatedAt: t, createdBy: by,
  };
}

export function OppEditor({ d, id }: { d: AdminData; id?: string }) {
  const { session, catalog, go } = useApp();
  const toast = useToast();
  const existing = d.opps.find((o) => o.id === id);
  const [o, setO] = useState<Opportunity>(() => (existing ? JSON.parse(JSON.stringify(existing)) : blankOpp(session.uid ?? "equipo")));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  if (id && !d.ready) return <LoadingBlock />;
  if (id && !existing) return <Page><Empty title="No encontramos esta oportunidad" text="Puede que se haya eliminado." action={<button className="btn btn-contorno" onClick={() => go({ name: "opps-admin" })}>Volver</button>} /></Page>;
  const set = <K extends keyof Opportunity>(k: K, v: Opportunity[K]) => { setO({ ...o, [k]: v }); setErrors((e) => { const n = { ...e }; delete n[k as string]; return n; }); };

  function check(publishing: boolean) {
    const e: Record<string, string> = {};
    if (!o.internalName.trim()) e.internalName = "Pon un nombre interno para encontrarla.";
    if (publishing) {
      if (o.title.trim().length < 8) e.title = "Escribe un título visible claro.";
      if (!o.client.trim()) e.client = "Indica la empresa o cliente (puede ser confidencial).";
      if (o.summary.trim().length < 30) e.summary = "Escribe una descripción breve (mínimo 30 caracteres).";
      if (o.description.trim().length < 60) e.description = "Describe el proyecto (mínimo 60 caracteres).";
      if (!o.specialties.length) e.specialties = "Elige al menos una especialidad.";
      if (!o.sector) e.sector = "Elige el sector.";
      if (!o.companyType) e.companyType = "Elige el tipo de empresa.";
      if (!o.dedication) e.dedication = "Elige la dedicación.";
      if (!o.collaboration) e.collaboration = "Elige el tipo de colaboración.";
      if (!o.duration.trim()) e.duration = "Indica la duración.";
    }
    if (o.rateMin && o.rateMax && o.rateMin > o.rateMax) e.rateMax = "El máximo debe ser mayor que el mínimo.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }
  async function save(status?: OppStatus) {
    if (!session.db) return;
    const publishing = status === "publicada" || (!status && o.status === "publicada");
    if (!check(publishing)) { toast("Revisa los campos marcados.", "error"); return; }
    setBusy(true);
    try {
      await saveOpportunity(session.db, session.uid ?? "equipo", d, o, status);
      toast(status === "publicada" ? "Oportunidad publicada." : "Oportunidad guardada.");
      go({ name: "pipeline", oppId: o.id });
    } catch { toast("No se ha podido guardar la oportunidad.", "error"); } finally { setBusy(false); }
  }
  const opt = (l: string[]) => l;
  const err = (k: string) => errors[k];
  return (
    <Page>
      <button className="btn btn-texto btn-sm mb-6 !pl-0" onClick={() => go({ name: existing ? "pipeline" : "opps-admin", ...(existing ? { oppId: existing.id } : {}) } as never)}><Arrow dir="izquierda" /> Volver</button>
      <SectionHead eyebrow={existing ? "Editar oportunidad" : "Nueva oportunidad"} title={o.title || o.internalName || "Sin título"}
        actions={<><StatusTag {...OPP_STATUS[o.status]} /></>} />
      <div className="mt-8 grid gap-10 lg:grid-cols-6">
        <div className="flex min-w-0 flex-col gap-10 lg:col-span-4">
          <Group title="Identificación">
            <Field id="internalName" label="Nombre interno" help="Solo lo ve el equipo" error={err("internalName")}><TextInput id="internalName" value={o.internalName} invalid={!!err("internalName")} onChange={(e) => set("internalName", e.target.value)} placeholder="Cliente X · CMO Q1" /></Field>
            <Field id="title" label="Título visible para los profesionales" error={err("title")}><TextInput id="title" value={o.title} invalid={!!err("title")} onChange={(e) => set("title", e.target.value)} placeholder="Fractional CMO para scale-up SaaS B2B" /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="client" label="Empresa o cliente" error={err("client")}><TextInput id="client" value={o.client} invalid={!!err("client")} onChange={(e) => set("client", e.target.value)} /></Field>
              <label className="flex items-center gap-3 self-end rounded-[12px] border border-filo px-4 py-3 text-[14px]"><input type="checkbox" className="h-4 w-4 accent-black" checked={o.clientConfidential} onChange={(e) => set("clientConfidential", e.target.checked)} />Mantener el cliente confidencial</label>
            </div>
          </Group>
          <Group title="El proyecto">
            <Field id="summary" label="Descripción breve" help="Aparece en el listado" error={err("summary")}><TextArea id="summary" className="!min-h-[80px]" value={o.summary} invalid={!!err("summary")} onChange={(e) => set("summary", e.target.value)} maxLength={300} /></Field>
            <Field id="description" label="Descripción del proyecto" error={err("description")}><TextArea id="description" value={o.description} invalid={!!err("description")} onChange={(e) => set("description", e.target.value)} /></Field>
            <Field id="context" label="Contexto y retos de negocio" optional><TextArea id="context" value={o.context} onChange={(e) => set("context", e.target.value)} /></Field>
            <Field id="objectives" label="Objetivos y resultados esperados" optional><TextArea id="objectives" value={o.objectives} onChange={(e) => set("objectives", e.target.value)} /></Field>
            <Field id="responsibilities" label="Responsabilidades" optional><TextArea id="responsibilities" value={o.responsibilities} onChange={(e) => set("responsibilities", e.target.value)} /></Field>
          </Group>
          <Group title="Perfil buscado">
            <Field id="specialties" label="Competencias requeridas (especialidades)" error={err("specialties")}><ChipSelect id="specialties" options={catalog.specialties.filter((s) => !s.archived).map((s) => ({ value: s.id, label: s.label }))} value={o.specialties} onChange={(v) => set("specialties", v)} /></Field>
            <Field id="requirements" label="Requisitos" optional><TextArea id="requirements" value={o.requirements} onChange={(e) => set("requirements", e.target.value)} /></Field>
            <Field id="preferredExperience" label="Experiencia preferida" optional help="Interno, no se publica"><TextArea id="preferredExperience" className="!min-h-[80px]" value={o.preferredExperience} onChange={(e) => set("preferredExperience", e.target.value)} /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="sector" label="Sector" error={err("sector")}><Select id="sector" placeholder="Elige un sector" value={o.sector} invalid={!!err("sector")} onChange={(e) => set("sector", e.target.value)} options={catalog.sectors.map((s) => ({ value: s.id, label: s.label }))} /></Field>
              <Field id="companyType" label="Tipo de empresa" error={err("companyType")}><Select id="companyType" placeholder="Elige un tipo" value={o.companyType} invalid={!!err("companyType")} onChange={(e) => set("companyType", e.target.value)} options={opt(COMPANY_TYPES)} /></Field>
            </div>
          </Group>
          <Group title="Condiciones">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="dedication" label="Dedicación estimada" error={err("dedication")}><Select id="dedication" placeholder="Elige" value={o.dedication} invalid={!!err("dedication")} onChange={(e) => set("dedication", e.target.value)} options={DEDICATIONS} /></Field>
              <Field id="collaboration" label="Tipo de colaboración" error={err("collaboration")}><Select id="collaboration" placeholder="Elige" value={o.collaboration} invalid={!!err("collaboration")} onChange={(e) => set("collaboration", e.target.value)} options={COLLABORATIONS} /></Field>
              <Field id="duration" label="Duración del proyecto" error={err("duration")}><TextInput id="duration" value={o.duration} invalid={!!err("duration")} onChange={(e) => set("duration", e.target.value)} placeholder="6 meses, prorrogable" /></Field>
              <Field id="startDate" label="Fecha de inicio prevista" optional><TextInput id="startDate" type="date" value={o.startDate} onChange={(e) => set("startDate", e.target.value)} /></Field>
              <Field id="workMode" label="Modalidad de trabajo"><Select id="workMode" value={o.workMode} onChange={(e) => set("workMode", e.target.value)} options={WORK_MODES} /></Field>
              <Field id="location" label="Ubicación" optional><TextInput id="location" value={o.location} onChange={(e) => set("location", e.target.value)} placeholder="Madrid" /></Field>
              <Field id="deadline" label="Fecha límite de candidatura" optional><TextInput id="deadline" type="date" value={o.deadline} onChange={(e) => set("deadline", e.target.value)} /></Field>
              <Field id="seats" label="Profesionales necesarios"><TextInput id="seats" type="number" min={1} value={o.seats} onChange={(e) => set("seats", Math.max(1, Number(e.target.value) || 1))} /></Field>
            </div>
            <div className="tarjeta tarjeta-roto flex flex-col gap-3">
              <span className="etiqueta">Rango de tarifas · opcional</span>
              <div className="grid gap-3 sm:grid-cols-4">
                <TextInput id="rateMin" aria-label="Mínimo" type="number" min={0} placeholder="Mínimo" value={o.rateMin ?? ""} onChange={(e) => set("rateMin", e.target.value === "" ? null : Number(e.target.value))} />
                <TextInput id="rateMax" aria-label="Máximo" type="number" min={0} placeholder="Máximo" value={o.rateMax ?? ""} invalid={!!err("rateMax")} onChange={(e) => set("rateMax", e.target.value === "" ? null : Number(e.target.value))} />
                <Select id="rateType" aria-label="Unidad" value={o.rateType} onChange={(e) => set("rateType", e.target.value as "dia" | "mes")} options={[{ value: "dia", label: "Por día" }, { value: "mes", label: "Por mes" }]} />
                <Select id="currencyO" aria-label="Moneda" value={o.currency} onChange={(e) => set("currency", e.target.value)} options={CURRENCIES} />
              </div>
              {err("rateMax") && <span className="error">{err("rateMax")}</span>}
              <label className="flex items-center gap-3 text-[14px]"><input type="checkbox" className="h-4 w-4 accent-black" checked={o.publishRate} onChange={(e) => set("publishRate", e.target.checked)} />Mostrar el rango a los profesionales</label>
            </div>
          </Group>
          <Group title="Notas internas">
            <Field id="internalNotes" label="Solo para el equipo" optional><TextArea id="internalNotes" value={o.internalNotes} onChange={(e) => set("internalNotes", e.target.value)} /></Field>
          </Group>
        </div>
        <aside className="lg:col-span-2">
          <div className="flex flex-col gap-4 rounded-tarjeta bg-roto p-6 lg:sticky" style={{ top: "calc(88px + env(safe-area-inset-top,0px))" }}>
            <span className="eyebrow">Visibilidad</span>
            <p className="text-[14px]">{o.status === "publicada" ? "Visible para los profesionales de la red." : o.status === "pausada" ? "Visible pero sin admitir candidaturas." : o.status === "cerrada" ? "Visible como cerrada; no admite candidaturas." : "No visible para los profesionales."}</p>
            <p className="ayuda">{o.clientConfidential ? "Los profesionales verán «Cliente confidencial»." : "Los profesionales verán el nombre del cliente."} Las notas internas y la experiencia preferida nunca se publican.</p>
            <div className="flex flex-col gap-2 border-t border-filo pt-4">
              {o.status !== "publicada" && <button className="btn btn-verde" disabled={busy} onClick={() => save("publicada")}>{o.status === "pausada" ? "Reanudar publicación" : "Publicar"}</button>}
              <button className="btn btn-negro" disabled={busy} onClick={() => save()}>Guardar {o.status === "borrador" ? "borrador" : "cambios"}</button>
              {o.status === "publicada" && <button className="btn btn-contorno" disabled={busy} onClick={() => save("pausada")}>Pausar</button>}
              {["publicada", "pausada"].includes(o.status) && <button className="btn btn-contorno" disabled={busy} onClick={() => save("cerrada")}>Cerrar</button>}
              {existing && o.status !== "archivada" && <button className="btn btn-texto" disabled={busy} onClick={() => save("archivada")}>Archivar</button>}
              {o.status === "archivada" && <button className="btn btn-contorno" disabled={busy} onClick={() => save("borrador")}>Recuperar como borrador</button>}
            </div>
          </div>
        </aside>
      </div>
    </Page>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="flex flex-col gap-5"><h2 className="border-b border-filo pb-2 font-display text-[22px]">{title}</h2>{children}</section>;
}

/* ---------- Candidaturas de una oportunidad ---------- */
export function Pipeline({ d, oppId }: { d: AdminData; oppId: string }) {
  const { session, go, label } = useApp();
  const toast = useToast();
  const o = d.opps.find((x) => x.id === oppId);
  const [view, setView] = useState<"kanban" | "tabla" | "recomendados">("kanban");
  const [open, setOpen] = useState<AppRow | null>(null);
  const [cmp, setCmp] = useState<string[]>([]);
  const [cmpOpen, setCmpOpen] = useState(false);
  const [onlyFav, setOnlyFav] = useState(false);
  const [dragOver, setDragOver] = useState<Stage | null>(null);
  const rows = useMemo(() => d.applications.filter((a) => a.oppId === oppId), [d.applications, oppId]);
  if (!d.ready) return <LoadingBlock />;
  if (!o) return <Page><Empty title="No encontramos esta oportunidad" text="Puede que se haya eliminado." action={<button className="btn btn-contorno" onClick={() => go({ name: "opps-admin" })}>Volver</button>} /></Page>;
  const by = session.uid ?? "equipo";
  const person = (uid: string) => d.people.find((p) => p.uid === uid);
  const active = rows.filter((r) => !r.withdrawn && (!onlyFav || r.pipe?.favorite));
  const withdrawn = rows.filter((r) => r.withdrawn);
  const toggleCmp = (uid: string) => setCmp((c) => (c.includes(uid) ? c.filter((x) => x !== uid) : c.length >= 4 ? c : [...c, uid]));

  async function move(r: AppRow, stage: Stage) {
    if (!session.db || r.stage === stage) return;
    try { await setStage(session.db, by, d, r, stage); toast(`Movida a «${STAGES.find((s) => s.id === stage)!.label}».`); } catch { toast("No se ha podido mover la candidatura.", "error"); }
  }
  async function fav(r: AppRow) {
    if (!session.db) return;
    try { await savePipelineFields(session.db, d, r, { favorite: !r.pipe?.favorite }); } catch { toast("No se ha podido marcar.", "error"); }
  }

  const recos = d.people.filter((p) => isActive(p.status) && !rows.some((r) => r.uid === p.uid)).map((p) => ({ p, f: fit(p, o, label, true) })).sort((a, b) => b.f.score - a.f.score).slice(0, 12);

  return (
    <Page>
      <button className="btn btn-texto btn-sm mb-6 !pl-0" onClick={() => go({ name: "opps-admin" })}><Arrow dir="izquierda" /> Oportunidades</button>
      <SectionHead eyebrow={o.internalName} title={o.title}
        text={<span className="flex flex-wrap items-center gap-2"><StatusTag {...OPP_STATUS[o.status]} />{o.clientConfidential ? `${o.client} · confidencial` : o.client} · {label(o.sector)} · {o.dedication}</span>}
        actions={<><button className="btn btn-contorno" onClick={() => go({ name: "opp-edit", id: o.id })}>Editar oportunidad</button>{cmp.length >= 2 && <button className="btn btn-negro" onClick={() => setCmpOpen(true)}>Comparar {cmp.length}</button>}</>} />
      <div className="vidrio mt-4 !rounded-[28px] px-4 py-5 md:px-8">
        <Proceso pasos={STAGES.filter((x) => x.id !== "no_seleccionada").map((x) => ({ label: x.label, count: rows.filter((r) => !r.withdrawn && r.stage === x.id).length }))} />
      </div>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <div className="vidrio flex gap-1 !rounded-full p-1" role="tablist">
          {([["kanban", "Tablero"], ["tabla", "Lista"], ["recomendados", "Perfiles recomendados"]] as const).map(([k, l]) => (
            <button key={k} role="tab" aria-selected={view === k} onClick={() => setView(k)} className={`rounded-full px-4 py-2 text-[13px] transition-colors duration-200 ${view === k ? "bg-negro text-blanco" : "hover:bg-white/70"}`}>{l}</button>
          ))}
        </div>
        {view !== "recomendados" && <div className="flex items-center gap-3"><button className="chip" aria-pressed={onlyFav} onClick={() => setOnlyFav(!onlyFav)}>★ Solo favoritos</button><span className="tnum text-[13px] text-suave">{active.length} activas · {withdrawn.length} retiradas</span></div>}
      </div>

      {view === "kanban" && (
        active.length === 0 && !onlyFav ? <div className="mt-6"><Empty title="Aún no hay candidaturas" text={o.status === "publicada" ? "Cuando alguien se presente aparecerá en «Nuevas candidaturas». Mientras, revisa los perfiles recomendados e invítales." : "Publica la oportunidad para empezar a recibir candidaturas."} action={<button className="btn btn-contorno" onClick={() => setView("recomendados")}>Ver perfiles recomendados</button>} /></div> : (
          <div className="mt-6 overflow-x-auto pb-2">
            <div className="grid min-w-[1320px] grid-cols-6 gap-3">
              {STAGES.map((s) => {
                const col = active.filter((r) => r.stage === s.id);
                return (
                  <section key={s.id} onDragOver={(e) => { e.preventDefault(); setDragOver(s.id); }} onDragLeave={() => setDragOver(null)}
                    onDrop={(e) => { e.preventDefault(); setDragOver(null); const key = e.dataTransfer.getData("text/plain"); const r = active.find((x) => `${x.uid}|${x.oppId}` === key); if (r) move(r, s.id); }}
                    className={`flex min-h-[320px] flex-col gap-2.5 rounded-[24px] border p-2.5 transition-colors duration-200 ${dragOver === s.id ? "border-[rgba(0,170,0,.4)] bg-[rgba(0,255,0,.18)]" : "border-white/60 bg-white/40 backdrop-blur-xl"}`}>
                    <header className="flex items-center justify-between px-2 py-1.5"><h3 className="text-[13px] font-medium">{s.label}</h3><span className="tnum grid h-6 min-w-6 place-items-center rounded-full bg-white/80 px-1.5 text-[11px]">{col.length}</span></header>
                    {col.map((r) => {
                      const p = person(r.uid);
                      const lit = ["preseleccionada", "entrevista", "seleccionada"].includes(r.stage);
                      return (
                        <div key={r.uid} draggable onDragStart={(e) => e.dataTransfer.setData("text/plain", `${r.uid}|${r.oppId}`)} className="cursor-grab active:cursor-grabbing">
                          {p ? (
                            <PerfilCard compact p={toPerfil(p)} label={label} highlight={lit} onClick={() => setOpen(r)}
                              badges={<>{p.demo && <DemoTag />}{d.dupes.has(r.uid) && <span className="tag bg-blanco">Duplicado</span>}</>}
                              placaExtra={<button className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-[15px] ${r.pipe?.favorite ? "bg-amarillo/60" : "text-suave hover:text-negro"}`} aria-label={r.pipe?.favorite ? "Quitar de favoritos" : "Marcar como favorito"} aria-pressed={!!r.pipe?.favorite} onClick={(e) => { e.stopPropagation(); fav(r); }}>★</button>}
                              footer={
                                <span className="flex w-full flex-col items-stretch gap-2" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
                                  <label className="flex items-center gap-1.5 text-[11px] text-suave"><input type="checkbox" className="accent-black" checked={cmp.includes(r.uid)} onChange={() => toggleCmp(r.uid)} />Comparar</label>
                                  <select aria-label="Mover a" className="w-full rounded-full border border-filo bg-white/80 px-2.5 py-1.5 text-[11.5px]" value={r.stage} onChange={(e) => move(r, e.target.value as Stage)}>
                                    {STAGES.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}
                                  </select>
                                </span>
                              }>
                              {lit && <span className={`glow ${r.stage === "seleccionada" ? "glow-verde" : "glow-amarillo"} -bottom-10 -right-8 w-[140px] opacity-70`} aria-hidden="true" />}
                              {r.pipe?.nextStep && <span className="flex items-start gap-1.5 text-[12px] leading-snug"><Arrow size={10} />{r.pipe.nextStep}</span>}
                            </PerfilCard>
                          ) : <div className="vidrio p-3 text-[13px] text-suave">Perfil eliminado</div>}
                        </div>
                      );
                    })}
                  </section>
                );
              })}
            </div>
          </div>
        )
      )}

      {view === "tabla" && (
        <div className="mt-6 overflow-x-auto">
          {rows.length === 0 ? <Empty title="Aún no hay candidaturas" text="Las candidaturas aparecerán aquí en cuanto alguien se presente." /> : (
            <table className="tabla min-w-[980px]">
              <thead><tr><th aria-label="Comparar" /><th>Profesional</th><th>Encaje</th><th>Disponibilidad</th><th>Presentada</th><th>Fase</th><th>Próximo paso</th><th aria-label="Favorito" /></tr></thead>
              <tbody>
                {[...active, ...withdrawn].map((r) => {
                  const p = person(r.uid);
                  const f = p ? fit(p, o, label) : null;
                  return (
                    <tr key={r.uid} className={r.withdrawn ? "text-suave" : ""}>
                      <td><input type="checkbox" aria-label="Comparar" className="accent-black" checked={cmp.includes(r.uid)} onChange={() => toggleCmp(r.uid)} /></td>
                      <td><div className="flex items-center gap-3">{p && <Avatar name={p.fullName} areas={[areaOf(p.specialties[0] ?? "")]} size={40} />}<div className="min-w-0"><button className="text-left font-medium hover:underline" onClick={() => setOpen(r)}>{p?.fullName ?? "Perfil eliminado"}</button>{p?.demo && <span className="ml-1.5"><DemoTag /></span>}<div className="text-[12px] text-suave">{p?.headline}</div></div></div></td>
                      <td className="tnum font-display text-[20px]">{f?.score ?? "—"}</td>
                      <td>{p && <AvailabilityDot value={p.availability} />}</td>
                      <td className="tnum text-[13px]">{fmtDate(r.appliedAt)}</td>
                      <td>{r.withdrawn ? <span className="tag border border-linea">Retirada</span> : (
                        <select aria-label="Fase" className="entrada !w-auto !py-1 !text-[13px]" value={r.stage} onChange={(e) => move(r, e.target.value as Stage)}>{STAGES.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</select>
                      )}</td>
                      <td className="max-w-[200px] text-[13px]">{r.pipe?.nextStep ?? "—"}</td>
                      <td><button className={r.pipe?.favorite ? "" : "text-linea hover:text-negro"} aria-label="Favorito" aria-pressed={!!r.pipe?.favorite} onClick={() => fav(r)}>★</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}

      {view === "kanban" && withdrawn.length > 0 && (
        <details className="mt-6"><summary className="cursor-pointer text-[14px] text-suave">Candidaturas retiradas ({withdrawn.length})</summary>
          <ul className="mt-2 border-t border-filo">{withdrawn.map((r) => <li key={r.uid} className="flex justify-between border-b-[0.5px] border-filo py-2 text-[14px]"><button className="hover:underline" onClick={() => setOpen(r)}>{person(r.uid)?.fullName ?? "Perfil eliminado"}</button><span className="text-suave">Retirada {fmtDate(r.withdrawnAt)}</span></li>)}</ul>
        </details>
      )}

      {view === "recomendados" && (
        <div className="mt-6 flex flex-col gap-3">
          <p className="ayuda">Profesionales activos de la comunidad que no se han presentado, ordenados por encaje. Las reglas son transparentes: especialidades (40), sector (15), disponibilidad (15), tipo de empresa (10), dedicación (10), colaboración (5) y modalidad (5). La tarifa se compara aparte.</p>
          {recos.length === 0 ? <Empty title="No hay perfiles para recomendar" text="Todos los perfiles activos ya se han presentado o la comunidad aún no tiene perfiles." /> : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {recos.map(({ p, f }, i) => (
                <PerfilCard key={p.uid} p={toPerfil(p)} label={label} highlight={i === 0 && f.score >= 70}
                  scoreBadge={<span className="flex items-baseline gap-1 rounded-full border border-white/70 bg-white/80 px-3 py-1 backdrop-blur-xl"><span className="font-display text-[26px] leading-none">{f.score}</span><span className="font-mono text-[10px] text-suave">/100</span></span>}
                  badges={<><span className="tag bg-blanco">N.º {i + 1}</span>{p.demo && <DemoTag />}</>}
                  footer={<InviteButton uid={p.uid} oppId={o.id} title={o.title} disabled={o.status !== "publicada"} />}>
                  <Criterios reasons={f.reasons} />
                </PerfilCard>
              ))}
            </div>
          )}
        </div>
      )}

      {open && <AppDrawer d={d} row={rows.find((r) => r.uid === open.uid) ?? open} onClose={() => setOpen(null)} onMove={move} />}
      <Modal open={cmpOpen} onClose={() => setCmpOpen(false)} title="Comparar candidatos" wide>
        <Compare d={d} uids={cmp} oppId={oppId} />
      </Modal>
    </Page>
  );
}

function InviteButton({ uid, oppId, title, disabled }: { uid: string; oppId: string; title: string; disabled?: boolean }) {
  const { session } = useApp();
  const toast = useToast();
  const [sent, setSent] = useState(false);
  return (
    <button className="btn btn-contorno btn-sm" disabled={disabled || sent} title={disabled ? "Publica la oportunidad para invitar" : undefined}
      onClick={async () => { if (!session.db) return; await notify(session.db, uid, `El equipo de Extandard te invita a presentar tu candidatura a «${title}».`, oppId); setSent(true); toast("Invitación enviada a su área privada."); }}>
      {sent ? "Invitación enviada" : "Invitar a presentarse"}
    </button>
  );
}

function AppDrawer({ d, row, onClose, onMove }: { d: AdminData; row: AppRow; onClose: () => void; onMove: (r: AppRow, s: Stage) => void }) {
  const { session, label } = useApp();
  const toast = useToast();
  const confirm = useConfirm();
  const p = d.people.find((x) => x.uid === row.uid);
  const o = d.opps.find((x) => x.id === row.oppId);
  const [next, setNext] = useState(row.pipe?.nextStep ?? "");
  const [notes, setNotes] = useState(row.pipe?.interviewNotes ?? "");
  const names = useNames(session.user, (row.pipe?.history ?? []).map((h) => h.by));
  const others = d.applications.filter((a) => a.uid === row.uid && a.oppId !== row.oppId);
  const f = p && o ? fit(p, o, label, true) : null;
  async function saveFields() {
    if (!session.db) return;
    try { await savePipelineFields(session.db, d, row, { nextStep: next.trim(), interviewNotes: notes.trim() }); toast("Seguimiento guardado."); } catch { toast("No se ha podido guardar.", "error"); }
  }
  return (
    <Drawer open onClose={onClose} title={<div className="flex flex-col gap-1.5"><span className="eyebrow">Candidatura · {row.title}</span><h2 className="font-display text-[28px] leading-tight">{p?.fullName ?? "Perfil eliminado"}</h2>{p && <span className="text-[14px] text-suave">{p.headline}</span>}</div>}>
      <div className="flex flex-col gap-8">
        <section className="grid gap-3 rounded-tarjeta bg-roto p-4 sm:grid-cols-2">
          <Field id="stage" label="Fase">
            {row.withdrawn ? <span className="tag border border-linea">Retirada el {fmtDate(row.withdrawnAt)}</span> : (
              <Select id="stage" value={row.stage} onChange={(e) => onMove(row, e.target.value as Stage)} options={STAGES.map((s) => ({ value: s.id, label: s.label }))} />
            )}
          </Field>
          <div className="flex flex-col gap-1.5"><span className="etiqueta">Presentada</span><span className="text-[14px]">{fmtDate(row.appliedAt, true)}</span>{p && <span className="text-[13px] text-suave">Perfil: {PROFILE_STATUS[p.status].label}</span>}</div>
        </section>
        <section className="flex flex-col gap-2"><h3 className="border-b border-filo pb-2 font-display text-[20px]">Mensaje del candidato</h3><p className="whitespace-pre-line">{row.motivation}</p></section>
        {f && <FitCard title="Encaje con esta oportunidad" score={f.score} reasons={f.reasons} />}
        <section className="flex flex-col gap-4">
          <h3 className="border-b border-filo pb-2 font-display text-[20px]">Seguimiento interno</h3>
          <Field id="nextStep" label="Próximo paso" optional><TextInput id="nextStep" value={next} onChange={(e) => setNext(e.target.value)} placeholder="Llamada con Alejandra el jueves" /></Field>
          <Field id="interviewNotes" label="Comentarios de entrevista y notas privadas" optional><TextArea id="interviewNotes" value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
          <div><button className="btn btn-negro btn-sm" onClick={saveFields}>Guardar seguimiento</button></div>
        </section>
        {(row.pipe?.history?.length ?? 0) > 0 && (
          <section className="flex flex-col gap-2"><h3 className="border-b border-filo pb-2 font-display text-[20px]">Historial</h3>
            <ul>{row.pipe!.history.slice().reverse().map((h, i) => <li key={i} className="border-b-[0.5px] border-linea py-2 text-[13px]"><span className="font-medium">{STAGES.find((s) => s.id === h.status)?.label ?? h.status}</span> · {names(h.by)} · {fmtDate(h.at, true)}</li>)}</ul>
          </section>
        )}
        {others.length > 0 && (
          <section className="flex flex-col gap-2"><h3 className="border-b border-filo pb-2 font-display text-[20px]">Otras candidaturas</h3>
            <ul>{others.map((a) => <li key={a.oppId} className="flex justify-between border-b-[0.5px] border-linea py-2 text-[13px]"><span>{a.title}</span><span className="text-suave">{a.withdrawn ? "Retirada" : STAGES.find((s) => s.id === a.stage)?.label}</span></li>)}</ul>
          </section>
        )}
        {p && <section className="flex flex-col gap-2"><h3 className="font-display text-[20px]">Perfil completo</h3><ProfileSummary p={p} label={label} showPrivate /></section>}
        {confirm.node}
      </div>
    </Drawer>
  );
}

function Compare({ d, uids, oppId }: { d: AdminData; uids: string[]; oppId: string }) {
  const { label } = useApp();
  const o = d.opps.find((x) => x.id === oppId)!;
  const ps = uids.map((u) => d.people.find((p) => p.uid === u)).filter(Boolean) as AdminData["people"];
  const rows: [string, (p: AdminData["people"][number]) => React.ReactNode][] = [
    ["Encaje", (p) => <span className="font-display text-[26px]">{fit(p, o, label).score}</span>],
    ["Titular", (p) => p.headline],
    ["Años", (p) => p.years],
    ["Especialidades", (p) => p.specialties.map((s) => <span key={s} className={`mr-1 inline-block ${o.specialties.includes(s) ? "marcador" : ""}`}>{label(s)};</span>)],
    ["Sectores", (p) => p.sectorsExpertise.map(label).join(", ")],
    ["Empresas", (p) => p.companyTypes.join(", ")],
    ["Disponibilidad", (p) => <AvailabilityDot value={p.availability} />],
    ["Dedicación", (p) => p.dedication],
    ["Colaboración", (p) => p.collaboration.join(", ")],
    ["Modalidad", (p) => p.workMode.join(", ")],
    ["Ubicación", (p) => `${p.location} · ${p.timezone}`],
    ["Tarifa mínima", (p) => (p.rateMin ? `${p.rateMin.toLocaleString("es-ES")} ${p.currency}/${p.rateType === "dia" ? "día" : "mes"}` : "—")],
    ["Idiomas", (p) => p.languages.join(", ")],
  ];
  return (
    <div className="flex flex-col gap-4">
    <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${ps.length}, minmax(0, 1fr))` }}>
      {ps.map((p) => <PerfilCard key={p.uid} compact p={toPerfil(p)} label={label} scoreBadge={<span className="flex items-baseline gap-1 rounded-full bg-white/80 px-2.5 py-0.5"><span className="font-display text-[20px] leading-none">{fit(p, o, label).score}</span><span className="font-mono text-[9px] text-suave">/100</span></span>} />)}
    </div>
    <div className="overflow-x-auto">
      <table className="tabla min-w-[640px]">
        <thead><tr><th /> {ps.map((p) => <th key={p.uid} className="!normal-case !text-[14px]">{p.fullName}</th>)}</tr></thead>
        <tbody>{rows.map(([k, fn]) => <tr key={k}><td className="whitespace-nowrap text-[13px] text-suave">{k}</td>{ps.map((p) => <td key={p.uid} className="text-[13px]">{fn(p)}</td>)}</tr>)}</tbody>
      </table>
      <p className="ayuda mt-3">Las especialidades marcadas en verde son las que pide la oportunidad.</p>
    </div>
    </div>
  );
}

