import { useEffect, useState } from "react";
import type { AuditEntry, InboxDoc, Notice, Profile, Review, ProfileStatus } from "./types";

/* ---------- Tipos mínimos del runtime de la plataforma ---------- */
export interface Snap { id: string; exists: boolean; data(): Record<string, unknown> | undefined }
export interface QSnap { docs: Snap[] }
export interface DocRef {
  id: string; path: string;
  get(): Promise<Snap>;
  set(d: Record<string, unknown>): Promise<void>;
  update(d: Record<string, unknown>): Promise<void>;
  delete(): Promise<void>;
  onSnapshot(n: (s: Snap) => void, e?: (err: { code: string; message: string }) => void): () => void;
}
export interface ColRef {
  path: string;
  doc(id?: string): DocRef;
  add(d: Record<string, unknown>): Promise<DocRef>;
  orderBy(f: string, dir?: "asc" | "desc"): ColRef;
  limit(n: number): ColRef;
  onSnapshot(n: (s: QSnap) => void, e?: (err: { code: string; message: string }) => void): () => void;
}
export interface DB { doc(p: string): DocRef; collection(p: string): ColRef }
export interface UserNS {
  canEdit(): Promise<boolean>;
  can(name: string): Promise<boolean | null>;
  id(): Promise<string | null>;
  me(): Promise<{ id: string | null; name: string; avatarUrl: string; isOwner: boolean; canEdit: boolean }>;
  profiles(ids: string[]): Promise<Record<string, { name: string; avatarUrl: string }>>;
}
declare global { interface Window { claude?: { use(name: string): Promise<unknown> } } }

/* ---------- Reglas de acceso declaradas al publicar (las aplica el servidor) ----------
   Profesional (nivel Contributor): lee y escribe SOLO su perfil, sus candidaturas y su bandeja;
   lee su estado de revisión y de candidaturas, que solo escribe el equipo.
   Equipo (Editor/Owner): lee y escribe todo. Las oportunidades internas, notas, etiquetas,
   pipeline y auditoría son invisibles para cualquier nivel inferior. */
export const RULES = [
  { path: "", read: "view", write: "admin" },
  { path: "profiles", read: "admin", write: "admin" }, { path: "profiles/{self}", read: "interact", write: "interact" },
  { path: "reviews", read: "admin", write: "admin" }, { path: "reviews/{self}", read: "interact", write: "admin" },
  { path: "apps", read: "admin", write: "admin" }, { path: "apps/{self}", read: "interact", write: "interact" },
  { path: "appStatus", read: "admin", write: "admin" }, { path: "appStatus/{self}", read: "interact", write: "admin" },
  { path: "inbox", read: "admin", write: "admin" }, { path: "inbox/{self}", read: "interact", write: "interact" },
  { path: "opps", read: "admin", write: "admin" },
  { path: "internal", read: "admin", write: "admin" },
  { path: "pipeline", read: "admin", write: "admin" },
  { path: "audit", read: "admin", write: "admin" },
];

/* ---------- Sesión ---------- */
export type Role = "equipo" | "profesional" | "lector" | "anonimo";
export interface Session { db: DB | null; user: UserNS | null; uid: string | null; role: Role; loading: boolean; name: string }

export function useSession(): Session {
  const [s, setS] = useState<Session>({ db: null, user: null, uid: null, role: "anonimo", loading: true, name: "" });
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!window.claude) { if (alive) setS((x) => ({ ...x, loading: false })); return; }
      const [db, user] = (await Promise.all([window.claude.use("db"), window.claude.use("user")])) as [DB | null, UserNS | null];
      if (!db || !user) { if (alive) setS({ db, user, uid: null, role: "anonimo", loading: false, name: "" }); return; }
      const [me, write] = await Promise.all([user.me(), user.can("data.write")]);
      let role: Role = "lector";
      if (me.canEdit) role = "equipo";
      else if (me.id && write !== false) role = "profesional";
      if (alive) setS({ db, user, uid: me.id, role, loading: false, name: me.name });
    })();
    return () => { alive = false; };
  }, []);
  return s;
}

/* ---------- Suscripciones en vivo ---------- */
export function useDoc<T>(db: DB | null, path: string | null): { data: T | null; ready: boolean } {
  const [st, setSt] = useState<{ data: T | null; ready: boolean }>({ data: null, ready: false });
  useEffect(() => {
    if (!db || !path) { setSt({ data: null, ready: true }); return; }
    setSt({ data: null, ready: false });
    return db.doc(path).onSnapshot(
      (s) => setSt({ data: s.exists ? (s.data() as T) : null, ready: true }),
      () => setSt({ data: null, ready: true }),
    );
  }, [db, path]);
  return st;
}

export function useCollection<T>(db: DB | null, path: string | null): { items: (T & { _id: string })[]; ready: boolean } {
  const [st, setSt] = useState<{ items: (T & { _id: string })[]; ready: boolean }>({ items: [], ready: false });
  useEffect(() => {
    if (!db || !path) { setSt({ items: [], ready: true }); return; }
    setSt({ items: [], ready: false });
    return db.collection(path).onSnapshot(
      (q) => setSt({ items: q.docs.filter((d) => d.exists).map((d) => ({ ...(d.data() as T), _id: d.id })), ready: true }),
      () => setSt({ items: [], ready: true }),
    );
  }, [db, path]);
  return st;
}

/* ---------- Utilidades ---------- */
export const now = () => new Date().toISOString();
export const rid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

/** Copia profunda segura para escribir (los snapshots están congelados). */
export const plain = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

export async function audit(db: DB, e: Omit<AuditEntry, "at">) {
  try { await db.collection("audit").add({ ...e, at: now() }); } catch { /* la auditoría nunca bloquea la acción */ }
}

/** Añade una notificación a la bandeja de una persona (máx. 60 guardadas). */
export async function notify(db: DB, uid: string, text: string, link?: string) {
  const ref = db.doc(`inbox/${uid}`);
  try {
    const snap = await ref.get();
    const cur = (snap.exists ? (snap.data() as unknown as InboxDoc) : { items: [] }).items ?? [];
    const n: Notice = { id: rid(), text, at: now(), read: false, ...(link ? { link } : {}) };
    await ref.set({ items: [n, ...plain(cur)].slice(0, 60) });
  } catch { /* sin bloqueo */ }
}

/** Estado efectivo del perfil, combinando lo que escribe el profesional y lo que decide el equipo. */
export function profileStatus(p: Profile | null | undefined, r: Review | null | undefined): ProfileStatus {
  // Comunidad abierta: el perfil queda activo al enviarlo. El equipo solo puede pedir información
  // (sin bloquear candidaturas) o pausarlo. La valoración se hace en cada candidatura.
  if (!p || !p.submittedAt) return "borrador";
  if (r?.status === "inactivo" || r?.status === "no_aceptado") return "inactivo";
  if (r?.status === "info_solicitada" && !(p.submittedAt > r.updatedAt)) return "info_solicitada";
  return "aprobado";
}

export function fmtDate(iso?: string | null, withTime = false) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("es-ES", { day: "numeric", month: "short", year: "numeric", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}) });
}

export function ago(iso?: string) {
  if (!iso) return "";
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return "ahora";
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`;
  if (s < 86400) return `hace ${Math.floor(s / 3600)} h`;
  if (s < 86400 * 30) return `hace ${Math.floor(s / 86400)} d`;
  return fmtDate(iso);
}

/** Nombres de miembros del equipo a partir de sus ids (nunca se guardan nombres). */
export function useNames(user: UserNS | null, ids: string[]) {
  const [names, setNames] = useState<Record<string, string>>({});
  const key = Array.from(new Set(ids.filter((i) => i && i.startsWith("u_")))).sort().join(",");
  useEffect(() => {
    if (!user || !key) return;
    let alive = true;
    user.profiles(key.split(",")).then((ps) => {
      if (!alive) return;
      const out: Record<string, string> = {};
      for (const [id, p] of Object.entries(ps)) out[id] = p.name || "Equipo";
      setNames(out);
    });
    return () => { alive = false; };
  }, [user, key]);
  return (id: string) => (id === "sistema" ? "Sistema (datos ficticios)" : names[id] || "Equipo");
}
