import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { AVAILABILITY, AREAS, areaOf, type AreaId } from "./constants";
import type { Availability } from "./types";

/* ---------- Marca ---------- */
const LOGO_SVG = `<g><g transform="matrix(1 0 0 1 974.73 0)"><path d="M0.00 114.42 C0.00 76.68 26.20 49.76 62.02 49.76 C76.44 49.76 89.90 56.01 97.60 63.46 L97.60 27.88 C97.60 14.90 92.55 12.50 80.05 14.42 L80.05 11.29 L114.66 0.00 L117.79 0.00 L117.79 155.77 C117.79 164.67 121.88 168.99 135.10 170.68 L135.10 173.80 L97.60 173.80 L97.60 147.12 C92.79 164.67 75.96 177.41 54.57 177.41 C22.11 177.41 0.00 150.00 0.00 114.42 Z M97.60 80.77 C92.55 67.07 81.01 54.81 63.70 54.81 C38.94 54.81 21.63 80.29 21.63 111.30 C21.63 141.59 37.98 165.63 63.70 165.63 C80.77 165.63 93.99 153.85 97.60 139.67 L97.60 80.77 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 868.08 49.76)"><path d="M93.03 37.26 C92.79 20.19 83.17 12.50 68.75 12.50 C54.08 12.50 42.55 23.79 37.74 38.70 L37.74 106.01 C37.74 116.83 45.19 119.23 61.30 120.91 L61.30 124.04 L0.00 124.04 L0.00 120.91 C9.85 119.23 17.54 116.83 17.54 106.01 L17.54 31.25 C17.54 18.51 12.02 15.86 0.00 18.03 L0.00 14.90 L34.61 3.60 L37.74 3.60 L37.74 30.77 C44.23 12.02 59.37 0.00 75.00 0.00 C85.58 0.00 95.67 4.56 100.48 8.89 L96.15 37.74 L93.03 37.26 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 745.08 49.76)"><path d="M43.51 127.65 C24.03 127.65 9.13 113.94 9.13 95.91 C9.13 72.11 26.92 59.61 69.95 50.48 L79.57 48.56 L79.57 44.71 C79.57 21.39 65.62 5.04 46.15 5.04 C25.96 5.04 11.29 22.35 12.98 45.67 L10.09 46.63 L0.00 25.72 C7.93 11.53 25.24 0.00 47.11 0.00 C78.36 0.00 99.76 17.06 99.76 48.56 L99.76 106.01 C99.76 114.90 103.85 119.23 117.07 120.91 L117.07 124.04 L79.57 124.04 L79.57 102.16 C72.11 118.51 58.89 127.65 43.51 127.65 Z M29.80 93.03 C29.80 105.77 39.18 115.87 52.16 115.87 C64.90 115.87 73.32 107.69 79.57 96.87 L79.57 53.60 L70.43 56.25 C41.58 63.94 29.80 75.72 29.80 93.03 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 601.22 0)"><path d="M0.00 114.42 C0.00 76.68 26.20 49.76 62.02 49.76 C76.44 49.76 89.90 56.01 97.60 63.46 L97.60 27.88 C97.60 14.90 92.55 12.50 80.05 14.42 L80.05 11.29 L114.66 0.00 L117.79 0.00 L117.79 155.77 C117.79 164.67 121.88 168.99 135.10 170.68 L135.10 173.80 L97.60 173.80 L97.60 147.12 C92.79 164.67 75.96 177.41 54.57 177.41 C22.11 177.41 0.00 150.00 0.00 114.42 Z M97.60 80.77 C92.55 67.07 81.01 54.81 63.70 54.81 C38.94 54.81 21.63 80.29 21.63 111.30 C21.63 141.59 37.98 165.63 63.70 165.63 C80.77 165.63 93.99 153.85 97.60 139.67 L97.60 80.77 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 453.73 49.76)"><path d="M0.00 120.91 C13.22 119.23 17.54 114.90 17.54 106.01 L17.54 31.25 C17.54 18.51 12.02 15.86 0.00 18.03 L0.00 14.90 L34.61 3.60 L37.74 3.60 L37.74 25.48 C48.31 9.61 63.94 0.00 80.77 0.00 C105.29 0.00 120.67 15.62 120.67 40.62 L120.67 106.01 C120.67 114.90 125.00 119.23 138.22 120.91 L138.22 124.04 L83.17 124.04 L83.17 120.91 C96.39 119.23 100.48 114.90 100.48 106.01 L100.48 41.58 C100.48 24.28 89.66 10.33 72.84 10.33 C59.37 10.33 46.39 18.99 37.74 31.25 L37.74 106.01 C37.74 114.90 41.82 119.23 55.05 120.91 L55.05 124.04 L0.00 124.04 L0.00 120.91 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 330.73 49.76)"><path d="M43.51 127.65 C24.04 127.65 9.13 113.94 9.13 95.91 C9.13 72.11 26.92 59.61 69.95 50.48 L79.57 48.56 L79.57 44.71 C79.57 21.39 65.62 5.04 46.15 5.04 C25.96 5.04 11.29 22.35 12.98 45.67 L10.09 46.63 L0.00 25.72 C7.93 11.53 25.24 0.00 47.11 0.00 C78.36 0.00 99.76 17.06 99.76 48.56 L99.76 106.01 C99.76 114.90 103.85 119.23 117.07 120.91 L117.07 124.04 L79.57 124.04 L79.57 102.16 C72.11 118.51 58.89 127.65 43.51 127.65 Z M29.80 93.03 C29.80 105.77 39.18 115.87 52.16 115.87 C64.90 115.87 73.32 107.69 79.57 96.87 L79.57 53.60 L70.43 56.25 C41.58 63.94 29.80 75.72 29.80 93.03 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 243.32 20.19)"><path d="M82.21 131.97 C75.96 147.84 64.66 157.21 50.00 157.21 C30.53 157.21 18.27 145.19 18.27 125.48 L18.27 38.22 L0.00 38.22 L0.00 34.13 C10.57 33.17 25.72 25.48 34.37 0.00 L38.46 0.00 L38.46 33.17 L75.00 29.08 L76.20 38.22 L38.46 38.22 L38.46 123.56 C38.46 137.74 45.43 146.16 57.69 146.16 C64.66 146.16 72.84 142.07 79.09 130.29 L82.21 131.97 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 115.08 53.36)"><path d="M73.80 117.31 C87.74 115.39 87.50 111.78 81.73 103.37 L56.49 66.34 L31.49 102.40 C25.48 111.06 23.55 116.11 38.46 117.31 L38.46 120.43 L0.00 120.43 L0.00 117.31 C10.81 116.11 15.38 113.94 25.00 101.44 L53.84 62.26 L22.59 16.58 C15.38 6.01 10.57 4.08 0.24 3.12 L0.24 0.00 L54.57 0.00 L54.57 3.12 C40.86 4.08 41.34 8.17 47.11 16.58 L69.23 49.04 L90.62 18.27 C96.87 9.61 98.08 4.32 82.93 3.12 L82.93 0.00 L121.64 0.00 L121.64 3.12 C110.82 4.32 106.25 6.73 96.87 19.23 L72.11 53.36 L106.01 103.37 C113.46 114.18 118.99 116.11 128.13 117.31 L128.13 120.43 L73.80 120.43 L73.80 117.31 Z" fill="currentColor"/></g><g transform="matrix(1 0 0 1 0 49.76)"><path d="M62.50 127.65 C26.92 127.65 0.00 100.48 0.00 63.94 C0.00 27.40 25.00 0.00 59.85 0.00 C93.51 0.00 110.10 24.04 106.01 52.64 L21.15 52.64 L20.91 58.41 C20.91 90.86 40.86 114.90 70.91 114.90 C91.11 114.90 106.25 102.16 113.22 87.02 L116.35 88.46 C109.38 111.54 91.11 127.65 62.50 127.65 Z M21.63 48.07 L86.30 45.19 C89.90 23.55 78.12 5.04 58.41 5.04 C38.94 5.04 24.52 23.31 21.63 48.07 Z" fill="currentColor"/></g></g>`;

export function Logo({ height = 26, color = "#000" }: { height?: number; color?: string }) {
  return <svg viewBox="0 0 1109.83 177.41" height={height} role="img" aria-label="extandard" style={{ color, display: "block", width: "auto" }} dangerouslySetInnerHTML={{ __html: LOGO_SVG }} />;
}

/** Isotipo: una barra vertical y tres horizontales (612×441). */
export function Isotipo({ height = 64, color = "#1D1D1B", stroke = 4 }: { height?: number; color?: string; stroke?: number }) {
  return (
    <svg viewBox="0 0 612 441" height={height} aria-hidden="true" style={{ display: "block", width: "auto", color }}>
      <rect x="2" y="0" width={stroke} height="441" fill="currentColor" />
      <rect x="0" y="1" width="612" height={stroke} fill="currentColor" />
      <rect x="0" y={222 - stroke / 2 + 2} width="612" height={stroke} fill="currentColor" />
      <rect x="0" y={441 - stroke} width="612" height={stroke} fill="currentColor" />
    </svg>
  );
}

/* ---------- Estados ---------- */
export function StatusTag({ label, style }: { label: string; style: string }) {
  return <span className={`tag ${style}`}>{label}</span>;
}

export function AvailabilityDot({ value, withLabel = true }: { value: Availability; withLabel?: boolean }) {
  const a = AVAILABILITY[value] ?? AVAILABILITY.no_disponible;
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap text-[13px]">
      <span className="punto" style={{ background: a.dot, color: a.dot }} aria-hidden="true" />
      {withLabel && a.label}
    </span>
  );
}

export function DemoTag() {
  return <span className="tag bg-blanco" title="Dato ficticio de demostración">Ficticio</span>;
}

export function Spinner({ label = "Cargando" }: { label?: string }) {
  return <span className="inline-flex items-center gap-3 text-suave" role="status"><span className="cargando" />{label}</span>;
}

/** Carga: esqueletos de cristal animados, nunca ruedas. */
export function LoadingBlock({ label = "Cargando" }: { label?: string }) {
  return (
    <div className="flex flex-col gap-3 py-6" role="status">
      <span className="sr-only">{label}</span>
      <div className="esqueleto h-[120px]" />
      <div className="grid gap-3 sm:grid-cols-3"><div className="esqueleto h-[96px]" /><div className="esqueleto h-[96px]" /><div className="esqueleto h-[96px]" /></div>
      <div className="esqueleto h-[64px]" /><div className="esqueleto h-[64px] opacity-70" />
    </div>
  );
}

export function Empty({ title, text, action }: { title: string; text: string; action?: React.ReactNode }) {
  return (
    <div className="bento tarjeta-roto flex flex-col items-start gap-4 px-7 py-9">
      <span className="glow glow-celeste -right-24 -top-28 w-[300px] opacity-60" aria-hidden="true" />
      <Isotipo height={34} />
      <div className="flex flex-col gap-1.5 max-w-[52ch]">
        <h3 className="font-display text-[22px] leading-tight">{title}</h3>
        <p className="text-suave">{text}</p>
      </div>
      {action}
    </div>
  );
}

export function SectionHead({ eyebrow, title, text, actions }: { eyebrow?: string; title: React.ReactNode; text?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="bento flex flex-wrap items-end justify-between gap-x-8 gap-y-5 px-6 py-9 md:px-10 md:py-12">
      <span className="glow glow-celeste -left-20 -top-40 w-[420px] opacity-70" aria-hidden="true" />
      <span className="glow glow-verde -right-10 -top-24 w-[300px] opacity-50" aria-hidden="true" />
      <span className="glow glow-amarillo bottom-[-180px] right-[22%] w-[320px] opacity-45" aria-hidden="true" />
      <div className="vidrio absolute inset-0 -z-[1] !rounded-[28px] !bg-white/45" aria-hidden="true" />
      <div className="flex min-w-0 flex-col gap-3">
        {eyebrow && <span className="eyebrow flex items-center gap-2"><span className="punto" style={{ background: "#00FF00", color: "#00FF00" }} />{eyebrow}</span>}
        <h1 className="font-display text-[36px] leading-[1] tracking-[-0.02em] md:text-[52px]">{title}</h1>
        {text && <p className="max-w-[62ch] text-suave">{text}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

/** Cuenta corta al cargar (respeta movimiento reducido). */
export function CountUp({ value }: { value: React.ReactNode }) {
  const m = typeof value === "number" ? { n: value, suf: "" } : typeof value === "string" && /^\d+%?$/.test(value) ? { n: parseInt(value, 10), suf: value.endsWith("%") ? "%" : "" } : null;
  const [v, setV] = useState(m ? 0 : 0);
  useEffect(() => {
    if (!m) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduce || m.n === 0) { setV(m.n); return; }
    let raf = 0; const t0 = performance.now(); const dur = 700;
    const tick = (t: number) => { const k = Math.min(1, (t - t0) / dur); setV(Math.round(m.n * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [m?.n]); // eslint-disable-line react-hooks/exhaustive-deps
  return <>{m ? `${v}${m.suf}` : value}</>;
}

/** Tarjeta de métrica: cifra grande sobre resplandor de color, etiqueta en mono y flecha en círculo. */
export function Stat({ value, label, onClick, accent, color = "celeste" }: { value: React.ReactNode; label: string; onClick?: () => void; accent?: boolean; color?: "celeste" | "azul" | "amarillo" | "magenta" | "ambar" | "verde" }) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag onClick={onClick} className={`bento tarjeta-roto flex min-h-[148px] min-w-0 flex-col justify-between gap-4 p-5 text-left ${accent ? "borde-conexion" : ""} ${onClick ? "group elevar cursor-pointer" : ""}`}>
      <span className={`glow ${accent ? "glow-verde" : `glow-${color}`} -left-6 -top-10 w-[150px] ${accent ? "opacity-90" : "opacity-55"}`} aria-hidden="true" />
      <span className="font-display tnum text-[48px] leading-[.9]"><CountUp value={value} /></span>
      <span className="flex items-end justify-between gap-3">
        <span className="font-mono text-[10.5px] uppercase leading-snug tracking-[.07em] text-suave group-hover:text-negro">{label}</span>
        {onClick && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-negro text-blanco transition-colors group-hover:bg-verde group-hover:text-negro" aria-hidden="true"><Arrow size={11} /></span>}
      </span>
    </Tag>
  );
}

/* ---------- Conectar: avatar, tarjeta de perfil, píldora de conexión y proceso ---------- */
export function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "·";
}

/** Avatar sin foto: iniciales sobre el color de su área principal, con resplandor suave. */
export function Avatar({ name, areas, size = 56 }: { name: string; areas: AreaId[]; size?: number }) {
  const a = AREAS[areas[0] ?? "producto"].color;
  return (
    <span className="relative inline-grid shrink-0 place-items-center rounded-full font-display text-negro" style={{ width: size, height: size, fontSize: size * 0.36, background: a, boxShadow: `0 0 0 3px rgba(255,255,255,.8), 0 10px 26px -10px ${a}` }} aria-hidden="true">
      <span className="grid h-[78%] w-[78%] place-items-center rounded-full bg-white/75 backdrop-blur">{initials(name)}</span>
    </span>
  );
}

export interface PerfilData { name: string; headline: string; specialties: string[]; years: number | null; sector: string; dedication: string; availability?: Availability; quote?: string; place?: string; foto?: { src: string; fondo: string } }

/** Colores sobre los que el texto va en blanco. */
const AREA_TEXTO_BLANCO: AreaId[] = ["estrategia", "demanda"];

/**
 * Tarjeta de perfil de CMO (misma en portada, comunidad, candidaturas y recomendados):
 * bloque de foto sobre el color del área principal, placa de cristal con nombre y especialidad,
 * y debajo frase, datos en mono, etiquetas neutras y pie. Un solo color por tarjeta.
 */
export function PerfilCard({ p, label, badges, scoreBadge, placaExtra, footer, children, onClick, highlight, compact, className = "" }: {
  p: PerfilData; label: (id: string) => string; badges?: React.ReactNode; scoreBadge?: React.ReactNode; placaExtra?: React.ReactNode;
  footer?: React.ReactNode; children?: React.ReactNode; onClick?: () => void; highlight?: boolean; compact?: boolean; className?: string;
}) {
  const areas = Array.from(new Set(p.specialties.map(areaOf))) as AreaId[];
  const area = areas[0] ?? "producto";
  const color = AREAS[area].color;
  const blanco = AREA_TEXTO_BLANCO.includes(area);
  const main = p.specialties[0];
  const extra = p.specialties.slice(1);
  const act = onClick ? { role: "button", tabIndex: 0, onClick, onKeyDown: (e: React.KeyboardEvent) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(); } } } : {};
  return (
    <div {...act} className={`bento tarjeta-roto group flex h-full w-full flex-col p-2 text-left ${onClick ? "elevar cursor-pointer" : ""} ${highlight ? "borde-conexion" : ""} ${className}`}>
      <span className={`glow ${AREAS[area].glow} -bottom-16 left-1/2 w-[220px] -translate-x-1/2 opacity-0 transition-opacity duration-300 group-hover:opacity-60`} aria-hidden="true" />
      {/* Bloque de foto: sin foto, iniciales grandes sobre el color del área */}
      <div className="relative overflow-hidden rounded-[22px]" style={{ background: p.foto?.fondo ?? color, aspectRatio: p.foto ? (compact ? "4 / 3.6" : "4 / 4.5") : compact ? "4 / 3.2" : "1 / 0.9" }}>
        {p.foto ? (
          <>
            <img src={p.foto.src} alt={`Retrato de ${p.name}`} loading="lazy" draggable={false} className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" style={{ objectPosition: compact ? "50% 18%" : "50% 12%" }} />
            <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1/2" style={{ background: `linear-gradient(to top, ${p.foto.fondo}, ${p.foto.fondo}00)` }} />
          </>
        ) : (
          <>
            <span aria-hidden="true" className="absolute inset-0" style={{ background: "radial-gradient(120% 80% at 20% 0%, rgba(255,255,255,.45), rgba(255,255,255,0) 55%)" }} />
            <span aria-hidden="true" className={`absolute font-display leading-none tracking-[-0.04em] ${blanco ? "text-white/90" : "text-black/80"}`} style={{ left: compact ? 12 : 18, top: compact ? 10 : 16, fontSize: compact ? 44 : 92 }}>{initials(p.name)}</span>
          </>
        )}
        {scoreBadge && <div className="absolute left-2.5 top-2.5">{scoreBadge}</div>}
        {badges && <div className="absolute right-2.5 top-2.5 flex flex-col items-end gap-1.5">{badges}</div>}
        <div className="absolute inset-x-2 bottom-2 flex items-center gap-2 rounded-[16px] border border-white/70 bg-white/80 px-3 py-2.5 backdrop-blur-xl">
          <div className="min-w-0 flex-1">
            <div className={`font-display leading-[1.05] ${compact ? "line-clamp-2 text-[15px]" : "truncate text-[20px]"}`}>{p.name}</div>
            {main && <div className="flex items-center gap-1.5 truncate text-[12px] text-suave"><span className="punto !h-1.5 !w-1.5" style={{ background: color, color }} /><span className="truncate">{label(main)}</span></div>}
          </div>
          {placaExtra}
          {!compact && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-negro text-verde transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true"><Arrow size={11} /></span>}
        </div>
      </div>
      {/* Datos */}
      <div className={`flex flex-1 flex-col gap-2.5 px-2.5 pb-1.5 ${compact ? "pt-2.5" : "pt-3.5"}`}>
        {!compact && (p.quote || p.headline) && <p className="line-clamp-2 text-[13.5px] leading-snug text-suave"><span className="mr-1 font-display text-[18px] leading-none text-negro">“</span>{p.quote || p.headline}</p>}
        <p className="font-mono text-[10.5px] uppercase tracking-[.05em] text-negro/80">{[p.years ? `${p.years} años` : null, p.sector ? label(p.sector) : null, p.dedication || null].filter(Boolean).join(" · ")}</p>
        {!compact && extra.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {extra.slice(0, 2).map((s) => <span key={s} className="tag bg-blanco">{label(s)}</span>)}
            {extra.length > 2 && <span className="tag bg-blanco">+{extra.length - 2}</span>}
          </div>
        )}
        {children}
        {(p.place || footer) && (
          <div className="mt-auto flex flex-wrap items-center justify-between gap-2 border-t border-filo pt-2.5">
            {p.place && <span className="font-mono text-[10.5px] uppercase tracking-[.05em] text-suave">{p.place}</span>}
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/** Píldora de conexión: un extremo con cada parte, el texto en el centro y un degradado de un lado a otro. */
export function Conexion({ left, right, children, from = "#43CCFF", to = "#00FF00", className = "" }: { left: React.ReactNode; right: React.ReactNode; children: React.ReactNode; from?: string; to?: string; className?: string }) {
  return (
    <div className={`relative inline-flex items-center gap-3 rounded-full p-1.5 pr-1.5 shadow-flotante ${className}`} style={{ background: `linear-gradient(90deg, ${from}, ${to})` }}>
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-white/85 backdrop-blur">{left}</span>
      <span className="flex items-center gap-3 px-1 text-[14px] font-medium text-negro">{children}</span>
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-white/85 backdrop-blur">{right}</span>
    </div>
  );
}

/** Flecha dentro de un círculo: aparece donde dos elementos se encuentran. */
export function Conector({ size = 32, className = "" }: { size?: number; className?: string }) {
  return <span className={`grid shrink-0 place-items-center rounded-full bg-negro text-verde shadow-[0_0_0_4px_rgba(255,255,255,.75),0_8px_20px_-6px_rgba(0,0,0,.45)] ${className}`} style={{ width: size, height: size }} aria-hidden="true"><Arrow size={size * 0.36} /></span>;
}

/** Proceso horizontal con contador y conector de degradado entre pasos. */
export function Proceso({ pasos, actual }: { pasos: { label: string; count?: number; onClick?: () => void }[]; actual?: number }) {
  return (
    <ol className="flex w-full items-center overflow-x-auto pb-1">
      {pasos.map((p, i) => {
        const on = actual === undefined ? (p.count ?? 0) > 0 : i <= actual;
        const B = p.onClick ? "button" : "div";
        return (
          <li key={p.label} className="flex min-w-[130px] flex-1 items-center">
            <B onClick={p.onClick} className="flex flex-col items-center gap-2 px-1 text-center">
              <span className={`relative grid h-11 w-11 place-items-center rounded-full font-mono text-[13px] font-medium transition-colors duration-200 ${on ? "bg-verde text-negro shadow-[0_0_0_4px_rgba(255,255,255,.8),0_0_24px_4px_rgba(0,255,0,.55)]" : "vidrio !rounded-full text-suave"}`}>
                {p.count ?? String(i + 1).padStart(2, "0")}
              </span>
              <span className={`max-w-[120px] text-[12.5px] leading-tight ${on ? "font-medium" : "text-suave"}`}>{p.label}</span>
            </B>
            {i < pasos.length - 1 && <span className="mx-1 mb-6 h-[3px] min-w-[24px] flex-1 rounded-full" style={{ background: on ? "linear-gradient(90deg, #00FF00, #43CCFF)" : "rgba(10,20,40,.08)" }} aria-hidden="true" />}
          </li>
        );
      })}
    </ol>
  );
}

/* ---------- Formularios ---------- */
export function Field({ id, label, help, error, optional, children }: { id: string; label: string; help?: string; error?: string; optional?: boolean; children: React.ReactNode }) {
  return (
    <div className="campo">
      <label className="etiqueta" htmlFor={id}>{label}{optional && <span className="font-normal text-suave"> · opcional</span>}</label>
      {children}
      {help && !error && <span className="ayuda" id={`${id}-ayuda`}>{help}</span>}
      {error && <span className="error" id={`${id}-error`}>{error}</span>}
    </div>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }) {
  const { invalid, className, ...rest } = props;
  return <input {...rest} className={`entrada ${className ?? ""}`} aria-invalid={invalid || undefined} />;
}
export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }) {
  const { invalid, className, ...rest } = props;
  return <textarea {...rest} className={`entrada ${className ?? ""}`} aria-invalid={invalid || undefined} />;
}
export function Select({ options, placeholder, invalid, ...rest }: React.SelectHTMLAttributes<HTMLSelectElement> & { options: (string | { value: string; label: string })[]; placeholder?: string; invalid?: boolean }) {
  return (
    <select {...rest} className={`entrada ${rest.className ?? ""}`} aria-invalid={invalid || undefined}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {options.map((o) => typeof o === "string" ? <option key={o} value={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

/** Selección múltiple con chips (viñetas de la marca). */
export function ChipSelect({ id, options, value, onChange, max }: { id: string; options: { value: string; label: string }[]; value: string[]; onChange: (v: string[]) => void; max?: number }) {
  return (
    <div id={id} role="group" className="flex flex-wrap gap-2">
      {options.map((o) => {
        const on = value.includes(o.value);
        return (
          <button key={o.value} type="button" className="chip" aria-pressed={on}
            onClick={() => onChange(on ? value.filter((v) => v !== o.value) : max && value.length >= max ? value : [...value, o.value])}>
            {on && <svg width="10" height="8" viewBox="0 0 10 8" aria-hidden="true"><path d="M1 4l3 3 5-6" stroke="currentColor" strokeWidth="1.5" fill="none" /></svg>}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Capas ---------- */
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", k);
    ref.current?.querySelector<HTMLElement>("input,textarea,select,button")?.focus();
    return () => document.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-[rgba(20,35,70,.22)] p-4 backdrop-blur-[6px]" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title}
        className={`aparecer vidrio-alto max-h-[90vh] w-full overflow-y-auto rounded-tarjeta p-6 md:p-8 ${wide ? "max-w-[880px]" : "max-w-[560px]"}`}>
        <div className="mb-5 flex items-start justify-between gap-4">
          <h2 className="font-display text-[26px] leading-tight">{title}</h2>
          <button className="btn btn-contorno btn-sm !px-3" onClick={onClose} aria-label="Cerrar">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Drawer({ open, onClose, title, children, actions }: { open: boolean; onClose: () => void; title: React.ReactNode; children: React.ReactNode; actions?: React.ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", k);
    return () => document.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-[rgba(20,35,70,.18)] backdrop-blur-[4px]" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside role="dialog" aria-modal="true" className="aparecer vidrio-alto flex h-full w-full max-w-[760px] flex-col md:my-3 md:mr-3 md:h-[calc(100%-24px)] md:rounded-[28px]"
        style={{ paddingTop: "env(safe-area-inset-top,0px)", paddingBottom: "env(safe-area-inset-bottom,0px)", paddingRight: "env(safe-area-inset-right,0px)" }}>
        <header className="flex items-start justify-between gap-4 border-b border-filo px-5 py-4 md:px-8">
          <div className="min-w-0">{title}</div>
          <div className="flex shrink-0 items-center gap-2">{actions}<button className="btn btn-contorno btn-sm !px-3" onClick={onClose} aria-label="Cerrar">✕</button></div>
        </header>
        <div className="flex-1 overflow-y-auto px-5 py-6 md:px-8">{children}</div>
      </aside>
    </div>
  );
}

/* ---------- Avisos ---------- */
type Toast = { id: number; text: string; kind: "ok" | "error" };
const ToastCtx = createContext<(text: string, kind?: "ok" | "error") => void>(() => {});
export function useToast() { return useContext(ToastCtx); }
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [list, setList] = useState<Toast[]>([]);
  const push = useCallback((text: string, kind: "ok" | "error" = "ok") => {
    const id = Date.now() + Math.random();
    setList((l) => [...l, { id, text, kind }]);
    setTimeout(() => setList((l) => l.filter((t) => t.id !== id)), kind === "error" ? 7000 : 3800);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed z-[60] flex flex-col gap-2" aria-live="polite"
        style={{ bottom: "calc(16px + env(safe-area-inset-bottom,0px))", right: "max(16px, env(safe-area-inset-right,0px))", left: "max(16px, env(safe-area-inset-left,0px))", alignItems: "flex-end" }}>
        {list.map((t) => (
          <div key={t.id} className="aparecer vidrio-alto pointer-events-auto flex max-w-[420px] items-center gap-3 rounded-full px-5 py-3 text-[14px]">
            <span className="punto" style={{ background: t.kind === "ok" ? "#00FF00" : "#FF0085", color: t.kind === "ok" ? "#00FF00" : "#FF0085" }} aria-hidden="true" />
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/** Confirmación integrada (el visor no muestra confirm()). */
export function useConfirm() {
  const [state, setState] = useState<{ title: string; text: string; cta: string; resolve: (v: boolean) => void } | null>(null);
  const ask = (title: string, text: string, cta = "Confirmar") => new Promise<boolean>((resolve) => setState({ title, text, cta, resolve }));
  const node = (
    <Modal open={!!state} title={state?.title ?? ""} onClose={() => { state?.resolve(false); setState(null); }}>
      <p className="mb-6 text-suave">{state?.text}</p>
      <div className="flex flex-wrap justify-end gap-2">
        <button className="btn btn-contorno" onClick={() => { state?.resolve(false); setState(null); }}>Cancelar</button>
        <button className="btn btn-negro" onClick={() => { state?.resolve(true); setState(null); }}>{state?.cta}</button>
      </div>
    </Modal>
  );
  return { ask, node };
}

export function Pager({ page, pages, onPage }: { page: number; pages: number; onPage: (p: number) => void }) {
  if (pages <= 1) return null;
  return (
    <div className="flex items-center justify-end gap-3 pt-4 text-[13px]">
      <button className="btn btn-contorno btn-sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>Anterior</button>
      <span className="tnum text-suave">Página {page} de {pages}</span>
      <button className="btn btn-contorno btn-sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>Siguiente</button>
    </div>
  );
}

export function Arrow({ dir = "derecha", size = 14 }: { dir?: "derecha" | "izquierda"; size?: number }) {
  const d = dir === "izquierda" ? "M30 13.5H2M2 13.5L14 1.5M2 13.5L14 25.5" : "M2 13.5H30M30 13.5L18 1.5M30 13.5L18 25.5";
  return <svg viewBox="0 0 32 27" width={size} height={size * 27 / 32} aria-hidden="true"><path d={d} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="square" /></svg>;
}
