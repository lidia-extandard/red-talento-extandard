import type { Availability, AppPublicStatus, OppStatus, ProfileStatus, Stage, Catalog } from "./types";

export const DEFAULT_CATALOG: Catalog = {
  specialties: [
    ["estrategia", "Estrategia de marketing"], ["gtm", "Estrategia go-to-market"], ["posicionamiento", "Posicionamiento de marca y propuesta de valor"],
    ["demanda", "Generación de demanda"], ["performance", "Marketing de rendimiento"], ["growth", "Growth marketing"],
    ["product", "Product marketing"], ["mops", "Marketing operations y automatización"], ["crm", "CRM y marketing de ciclo de vida"],
    ["equipos", "Dirección y desarrollo de equipos"], ["internacional", "Expansión internacional"], ["b2b", "Marketing B2B"],
    ["b2c", "Marketing B2C"], ["ecommerce", "Comercio electrónico"], ["saas", "SaaS y tecnología"], ["otras", "Otras especialidades"],
  ].map(([id, label]) => ({ id, label })),
  sectors: [
    ["saas", "Software / SaaS"], ["fintech", "Fintech y servicios financieros"], ["salud", "Salud y bienestar"], ["retail", "Retail y consumo"],
    ["industria", "Industria"], ["educacion", "Educación"], ["rrhh", "RR. HH. y talento"], ["logistica", "Logística y movilidad"],
    ["energia", "Energía y sostenibilidad"], ["servicios", "Servicios profesionales"], ["turismo", "Turismo y hostelería"], ["otros", "Otros"],
  ].map(([id, label]) => ({ id, label })),
};

export const COMPANY_TYPES = ["Startup", "Scale-up", "Pyme", "Gran empresa"];
export const COMPANY_SIZES = ["1–10", "11–50", "51–200", "201–1.000", "+1.000"];
export const LANGUAGES = ["Español", "Inglés", "Francés", "Alemán", "Portugués", "Italiano", "Catalán", "Otro"];
export const TIMEZONES = ["Europe/Madrid (CET)", "Europe/London (GMT)", "Europe/Lisbon (WET)", "Atlantic/Canary (WET)", "America/Mexico_City", "America/Bogota", "America/Buenos_Aires", "America/New_York", "Otra"];
export const DEDICATIONS = ["Algunos días al mes", "Un día por semana", "Varios días por semana", "Flexible"];
export const COLLABORATIONS = ["Fractional CMO recurrente", "Proyecto cerrado", "Dirección interina", "Asesoramiento estratégico", "Otras modalidades"];
export const WORK_MODES = ["Remoto", "Híbrido", "Presencial"];
export const CURRENCIES = ["EUR", "USD", "GBP"];
export const TEAM_LEADERSHIP = ["Sin equipo a cargo", "Hasta 5 personas", "6–15 personas", "Más de 15 personas"];

export const AVAILABILITY: Record<Availability, { label: string; dot: string }> = {
  disponible: { label: "Disponible", dot: "#00FF00" },
  proximamente: { label: "Disponible próximamente", dot: "#43CCFF" },
  limitada: { label: "Disponibilidad limitada", dot: "#FFD917" },
  no_disponible: { label: "No disponible", dot: "#A9AEB8" },
};

export const PROFILE_STATUS: Record<ProfileStatus, { label: string; style: string; hint: string }> = {
  borrador: { label: "Borrador", style: "border border-dashed border-filo", hint: "Tu perfil aún no se ha enviado. Termínalo para entrar en la comunidad." },
  enviado: { label: "Activo", style: "bg-verde", hint: "Formas parte de la comunidad. Ya puedes presentarte a las oportunidades." },
  revision: { label: "Activo", style: "bg-verde", hint: "Formas parte de la comunidad. Ya puedes presentarte a las oportunidades." },
  info_solicitada: { label: "Información solicitada", style: "bg-amarillo", hint: "Tu perfil sigue activo, pero el equipo te pide completar o aclarar algunos datos." },
  aprobado: { label: "Activo", style: "bg-verde", hint: "Formas parte de la comunidad. Ya puedes presentarte a las oportunidades." },
  no_aceptado: { label: "Inactivo", style: "border border-linea text-suave", hint: "Tu perfil está pausado en la red." },
  inactivo: { label: "Inactivo", style: "border border-linea text-suave", hint: "Tu perfil está pausado en la red." },
};

/** Comunidad abierta: un perfil enviado está activo (aunque el equipo le haya pedido información). */
export const isActive = (s: ProfileStatus) => s === "aprobado" || s === "info_solicitada";

export const OPP_STATUS: Record<OppStatus, { label: string; style: string }> = {
  borrador: { label: "Borrador", style: "border border-dashed border-filo" },
  publicada: { label: "Publicada", style: "bg-verde" },
  pausada: { label: "Pausada", style: "bg-amarillo" },
  cerrada: { label: "Cerrada", style: "bg-negro text-blanco" },
  archivada: { label: "Archivada", style: "border border-linea text-suave" },
};

export const STAGES: { id: Stage; label: string }[] = [
  { id: "nueva", label: "Nuevas candidaturas" },
  { id: "revision", label: "En revisión" },
  { id: "preseleccionada", label: "Preseleccionados" },
  { id: "entrevista", label: "Entrevista" },
  { id: "seleccionada", label: "Seleccionados" },
  { id: "no_seleccionada", label: "No seleccionados" },
];

export const STAGE_TO_PUBLIC: Record<Stage, AppPublicStatus> = {
  nueva: "presentada", revision: "revision", preseleccionada: "preseleccionada", entrevista: "entrevista", seleccionada: "seleccionada", no_seleccionada: "no_seleccionada",
};

export const APP_STATUS: Record<AppPublicStatus, { label: string; style: string }> = {
  presentada: { label: "Presentada", style: "bg-roto border border-filo" },
  revision: { label: "En revisión", style: "bg-celeste" },
  preseleccionada: { label: "Preseleccionada", style: "bg-amarillo" },
  entrevista: { label: "Entrevista o reunión", style: "bg-amarillo" },
  seleccionada: { label: "Seleccionada", style: "bg-verde" },
  no_seleccionada: { label: "No seleccionada", style: "bg-negro text-blanco" },
  retirada: { label: "Retirada", style: "border border-linea text-suave" },
};

/* Áreas de expertise: un color de la paleta ampliada por área (atmósfera de cada perfil). */
export const AREAS = {
  estrategia: { label: "Estrategia", color: "#0B70FE", glow: "glow-azul" },
  demanda: { label: "Demanda y growth", color: "#FF0085", glow: "glow-magenta" },
  producto: { label: "Producto y SaaS", color: "#43CCFF", glow: "glow-celeste" },
  operaciones: { label: "Operaciones y equipos", color: "#FF9F00", glow: "glow-ambar" },
  consumo: { label: "Consumo y ecommerce", color: "#FFD917", glow: "glow-amarillo" },
} as const;
export type AreaId = keyof typeof AREAS;
const AREA_OF: Record<string, AreaId> = {
  estrategia: "estrategia", gtm: "estrategia", posicionamiento: "estrategia", internacional: "estrategia",
  demanda: "demanda", performance: "demanda", growth: "demanda",
  product: "producto", saas: "producto", b2b: "producto",
  mops: "operaciones", crm: "operaciones", equipos: "operaciones",
  b2c: "consumo", ecommerce: "consumo", otras: "consumo",
};
export const areaOf = (specialtyId: string): AreaId => AREA_OF[specialtyId] ?? "producto";
