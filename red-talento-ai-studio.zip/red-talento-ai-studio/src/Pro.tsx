import type React from "react";
import { useMemo, useState } from "react";
import { useApp } from "./context";
import { ago, fmtDate, notify, now, plain, profileStatus, useCollection, useDoc } from "./db";
import type { AppStatusDoc, AppsDoc, BoardItem, InboxDoc, Profile, Review, AppPublicStatus } from "./types";
import { APP_STATUS, COLLABORATIONS, DEDICATIONS, PROFILE_STATUS, WORK_MODES , AREAS, areaOf, isActive } from "./constants";
import { Eyebrow, FiltroCampo, Filtros, OppRow } from "./OppRow";
import { Arrow, AvailabilityDot, DemoTag, Empty, Field, LoadingBlock, Modal, SectionHead, Select, Stat, StatusTag, TextArea, TextInput, useConfirm, useToast } from "./ui";
import { ProfileSummary, completeness } from "./Wizard";
import { specialtyOverlap } from "./match";

/* ---------- Datos del profesional ---------- */
export function useProData() {
  const { session } = useApp();
  const { db, uid } = session;
  const profile = useDoc<Profile>(db, uid ? `profiles/${uid}` : null);
  const review = useDoc<Review>(db, uid ? `reviews/${uid}` : null);
  const apps = useDoc<AppsDoc>(db, uid ? `apps/${uid}` : null);
  const appStatus = useDoc<AppStatusDoc>(db, uid ? `appStatus/${uid}` : null);
  const inbox = useDoc<InboxDoc>(db, uid ? `inbox/${uid}` : null);
  const board = useCollection<BoardItem>(db, db ? "board" : null);
  const status = profileStatus(profile.data, review.data);
  const ready = profile.ready && review.ready && apps.ready && appStatus.ready && board.ready;
  return { profile: profile.data, review: review.data, apps: apps.data, appStatus: appStatus.data, inbox: inbox.data, board: board.items, status, ready };
}
export type ProData = ReturnType<typeof useProData>;

export function pubStatus(d: ProData, oppId: string): AppPublicStatus {
  const a = d.apps?.items?.[oppId];
  if (a?.withdrawnAt) return "retirada";
  return d.appStatus?.items?.[oppId]?.status ?? "presentada";
}

/* ---------- Inicio ---------- */
export function ProHome({ d }: { d: ProData }) {
  const { go, label } = useApp();
  if (!d.ready) return <LoadingBlock label="Cargando tu área" />;
  const p = d.profile;
  if (!p) {
    return (
      <Page>
        <SectionHead eyebrow="Tu área" title="Te damos la bienvenida a la red" text="Empieza creando tu perfil profesional. Son cinco pasos cortos y puedes guardar y seguir más tarde." />
        <div className="mt-8"><Empty title="Aún no tienes perfil" text="En cuanto lo envíes, tu perfil entra en la comunidad y ya puedes presentarte a las oportunidades publicadas. Sin aprobación previa." action={<button className="btn btn-verde" onClick={() => go({ name: "registro" })}>Crear mi perfil <Arrow /></button>} /></div>
      </Page>
    );
  }
  const st = PROFILE_STATUS[d.status];
  const pct = completeness(p);
  const published = d.board.filter((b) => b.status === "publicada");
  const matching = published.filter((b) => specialtyOverlap(p, b) > 0);
  const appItems = Object.values(d.apps?.items ?? {});
  const active = appItems.filter((a) => !["retirada", "no_seleccionada", "seleccionada"].includes(pubStatus(d, a.oppId)));
  const updates = appItems
    .map((a) => ({ a, st: pubStatus(d, a.oppId), at: a.withdrawnAt ?? d.appStatus?.items?.[a.oppId]?.updatedAt ?? a.appliedAt }))
    .sort((x, y) => (y.at > x.at ? 1 : -1)).slice(0, 4);
  const first = p.fullName.split(" ")[0] || "";

  return (
    <Page>
      <SectionHead eyebrow="Tu área" title={<>Hola{first ? `, ${first}` : ""}</>} text={st.hint}
        actions={<><button className="btn btn-contorno" onClick={() => go({ name: "perfil" })}>Ver mi perfil</button>{isActive(d.status) && <button className="btn btn-verde" onClick={() => go({ name: "oportunidades" })}>Ver oportunidades <Arrow /></button>}</>} />

      {d.status === "info_solicitada" && d.review?.note && (
        <div className="mt-6 flex flex-col gap-3 rounded-tarjeta bg-amarillo p-6">
          <span className="eyebrow !text-negro">Mensaje del equipo</span>
          <p className="max-w-[70ch] text-[16px]">{d.review.note}</p>
          <p className="text-[13.5px]">Tu perfil sigue activo y puedes presentarte a oportunidades mientras tanto.</p>
          <div><button className="btn btn-negro btn-sm" onClick={() => go({ name: "registro", step: 0 })}>Completar mi perfil</button></div>
        </div>
      )}
      {d.status === "borrador" && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-tarjeta bg-roto p-6">
          <p>Tu perfil está a medias. Te quedan {5 - Math.min(p.step ?? 0, 4)} de 5 pasos para enviarlo.</p>
          <button className="btn btn-verde" onClick={() => go({ name: "registro" })}>Continuar registro <Arrow /></button>
        </div>
      )}

      <div className="mt-10 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <div className="bento tarjeta-roto flex min-h-[148px] flex-col justify-between gap-4 p-5"><span className="font-mono text-[10.5px] uppercase tracking-[.07em] text-suave">Estado del perfil</span><div><StatusTag {...st} /></div></div>
        <div className="bento tarjeta-roto flex min-h-[148px] flex-col justify-between gap-4 p-5">
          <span className="glow glow-verde -left-6 -top-10 w-[140px] opacity-40" aria-hidden="true" />
          <span className="font-mono text-[10.5px] uppercase tracking-[.07em] text-suave">Disponibilidad</span>
          <AvailabilityDot value={p.availability} />
        </div>
        <Stat value={`${pct}%`} label="Perfil completado" onClick={() => go({ name: "perfil" })} />
        <Stat value={matching.length} label="Oportunidades activas que encajan contigo" onClick={() => go({ name: "oportunidades" })} accent={matching.length > 0} />
        <Stat value={active.length} label="Candidaturas en curso" onClick={() => go({ name: "candidaturas" })} />
      </div>

      <section className="mt-10 flex flex-col gap-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-col gap-2"><Eyebrow>Encajan con tu especialización</Eyebrow><h2 className="font-display text-[32px] leading-none">Oportunidades para ti</h2></div>
          <button className="btn btn-texto !no-underline" onClick={() => go({ name: "oportunidades" })}>Ver todas <Arrow /></button>
        </div>
        {matching.length ? (
          <ul className="flex flex-col gap-4">
            {matching.slice(0, 3).map((b, i) => (
              <li key={b.id}><OppRow o={{ ...b, confidential: !b.client }} n={i + 1} label={label} onClick={() => go({ name: "oportunidad", id: b.id })}
                badge={d.apps?.items?.[b.id] ? <StatusTag {...APP_STATUS[pubStatus(d, b.id)]} /> : <span className="tag bg-verde">Encaja contigo</span>} /></li>
            ))}
          </ul>
        ) : <div className="vidrio !rounded-[24px] p-6 text-suave">{isActive(d.status) ? "Ahora mismo no hay oportunidades publicadas con tus especialidades. Te avisaremos cuando haya." : "Las verás aquí en cuanto envíes tu perfil."}</div>}
      </section>

      <section className="bento vidrio mt-6 flex flex-col gap-4 p-6 md:p-7">
        <span className="glow glow-celeste -right-24 -top-24 w-[300px] opacity-50" aria-hidden="true" />
        <Eyebrow>Tus candidaturas</Eyebrow>
        <h2 className="font-display text-[28px] leading-none">Últimas actualizaciones</h2>
        {updates.length ? (
          <ul>
            {updates.map(({ a, st, at }) => (
              <li key={a.oppId} className="border-t border-filo">
                <button className="fila flex w-full flex-wrap items-center justify-between gap-3 px-3 py-3.5 text-left" onClick={() => go({ name: "oportunidad", id: a.oppId })}>
                  <span className="min-w-0 font-medium">{a.title}</span>
                  <span className="flex items-center gap-3"><StatusTag {...APP_STATUS[st]} /><span className="font-mono text-[10.5px] uppercase tracking-[.06em] text-suave">{ago(at)}</span></span>
                </button>
              </li>
            ))}
          </ul>
        ) : <p className="text-suave">Cuando te presentes a una oportunidad, verás aquí cómo avanza.</p>}
      </section>
    </Page>
  );
}

/* ---------- Mi perfil ---------- */
export function MyProfile({ d }: { d: ProData }) {
  const { go, label, session } = useApp();
  const toast = useToast();
  const confirm = useConfirm();
  const [preview, setPreview] = useState(false);
  const [availOpen, setAvailOpen] = useState(false);
  if (!d.ready) return <LoadingBlock />;
  const p = d.profile;
  if (!p) return <Page><Empty title="Aún no tienes perfil" text="Crea tu perfil para entrar en la red." action={<button className="btn btn-verde" onClick={() => go({ name: "registro" })}>Crear mi perfil</button>} /></Page>;

  async function requestDeletion() {
    const ok = await confirm.ask("Solicitar eliminación", "El equipo eliminará tu perfil, tus candidaturas y cualquier nota asociada. Esta acción no se puede deshacer una vez tramitada.", "Solicitar eliminación");
    if (!ok || !session.db || !session.uid) return;
    try {
      await session.db.doc(`profiles/${session.uid}`).update({ deletionRequestedAt: now() });
      await notify(session.db, session.uid, "Hemos recibido tu solicitud de eliminación de datos. El equipo la tramitará.");
      toast("Solicitud enviada al equipo.");
    } catch { toast("No se ha podido enviar la solicitud. Vuelve a intentarlo.", "error"); }
  }

  return (
    <Page>
      <SectionHead eyebrow="Mi perfil" title={p.fullName || "Tu perfil"} text={p.headline}
        actions={<>
          <button className="btn btn-contorno" onClick={() => setAvailOpen(true)}>Actualizar disponibilidad</button>
          <button className="btn btn-contorno" onClick={() => setPreview((x) => !x)}>{preview ? "Ver mi perfil completo" : "Cómo lo ve el equipo"}</button>
          <button className="btn btn-verde" onClick={() => go({ name: "registro", step: 0 })}>Editar perfil</button>
        </>} />
      <div className="mt-6 flex flex-wrap items-center gap-4">
        <StatusTag {...PROFILE_STATUS[d.status]} />
        <span className="text-[13px] text-suave">Actualizado {ago(p.updatedAt)} · {completeness(p)}% completado</span>
      </div>
      {preview && (
        <div className="mt-6 rounded-tarjeta bg-roto p-5 text-[14px]">
          Esta es la vista del equipo de Extandard. Los campos marcados como <span className="tag bg-negro text-blanco">Privado</span> solo los ve el equipo interno; el resto de profesionales de la red no puede ver tu perfil.
        </div>
      )}
      <div className="mt-8 max-w-[860px]">
        <ProfileSummary p={p} label={label} onEdit={preview ? undefined : (s) => go({ name: "registro", step: s })} showPrivate />
      </div>
      <section className="mt-14 max-w-[860px] border-t border-filo pt-6">
        <h2 className="font-display text-[20px]">Tus datos</h2>
        <p className="mt-2 max-w-[62ch] text-suave">Puedes pedir que eliminemos tu perfil y todos los datos asociados. {p.deletionRequestedAt && <strong className="font-medium text-negro">Solicitud enviada el {fmtDate(p.deletionRequestedAt)}.</strong>}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <button className="btn btn-contorno btn-sm" disabled={!!p.deletionRequestedAt} onClick={requestDeletion}>Solicitar eliminación de mis datos</button>
          <button className="btn btn-texto btn-sm" onClick={() => go({ name: "privacidad" })}>Aviso de privacidad</button>
        </div>
      </section>
      <AvailabilityModal open={availOpen} onClose={() => setAvailOpen(false)} p={p} />
      {confirm.node}
    </Page>
  );
}

function AvailabilityModal({ open, onClose, p }: { open: boolean; onClose: () => void; p: Profile }) {
  const { session } = useApp();
  const toast = useToast();
  const [v, setV] = useState(p.availability);
  const [from, setFrom] = useState(p.availableFrom);
  const [saving, setSaving] = useState(false);
  async function save() {
    if (!session.db || !session.uid) return;
    setSaving(true);
    try {
      await session.db.doc(`profiles/${session.uid}`).update({ availability: v, availableFrom: from, updatedAt: now() });
      toast("Disponibilidad actualizada."); onClose();
    } catch { toast("No se ha podido guardar.", "error"); } finally { setSaving(false); }
  }
  return (
    <Modal open={open} onClose={onClose} title="Actualizar disponibilidad">
      <div className="flex flex-col gap-4">
        <Select id="avail-quick" aria-label="Disponibilidad" value={v} onChange={(e) => setV(e.target.value as Profile["availability"])}
          options={[{ value: "disponible", label: "Disponible" }, { value: "proximamente", label: "Disponible próximamente" }, { value: "limitada", label: "Disponibilidad limitada" }, { value: "no_disponible", label: "No disponible" }]} />
        <Field id="avail-from" label="Fecha estimada de incorporación" optional><TextInput id="avail-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
        <div className="flex justify-end gap-2"><button className="btn btn-contorno" onClick={onClose}>Cancelar</button><button className="btn btn-verde" onClick={save} disabled={saving}>Guardar</button></div>
      </div>
    </Modal>
  );
}

/* ---------- Oportunidades (profesional y visitantes) ---------- */
export function OppList({ d, publicView }: { d?: ProData; publicView?: boolean }) {
  const { go, label, catalog, session } = useApp();
  const board = useCollection<BoardItem>(session.db, publicView ? "board" : null);
  const items = publicView ? board.items : d?.board ?? [];
  const ready = publicView ? board.ready : d?.ready;
  const [q, setQ] = useState("");
  const [f, setF] = useState({ specialty: "", sector: "", dedication: "", collaboration: "", workMode: "", location: "" });
  const [onlyMine, setOnlyMine] = useState(false);
  const list = useMemo(() => items
    .filter((b) => b.status === "publicada")
    .filter((b) => !q || `${b.title} ${b.summary} ${b.description}`.toLowerCase().includes(q.toLowerCase()))
    .filter((b) => !f.specialty || b.specialties.includes(f.specialty))
    .filter((b) => !f.sector || b.sector === f.sector)
    .filter((b) => !f.dedication || b.dedication === f.dedication)
    .filter((b) => !f.collaboration || b.collaboration === f.collaboration)
    .filter((b) => !f.workMode || b.workMode === f.workMode)
    .filter((b) => !f.location || (b.location ?? "").toLowerCase().includes(f.location.toLowerCase()))
    .filter((b) => !onlyMine || specialtyOverlap(d?.profile ?? null, b) > 0)
    .sort((a, b) => (b.publishedAt > a.publishedAt ? 1 : -1)), [items, q, f, onlyMine, d?.profile]);
  const sp = catalog.specialties.map((s) => ({ value: s.id, label: s.label }));
  const se = catalog.sectors.map((s) => ({ value: s.id, label: s.label }));
  const active = Object.values(f).some(Boolean) || q || onlyMine;
  const clear = () => { setQ(""); setOnlyMine(false); setF({ specialty: "", sector: "", dedication: "", collaboration: "", workMode: "", location: "" }); };
  return (
    <Page>
      <SectionHead eyebrow="Portal de oportunidades" title="Oportunidades" text="Proyectos abiertos en los que buscamos Fractional CMOs y líderes de marketing. Las oportunidades confidenciales no muestran el nombre del cliente." />
      <div className="mt-6 grid items-start gap-5 lg:grid-cols-[260px_1fr]">
        <Filtros active={!!active} onClear={clear}>
          <TextInput id="opp-q" type="search" placeholder="Buscar oportunidades" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar oportunidades" />
          {d?.profile && <button className="chip justify-center" aria-pressed={onlyMine} onClick={() => setOnlyMine(!onlyMine)}>Solo las que encajan conmigo</button>}
          <FiltroCampo id="f-sp" label="Especialidad"><Select id="f-sp" placeholder="Todas" options={sp} value={f.specialty} onChange={(e) => setF({ ...f, specialty: e.target.value })} /></FiltroCampo>
          <FiltroCampo id="f-se" label="Sector"><Select id="f-se" placeholder="Todos" options={se} value={f.sector} onChange={(e) => setF({ ...f, sector: e.target.value })} /></FiltroCampo>
          <FiltroCampo id="f-de" label="Dedicación"><Select id="f-de" placeholder="Cualquiera" options={DEDICATIONS} value={f.dedication} onChange={(e) => setF({ ...f, dedication: e.target.value })} /></FiltroCampo>
          <FiltroCampo id="f-co" label="Colaboración"><Select id="f-co" placeholder="Cualquiera" options={COLLABORATIONS} value={f.collaboration} onChange={(e) => setF({ ...f, collaboration: e.target.value })} /></FiltroCampo>
          <FiltroCampo id="f-wm" label="Modalidad"><Select id="f-wm" placeholder="Cualquiera" options={WORK_MODES} value={f.workMode} onChange={(e) => setF({ ...f, workMode: e.target.value })} /></FiltroCampo>
          <FiltroCampo id="f-lo" label="Ubicación"><TextInput id="f-lo" placeholder="Ciudad o país" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></FiltroCampo>
        </Filtros>
        <div className="flex min-w-0 flex-col gap-4">
          <Eyebrow>{list.length} {list.length === 1 ? "oportunidad abierta" : "oportunidades abiertas"}</Eyebrow>
          {!ready ? <LoadingBlock /> : list.length === 0 ? (
            <Empty title={active ? "Ninguna oportunidad con esos filtros" : "No hay oportunidades publicadas ahora mismo"} text={active ? "Prueba a quitar algún filtro o a buscar con otra palabra." : "Publicamos proyectos a medida que llegan. Mantén tu perfil y tu disponibilidad al día para que podamos avisarte."} />
          ) : (
            <ul className="flex flex-col gap-4">
              {list.map((b, idx) => {
                const applied = d?.apps?.items?.[b.id];
                const ov = specialtyOverlap(d?.profile ?? null, b);
                return (
                  <li key={b.id}>
                    <OppRow o={{ ...b, confidential: !b.client }} n={idx + 1} label={label} onClick={() => go({ name: "oportunidad", id: b.id })}
                      badge={applied ? <StatusTag {...APP_STATUS[d ? pubStatus(d, b.id) : "presentada"]} /> : ov > 0 ? <span className="tag bg-verde">Encaja contigo</span> : undefined} />
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </Page>
  );
}

function Meta({ k, v }: { k: string; v: React.ReactNode }) {
  return <div className="min-w-0"><dt className="text-suave">{k}</dt><dd className="truncate">{v || "—"}</dd></div>;
}

export function OppDetail({ id, d }: { id: string; d?: ProData }) {
  const { go, label, session } = useApp();
  const toast = useToast();
  const confirm = useConfirm();
  const board = useCollection<BoardItem>(session.db, d ? null : "board");
  const items = d ? d.board : board.items;
  const ready = d ? d.ready : board.ready;
  const b = items.find((x) => x.id === id);
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (!ready) return <LoadingBlock />;
  if (!b) return <Page><Empty title="Esta oportunidad ya no está disponible" text="Puede que se haya cerrado o archivado." action={<button className="btn btn-contorno" onClick={() => go({ name: d ? "oportunidades" : "publicas" })}>Volver a oportunidades</button>} /></Page>;

  const app = d?.apps?.items?.[id];
  const st = d && app ? pubStatus(d, id) : null;
  const canApply = !!d && isActive(d.status) && b.status === "publicada" && (!app || app.withdrawnAt);
  const deadlinePassed = b.deadline && new Date(b.deadline) < new Date(new Date().toDateString());

  async function apply() {
    if (!session.db || !session.uid || !d) return;
    if (msg.trim().length < 30) { setErr("Cuéntanos en unas líneas por qué encajas (mínimo 30 caracteres)."); return; }
    setBusy(true);
    try {
      const cur = plain(d.apps?.items ?? {});
      cur[id] = { oppId: id, title: b!.title, appliedAt: now(), motivation: msg.trim() };
      await session.db.doc(`apps/${session.uid}`).set({ items: cur });
      await notify(session.db, session.uid, `Candidatura presentada a «${b!.title}». Te avisaremos de cada cambio.`, id);
      setOpen(false); setMsg(""); toast("Candidatura presentada.");
    } catch { toast("No se ha podido presentar la candidatura. Vuelve a intentarlo.", "error"); } finally { setBusy(false); }
  }
  async function withdraw() {
    if (!session.db || !session.uid || !d) return;
    const ok = await confirm.ask("Retirar candidatura", `Vas a retirar tu candidatura a «${b!.title}». Podrás volver a presentarte mientras siga abierta.`, "Retirar candidatura");
    if (!ok) return;
    const cur = plain(d.apps?.items ?? {});
    cur[id] = { ...cur[id], withdrawnAt: now() };
    try { await session.db.doc(`apps/${session.uid}`).set({ items: cur }); toast("Candidatura retirada."); } catch { toast("No se ha podido retirar.", "error"); }
  }

  const section = (t: string, body?: string) => body ? (
    <section className="flex flex-col gap-2 border-t-[0.5px] border-filo pt-4"><h2 className="font-display text-[22px]">{t}</h2><p className="max-w-[68ch] whitespace-pre-line">{body}</p></section>
  ) : null;

  return (
    <Page>
      <button className="btn btn-texto btn-sm mb-6 !pl-0" onClick={() => go({ name: d ? "oportunidades" : "publicas" })}><Arrow dir="izquierda" /> Oportunidades</button>
      <div className="grid gap-10 lg:grid-cols-6">
        <article className="flex min-w-0 flex-col gap-6 lg:col-span-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="tag bg-roto border border-filo">{label(b.sector)}</span>
            <span className="tag border border-filo">{b.companyType}</span>
            {b.status !== "publicada" && <span className="tag bg-amarillo">{b.status === "pausada" ? "En pausa" : "Cerrada"}</span>}
            {b.demo && <DemoTag />}
          </div>
          <h1 className="font-display text-[38px] leading-[1.02] md:text-[50px]">{b.title}</h1>
          <p className="text-[18px] leading-[1.45]">{b.summary}</p>
          <p className="text-[14px] text-suave">{b.client ? `Cliente: ${b.client}` : "Cliente confidencial"} · Publicada {fmtDate(b.publishedAt)}</p>
          {section("El proyecto", b.description)}
          {section("Contexto y retos", b.context)}
          {section("Objetivos", b.objectives)}
          {section("Responsabilidades", b.responsibilities)}
          {section("Requisitos", b.requirements)}
        </article>
        <aside className="lg:col-span-2">
          <div className="flex flex-col gap-5 rounded-tarjeta bg-roto p-6 lg:sticky" style={{ top: "calc(88px + env(safe-area-inset-top,0px))" }}>
            <dl className="grid gap-3 text-[14px]">
              {([["Dedicación", b.dedication], ["Colaboración", b.collaboration], ["Duración", b.duration], ["Inicio previsto", b.startDate ? fmtDate(b.startDate) : "A convenir"], ["Modalidad", b.workMode], ["Ubicación", b.location], ["Rango económico", b.rate], ["Candidaturas hasta", b.deadline ? fmtDate(b.deadline) : ""]] as [string, string | null][])
                .filter(([, v]) => v).map(([k, v]) => <div key={k} className="flex justify-between gap-4 border-b-[0.5px] border-filo pb-2"><dt className="text-suave">{k}</dt><dd className="text-right">{v}</dd></div>)}
            </dl>
            <div className="flex flex-col gap-2">
              <span className="text-[13px] text-suave">Especialidades requeridas</span>
              <div className="flex flex-wrap gap-1.5">{b.specialties.map((s) => <span key={s} className="chip chip-static !text-[12px]">{label(s)}</span>)}</div>
            </div>
            {st && st !== "retirada" ? (
              <div className="flex flex-col gap-3 border-t border-filo pt-4">
                <span className="text-[13px] text-suave">Tu candidatura</span>
                <div className="flex items-center justify-between gap-3"><StatusTag {...APP_STATUS[st]} /><span className="text-[12px] text-suave">Presentada {fmtDate(app!.appliedAt)}</span></div>
                {["presentada", "revision", "preseleccionada", "entrevista"].includes(st) && <button className="btn btn-contorno btn-sm" onClick={withdraw}>Retirar candidatura</button>}
              </div>
            ) : d ? (
              <>
                <button className="btn btn-verde text-[17px]" disabled={!canApply || !!deadlinePassed} onClick={() => setOpen(true)}>Presentar candidatura <Arrow /></button>
                {!canApply && !isActive(d.status) && <p className="ayuda">{d.status === "borrador" ? "Termina y envía tu perfil para presentarte: entra en la red al momento." : "Tu perfil está pausado. Reactívalo para presentarte."}</p>}
                {deadlinePassed && <p className="ayuda">El plazo de candidatura ha terminado.</p>}
                {st === "retirada" && <p className="ayuda">Retiraste tu candidatura. Puedes volver a presentarte.</p>}
              </>
            ) : (
              <p className="ayuda">Para presentarte necesitas un perfil en la red. Te registras en cinco pasos y entras al momento, sin aprobación.</p>
            )}
          </div>
        </aside>
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Presentar candidatura">
        <div className="flex flex-col gap-4">
          <p className="text-suave">El equipo verá tu perfil completo junto a este mensaje.</p>
          <Field id="motivation" label="¿Por qué encajas en este proyecto?" help={`${msg.trim().length} caracteres · mínimo 30`} error={err}>
            <TextArea id="motivation" value={msg} invalid={!!err} onChange={(e) => { setMsg(e.target.value); setErr(""); }} maxLength={1200} placeholder="Experiencia parecida, resultados y cuándo podrías empezar" />
          </Field>
          <div className="flex justify-end gap-2"><button className="btn btn-contorno" onClick={() => setOpen(false)}>Cancelar</button><button className="btn btn-verde" onClick={apply} disabled={busy}>Enviar candidatura</button></div>
        </div>
      </Modal>
      {confirm.node}
    </Page>
  );
}

/* ---------- Mis candidaturas ---------- */
export function MyApplications({ d }: { d: ProData }) {
  const { go } = useApp();
  if (!d.ready) return <LoadingBlock />;
  const list = Object.values(d.apps?.items ?? {}).sort((a, b) => (b.appliedAt > a.appliedAt ? 1 : -1));
  return (
    <Page>
      <SectionHead eyebrow="Mis candidaturas" title="Seguimiento de tus candidaturas" text="El estado se actualiza en cuanto el equipo mueve tu candidatura." />
      <div className="mt-8">
        {list.length === 0 ? <Empty title="Todavía no te has presentado a ningún proyecto" text="Explora las oportunidades publicadas y preséntate a las que encajen contigo." action={<button className="btn btn-verde" onClick={() => go({ name: "oportunidades" })}>Ver oportunidades <Arrow /></button>} /> : (
          <div className="overflow-x-auto">
            <table className="tabla min-w-[640px]">
              <thead><tr><th>Oportunidad</th><th>Presentada</th><th>Estado</th><th>Última actualización</th><th aria-label="Acciones" /></tr></thead>
              <tbody>
                {list.map((a) => {
                  const st = pubStatus(d, a.oppId);
                  const upd = a.withdrawnAt ?? d.appStatus?.items?.[a.oppId]?.updatedAt ?? a.appliedAt;
                  return (
                    <tr key={a.oppId} className="clic" onClick={() => go({ name: "oportunidad", id: a.oppId })}>
                      <td className="font-medium">{a.title}</td>
                      <td className="tnum">{fmtDate(a.appliedAt)}</td>
                      <td><StatusTag {...APP_STATUS[st]} /></td>
                      <td className="tnum">{fmtDate(upd)}</td>
                      <td className="text-right"><span className="inline-flex items-center gap-2 text-[13px]">Ver proyecto <Arrow /></span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Page>
  );
}

/* ---------- Notificaciones ---------- */
export function Inbox({ d }: { d: ProData }) {
  const { session, go } = useApp();
  const items = d.inbox?.items ?? [];
  const unread = items.filter((n) => !n.read).length;
  async function markAll() {
    if (!session.db || !session.uid || !unread) return;
    try { await session.db.doc(`inbox/${session.uid}`).set({ items: plain(items).map((n) => ({ ...n, read: true })) }); } catch { /* */ }
  }
  return (
    <Page>
      <SectionHead eyebrow="Avisos" title="Notificaciones" text="Los avisos se muestran dentro de la plataforma. El envío por correo se activará cuando se conecte un proveedor de email."
        actions={unread ? <button className="btn btn-contorno" onClick={markAll}>Marcar todo como leído</button> : undefined} />
      <div className="mt-8 max-w-[820px]">
        {items.length === 0 ? <Empty title="No tienes avisos" text="Aquí verás la confirmación de tu registro, los mensajes del equipo y los cambios en tus candidaturas." /> : (
          <ul className="border-t border-filo">
            {items.map((n) => (
              <li key={n.id} className="flex items-start gap-4 border-b-[0.5px] border-filo py-4">
                <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full border border-filo ${n.read ? "" : "bg-verde"}`} aria-label={n.read ? "Leído" : "Sin leer"} />
                <div className="flex min-w-0 flex-1 flex-col gap-1">
                  <p className={n.read ? "text-suave" : ""}>{n.text}</p>
                  <span className="text-[12px] text-suave">{fmtDate(n.at, true)}</span>
                </div>
                {n.link && <button className="btn btn-texto btn-sm" onClick={() => go({ name: "oportunidad", id: n.link! })}>Ver</button>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </Page>
  );
}

export function Page({ children }: { children: React.ReactNode }) {
  return <div className="gutter relative isolate overflow-clip"><div className="mx-auto max-w-contenido py-10 md:py-14">{children}</div></div>;
}
