// Modelo de datos. Cada colección tiene su regla de acceso (ver RULES en db.ts).

export type Availability = "disponible" | "proximamente" | "limitada" | "no_disponible";
export type ProfileStatus = "borrador" | "enviado" | "revision" | "info_solicitada" | "aprobado" | "no_aceptado" | "inactivo";
export type OppStatus = "borrador" | "publicada" | "pausada" | "cerrada" | "archivada";
export type Stage = "nueva" | "revision" | "preseleccionada" | "entrevista" | "seleccionada" | "no_seleccionada";
export type AppPublicStatus = "presentada" | "revision" | "preseleccionada" | "entrevista" | "seleccionada" | "no_seleccionada" | "retirada";

export interface CatalogItem { id: string; label: string; archived?: boolean }
export interface Catalog { specialties: CatalogItem[]; sectors: CatalogItem[] }

export interface Experience { role: string; company: string; period: string; summary: string }

/** profiles/{uid} — lo escribe el propio profesional; lo lee él y el equipo. */
export interface Profile {
  uid: string;
  demo?: boolean;
  // Paso 1
  fullName: string;
  email: string;
  location: string;
  timezone: string;
  linkedin: string;
  website: string;
  languages: string[];
  // Paso 2
  headline: string;
  bio: string;
  years: number | null;
  currentRole: string;
  experience: Experience[];
  sectorsWorked: string[];
  companyTypes: string[];
  achievements: string;
  cvName?: string;
  // Paso 3
  specialties: string[];
  sectorsExpertise: string[];
  companySizes: string[];
  teamLeadership: string;
  tools: string;
  // Paso 4
  availability: Availability;
  availableFrom: string;
  dedication: string;
  collaboration: string[];
  workMode: string[];
  preferredLocations: string;
  rateType: "dia" | "mes";
  rateMin: number | null;
  currency: string;
  comments: string;
  // Paso 5
  consentAt?: string;
  submittedAt?: string;
  step: number;
  createdAt: string;
  updatedAt: string;
  deletionRequestedAt?: string;
}

export interface HistoryEntry { status: string; by: string; at: string; note?: string }

/** reviews/{uid} — solo el equipo escribe; el profesional lee su propio estado. */
export interface Review { status: ProfileStatus; note?: string; updatedAt: string; history: HistoryEntry[] }

/** internal/{uid} — notas y etiquetas privadas del equipo. */
export interface InternalNote { id: string; text: string; by: string; at: string }
export interface Internal { tags: string[]; notes: InternalNote[] }

/** opps/{id} — ficha interna completa (cliente, notas, tarifas). Solo equipo. */
export interface Opportunity {
  id: string;
  demo?: boolean;
  internalName: string;
  title: string;
  client: string;
  clientConfidential: boolean;
  summary: string;
  description: string;
  context: string;
  objectives: string;
  responsibilities: string;
  requirements: string;
  preferredExperience: string;
  specialties: string[];
  sector: string;
  companyType: string;
  dedication: string;
  collaboration: string;
  duration: string;
  startDate: string;
  workMode: string;
  location: string;
  rateMin: number | null;
  rateMax: number | null;
  rateType: "dia" | "mes";
  currency: string;
  publishRate: boolean;
  deadline: string;
  seats: number;
  internalNotes: string;
  status: OppStatus;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

/** board/{id} — proyección pública de una oportunidad publicada, sin datos confidenciales. */
export interface BoardItem {
  id: string;
  title: string;
  client: string | null;
  summary: string;
  description: string;
  context: string;
  objectives: string;
  responsibilities: string;
  requirements: string;
  specialties: string[];
  sector: string;
  companyType: string;
  dedication: string;
  collaboration: string;
  duration: string;
  startDate: string;
  workMode: string;
  location: string;
  rate: string | null;
  deadline: string;
  status: "publicada" | "pausada" | "cerrada";
  publishedAt: string;
  demo?: boolean;
}

/** apps/{uid} — candidaturas que ha presentado el profesional. */
export interface Application { oppId: string; title: string; appliedAt: string; motivation: string; withdrawnAt?: string }
export interface AppsDoc { items: Record<string, Application> }

/** appStatus/{uid} — estado visible para el profesional (lo escribe el equipo). */
export interface AppStatusEntry { status: AppPublicStatus; updatedAt: string }
export interface AppStatusDoc { items: Record<string, AppStatusEntry> }

/** pipeline/{uid} — seguimiento interno de cada candidatura. Solo equipo. */
export interface PipelineEntry { stage: Stage; favorite?: boolean; nextStep?: string; interviewNotes?: string; history: HistoryEntry[] }
export interface PipelineDoc { items: Record<string, PipelineEntry> }

/** inbox/{uid} — notificaciones internas. */
export interface Notice { id: string; text: string; at: string; read?: boolean; link?: string }
export interface InboxDoc { items: Notice[] }

export interface AuditEntry { action: string; target: string; by: string; at: string; detail?: string }
