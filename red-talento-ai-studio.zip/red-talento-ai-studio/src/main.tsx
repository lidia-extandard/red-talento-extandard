import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { firebaseConfigured, installFirebaseRuntime } from "./firebase/runtime";

async function start() {
  if (!window.claude && firebaseConfigured()) {
    try { await installFirebaseRuntime(); } catch (e) { console.error("No se ha podido iniciar Firebase", e); }
  }
  createRoot(document.getElementById("root")!).render(<React.StrictMode><App /></React.StrictMode>);
}
start();
