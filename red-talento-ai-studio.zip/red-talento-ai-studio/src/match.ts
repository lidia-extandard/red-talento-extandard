import type { BoardItem, Opportunity, Profile } from "./types";

/** Encaje por reglas transparentes (sin IA). Cada criterio suma puntos y deja una explicación. */
export interface Reason { ok: boolean | null; text: string; points: number; max: number }
export interface Fit { score: number; reasons: Reason[] }

type OppLike = Pick<Opportunity | BoardItem, "specialties" | "sector" | "companyType" | "dedication" | "collaboration" | "workMode"> & Partial<Pick<Opportunity, "rateMax" | "rateType" | "currency">>;

const AV_POINTS = { disponible: 15, proximamente: 10, limitada: 5, no_disponible: 0 } as const;

export function fit(p: Profile, o: OppLike, labels: (id: string) => string, includeRate = false): Fit {
  const r: Reason[] = [];
  const req = o.specialties ?? [];
  const hit = req.filter((s) => p.specialties?.includes(s));
  r.push({
    ok: req.length === 0 ? null : hit.length === req.length ? true : hit.length > 0 ? null : false,
    text: req.length ? `${hit.length} de ${req.length} especialidades requeridas${hit.length ? ` (${hit.map(labels).join(", ")})` : ""}` : "La oportunidad no pide especialidades concretas",
    points: req.length ? Math.round((40 * hit.length) / req.length) : 20, max: 40,
  });
  const sectorHit = !!o.sector && (p.sectorsExpertise?.includes(o.sector) || p.sectorsWorked?.includes(o.sector));
  r.push({ ok: o.sector ? sectorHit : null, text: o.sector ? (sectorHit ? `Experiencia en ${labels(o.sector)}` : `Sin experiencia declarada en ${labels(o.sector)}`) : "Sector sin definir", points: sectorHit ? 15 : 0, max: 15 });
  const ctHit = !!o.companyType && p.companyTypes?.includes(o.companyType);
  r.push({ ok: o.companyType ? ctHit : null, text: o.companyType ? (ctHit ? `Ha trabajado en ${o.companyType.toLowerCase()}s` : `No ha trabajado en ${o.companyType.toLowerCase()}s`) : "Tipo de empresa sin definir", points: ctHit ? 10 : 0, max: 10 });
  const av = AV_POINTS[p.availability] ?? 0;
  r.push({ ok: av >= 10 ? true : av > 0 ? null : false, text: { disponible: "Disponible ahora", proximamente: `Disponible próximamente${p.availableFrom ? ` (desde ${p.availableFrom})` : ""}`, limitada: "Disponibilidad limitada", no_disponible: "No disponible" }[p.availability] ?? "Disponibilidad desconocida", points: av, max: 15 });
  const dedHit = !!o.dedication && (p.dedication === o.dedication || p.dedication === "Flexible" || o.dedication === "Flexible");
  r.push({ ok: o.dedication ? dedHit : null, text: o.dedication ? (dedHit ? `Dedicación compatible (${o.dedication.toLowerCase()})` : `Prefiere ${p.dedication?.toLowerCase() || "otra dedicación"}`) : "Dedicación sin definir", points: dedHit ? 10 : 0, max: 10 });
  const colHit = !!o.collaboration && p.collaboration?.includes(o.collaboration);
  r.push({ ok: o.collaboration ? colHit : null, text: o.collaboration ? (colHit ? `Acepta ${o.collaboration.toLowerCase()}` : `No ha marcado ${o.collaboration.toLowerCase()}`) : "Modalidad sin definir", points: colHit ? 5 : 0, max: 5 });
  const wmHit = !!o.workMode && p.workMode?.includes(o.workMode);
  r.push({ ok: o.workMode ? wmHit : null, text: o.workMode ? (wmHit ? `Trabajo ${o.workMode.toLowerCase()} compatible` : `No ha marcado trabajo ${o.workMode.toLowerCase()}`) : "Modalidad de trabajo sin definir", points: wmHit ? 5 : 0, max: 5 });
  if (includeRate) {
    if (o.rateMax && p.rateMin && o.rateType === p.rateType && o.currency === p.currency) {
      const ok = p.rateMin <= o.rateMax;
      r.push({ ok, text: ok ? "Tarifa mínima dentro del rango" : "Tarifa mínima por encima del rango", points: 0, max: 0 });
    } else r.push({ ok: null, text: "Sin datos suficientes para comparar tarifas", points: 0, max: 0 });
  }
  return { score: r.reduce((a, b) => a + b.points, 0), reasons: r };
}

export function specialtyOverlap(p: Profile | null, o: { specialties: string[] }) {
  if (!p) return 0;
  return (o.specialties ?? []).filter((s) => p.specialties?.includes(s)).length;
}
