# Red de talento · Extandard

Comunidad abierta de Fractional CMOs y líderes de marketing, portal de oportunidades y panel interno del equipo.

- React 18, TypeScript, Vite y Tailwind.
- Datos y accesos en Firebase: Authentication y Cloud Firestore.
- Es el mismo código que la demo funcional en Claude. Lo único que cambia es la capa de datos, que aquí usa `src/firebase/`.

## Pasarlo a Google AI Studio

1. **Crea un repositorio vacío y privado en GitHub**, por ejemplo `red-talento-extandard`.
   - En la página del repositorio, pulsa «uploading an existing file».
   - Arrastra todo el contenido de esta carpeta, sin `node_modules` ni `dist`, y confirma con «Commit changes».
2. **En AI Studio**, abre Build, pulsa el botón «+» de la caja de texto y elige «Import from GitHub». Selecciona el repositorio.
3. **Pega el mensaje de `AI_STUDIO_PROMPT.md`.**
   - Antes, añade los correos del equipo en el punto 4.
   - AI Studio conecta Firebase, despliega las reglas y publica.
4. **Da de alta al equipo**, si AI Studio no lo ha hecho.
   - En la consola de Firebase, abre Firestore Database y crea la colección `admins`.
   - Crea un documento por persona. El ID del documento es su correo en minúsculas y lleva el campo `rol` = `equipo`.
5. **Entra con uno de esos correos.**
   - Para el acceso de equipo, el correo tiene que estar verificado. Google ya lo está; con email y contraseña hay que pulsar el enlace del correo de verificación.
   - En el panel, pulsa «Cargar datos de ejemplo» si quieres probar con perfiles ficticios.
6. **Publica** y conecta `red.extandard.es`.

Con la sincronización de GitHub, los cambios que haga AI Studio vuelven al repositorio.

## Roles y permisos

| Quién | Cómo se decide | Qué puede hacer |
|---|---|---|
| Visitante | Sin sesión | Ver la portada, el portal de oportunidades y cada oferta (`#/oportunidades/{id}`) |
| Profesional | Cualquier cuenta | Registrarse (entra en la comunidad sin aprobación), editar su perfil, presentarse, retirar candidaturas y ver sus avisos |
| Equipo | Correo verificado con documento en `admins/{correo}` | Todo el panel: comunidad, oportunidades, candidaturas, recomendados, catálogo y auditoría |

Los permisos los aplica `firestore.rules` en el servidor, no la interfaz.
- Un profesional solo lee y escribe sus documentos (`profiles`, `apps`, `inbox`).
- Un profesional solo lee lo que decide el equipo sobre él (`reviews`, `appStatus`).
- Lo interno (`opps`, `internal`, `pipeline`, `audit`) es solo del equipo.

## Colecciones

| Colección | Contenido |
|---|---|
| `profiles/{uid}` | Perfil completo de los 5 pasos, incluida la tarifa privada |
| `reviews/{uid}` | Estado que fija el equipo: información solicitada o perfil pausado, con historial |
| `apps/{uid}` | Candidaturas que presenta el profesional (mensaje, fecha, retirada) |
| `appStatus/{uid}` | Estado visible de cada candidatura. Lo escribe el equipo |
| `pipeline/{uid}` | Fase interna, favorito, próximo paso, notas de entrevista e historial |
| `inbox/{uid}` | Avisos dentro de la app |
| `opps/{id}` | Ficha interna de la oportunidad: cliente, tarifas y notas |
| `board/{id}` | Copia pública de cada oferta publicada, sin datos confidenciales |
| `internal/{uid}` | Notas y etiquetas del equipo sobre cada perfil |
| `audit/{id}` | Quién cambió qué y cuándo |
| `config/catalog` | Especialidades y sectores editables |
| `admins/{correo}` | Quién es del equipo. Solo se edita desde la consola |
| `staff/{uid}` | Nombre de cada miembro del equipo, para los historiales |

## Trabajar en local

```bash
npm install
cp .env.example .env   # y rellena la configuración web de Firebase
npm run dev
```

## Pendiente

- **Foto y CV**: los perfiles reales muestran sus iniciales. La subida con Firebase Storage está descrita como siguiente mensaje en `AI_STUDIO_PROMPT.md`.
- **Emails**: los avisos son internos, dentro de la app. Para enviarlos por correo hace falta conectar un proveedor; no se simulan envíos.
- **Reglas sin probar en el emulador**: `firestore.rules` no se ha podido ejecutar contra el emulador de Firestore en este entorno. El prompt pide a AI Studio que pruebe los accesos con un profesional y un administrador antes de publicar.
- **Aviso de privacidad**: es un borrador y tiene que revisarlo un asesor legal.
