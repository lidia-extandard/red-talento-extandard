Pega este mensaje en Google AI Studio después de importar el repositorio desde GitHub.

---

Este repositorio es la red de talento de Extandard (The Fractional CMO Company), ya construida en React + TypeScript + Vite + Tailwind. El diseño y la funcionalidad están terminados y aprobados. Las capturas de `docs/diseno/` muestran cómo debe verse.

NO rediseñes nada. No cambies textos, colores, tipografías, espaciados, componentes ni la estructura de pantallas. No sustituyas las fuentes de `src/fonts/` ni las fotos de `src/fotos/`. Tu trabajo es solo conectarla a Firebase, comprobar que funciona y publicarla.

CÓMO ESTÁ HECHA LA CAPA DE DATOS
- Toda la app usa una interfaz mínima tipo Firestore expuesta en `window.claude` (`db.doc`, `db.collection`, `onSnapshot`, `set`, `update`, `delete`) y un espacio de usuario (`me`, `canEdit`, `profiles`). Es intencionado: no la reescribas.
- `src/firebase/runtime.ts` ya implementa esa interfaz con Firebase Authentication y Cloud Firestore, y `src/main.tsx` la instala al arrancar si hay configuración.
- `src/Acceso.tsx` es la pantalla de acceso: Google, email y contraseña, verificación de email y recuperación de contraseña.

LO QUE TIENES QUE HACER
1. Conecta Firebase a esta app con tu integración: Cloud Firestore y Firebase Authentication.
   - Pon la configuración web del proyecto en `src/firebase/config.ts`. Lee las variables `VITE_FIREBASE_*` o el archivo de configuración que genere tu integración.
   - Si el nombre del archivo es distinto, cambia solo `config.ts`.
2. Activa los métodos de acceso Google y Correo/contraseña. Si tengo que activarlos yo en la consola de Firebase, dime exactamente dónde.
3. Despliega `firestore.rules` tal cual. Por defecto se deniega todo; las reglas validan los permisos en el servidor. No las abras ni añadas reglas permisivas para que algo funcione: si algo falla por permisos, dime qué y por qué.
4. Equipo: un usuario es administrador si su email verificado tiene un documento en `admins/{email en minúsculas}`. Esa colección no se edita desde la app.
   - Crea esos documentos para estos correos, con el campo `rol: "equipo"`: lidia@extandard.es, [añade aquí el resto del equipo].
   - Si no puedes crearlos tú, dime cómo hacerlo en la consola.
5. No toques `src/firebase/runtime.ts` salvo para corregir un error. Si lo cambias, explícame el motivo.

PRUEBA ANTES DE TERMINAR
- Un visitante sin sesión ve la portada, las últimas oportunidades y el portal `#/oportunidades`. Ve la ficha de cada oferta en `#/oportunidades/{id}`, con las UTM conservadas en la URL.
- Al entrar con un correo de `admins` se abre el panel del equipo.
  - Con la base vacía aparece «Cargar datos de ejemplo». Púlsalo: carga 8 perfiles y 3 oportunidades marcados como ficticios.
- Una persona nueva crea su cuenta con email, completa el registro de 5 pasos y su perfil queda Activo sin aprobación. Después se presenta a una oferta.
- El administrador mueve esa candidatura a Preseleccionados en el kanban. El profesional ve el nuevo estado y el aviso en su área.
- Con la cuenta del profesional, intenta leer `profiles`, `opps`, `internal`, `pipeline` y `audit` de otras personas. Las reglas deben rechazarlo.
- Una oferta confidencial nunca muestra el cliente en la parte pública. La tarifa solo se ve si la oferta está marcada para publicarla.

PUBLICACIÓN
Publica con Publish y explícame cómo conectar el subdominio red.extandard.es: registros DNS y dónde se configura.

AL TERMINAR
Dime qué has cambiado (archivo por archivo), qué has probado y qué tengo que hacer yo en la consola de Firebase.

---

Siguientes mensajes opcionales, de uno en uno:
- «Añade la subida de foto y CV en el paso 1 y 2 del registro con Firebase Storage, en `fotos/{uid}` y `cv/{uid}`, legibles solo por su dueño y por los administradores. La foto debe verse en las tarjetas de perfil igual que las de ejemplo: retrato con el fondo del color de su área.»
- «Envía por email los avisos que hoy son internos (perfil activo, cambio de estado de candidatura, nueva oferta que encaja) con [proveedor]. Te paso la clave como secreto del servidor. No envíes nada sin proveedor configurado.»
